# Tableau Development Agent Instructions

<!-- Canonical cross-tool instructions. CLAUDE.md and GEMINI.md import this file;
     .cursorrules and .windsurfrules are generated from it by build/build.py. Edit here. -->

This project authors Tableau workbooks (`.twb` / `.twbx`), data sources and `.hyper` extracts with AI agents, and optionally publishes and renders them on Tableau Server / Tableau Cloud.

## Architecture: Agents → Skills → Common → MCP tools

- **Agents** (`agents/`) orchestrate work that crosses stages. Start broad requests with `agents/TableauReportDeveloper.agent.md`.
- **Skills** (`skills/<name>/SKILL.md`) hold the procedure for one area. Each SKILL.md is a short dispatcher; read the reference file it points to before acting.
- **Common** (`common/`) holds rules every skill shares. Read `common/TABLEAU-CORE.md` before the first workbook change of a session.
- **MCP tools** (`mcp-server/server.py`, server name `tableau-desktop`) perform every workbook read and write, with backup-before-write.

## Skills

| Skill | Use for |
|---|---|
| `skills/tableau-report-cli` | Plan → design → author → QA for worksheets and dashboards (modes: planning, design, authoring, qa) |
| `skills/tableau-datasource-authoring` | Connections, calculated fields, LOD calcs, parameters, `.hyper` extracts |
| `skills/tableau-chart-library` | Browse and extend the 81-chart template/recipe library |
| `skills/tableau-server-cli` | Publish, render (PNG/PDF), refresh, download on Server/Cloud via PAT |
| `skills/looker-to-tableau-migration` | LookML (+ PDF) → BRD.md → Tableau build |

## Agents

| Agent | Role |
|---|---|
| `TableauReportDeveloper` | End-to-end report builds; delegates everything below |
| `TableauDataEngineer` | Data layer |
| `TableauQA` | Independent validate → render → review → fix loop, 3-attempt cap |
| `TableauMigrationEngineer` | Looker → Tableau |

## Non-negotiables

1. Use an MCP tool when one exists; hand-edit XML only for mechanical bulk changes, then run `validate_workbook`.
2. `inspect_workbook` first. Never map, plan or invent a field that isn't in the workbook.
3. Run `validate_workbook` after every write. "Saved" is not "correct": a target is done only after a logged QA pass.
4. Stop after 3 logged QA failures on a target and escalate to the user with the history.
5. Never write secrets (PATs, database passwords) into chat, workbooks or repo files. Server auth uses `TABLEAU_*` environment variables.
6. State limitations plainly: measure/date quick filters, non-grid dashboards, charts with no recipe and formatting polish are Desktop steps.

## Setup

```bash
pip install -r mcp-server/requirements.txt
python mcp-server/server.py --selftest
```

MCP registration for each host: `mcp-setup/README.md`.
