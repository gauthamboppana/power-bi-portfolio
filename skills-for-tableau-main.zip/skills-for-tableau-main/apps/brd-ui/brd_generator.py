"""
Turns raw LookML files (+ optionally the Looker dashboard PDF) into a BRD.md
- the input format tableau-report-cli planning mode's "Starting from a BRD"
section expects, so the existing Tableau-side chat/agent picks up exactly
where a hand-written BRD would leave off.

generate_brd_agentic (the only entry point) runs this as a real tool-use
loop: the model gets tools to list the uploaded LookML files and read any
one of them raw, and does its own reading/understanding of the LookML
syntax (brace-syntax views/explores/models, YAML dashboard files) - there is
no separate Python-side lkml/PyYAML parsing step feeding it a pre-extracted
structure. That deterministic-parse approach was tried and dropped: LookML
is heterogeneous enough in practice that a strict grammar parser hard-fails
an entire file on one unexpected token, which is a worse failure mode than
having the LLM read the file directly the way a person would. The model is
still told never to invent a field name that isn't actually in the text
it read - the discipline moves from "a parser enforces this mechanically"
to "the agent is instructed to quote only what it can see," which is the
same standard the Tableau build agent (app.py) is held to for workbook XML.
"""

import base64
import json

# Reference table only (not computed from any parsed structure) - the LLM
# uses this itself when a dashboard tile's raw `type:` value names a known
# Looker viz type, mapping to the same 81-chart template library
# skills/tableau-report-cli design mode points to. `None`/absent means no clean
# Tableau chart equivalent - flag for Desktop/manual design judgment rather
# than guessing.
LOOKER_TO_TABLEAU_MAPPING = """
| Looker `type:` | Tableau template | Intent |
|---|---|---|
| looker_line | Line | trend |
| looker_column | Bar__Columns_ | comparison |
| looker_bar | Bar__Rows_ | comparison |
| looker_area | Area | trend |
| looker_scatter | Scatter_plots | correlation |
| single_value | KPI | single-value |
| looker_single_record | KPI | single-value |
| looker_pie | Pie | composition |
| looker_donut_multiples | Donut | composition |
| looker_waterfall | Waterfall | composition |
| looker_boxplot | Box_Plot | distribution |
| looker_bullet | Bullet | single-value |
| looker_funnel | Funnel | composition |
| looker_geo_choropleth | Map_Basic | geospatial |
| looker_map | Map_Basic | geospatial |
| looker_grid / table | (none - crosstab) | table: build as a Tableau text table, not a chart recipe |
| looker_column_line | Bars___Line_Dual_Axis | two-measure comparison over time |

Any `type:` not in this table has no established Tableau mapping yet - say so and flag it for manual chart-type judgment rather than guessing a template.
"""

SYSTEM_PROMPT = """You are producing a BRD.md (business requirements document) for a Looker-to-Tableau migration. Your audience is another AI agent (tableau-report-cli, planning mode) that will read this BRD to pre-fill a build spec, plus the human who will confirm it - so it must be structured, literal, and honest about gaps, not aspirational or padded.

You are reading raw LookML/YAML source files yourself (via tools - see below) - there is no separate pre-parsed extraction handed to you. Two distinct LookML shapes exist:
- View/explore/model files (often named *.view.lkml, *.explore.lkml, *.model.lkml, or just *.lkml / *.txt): Looker's own brace syntax, e.g. `dimension: field_name { type: string sql: ${TABLE}.column ;; }`, `measure: total { type: sum sql: ${amount} ;; }`, `explore: name { join: other { sql_on: ... ;; relationship: many_to_one }}`.
- Dashboard files (often *.dashboard.lookml or *.dashboard.lkml, sometimes just *.lkml/*.txt): these are YAML, not brace-LookML - a `- dashboard: name` list with `elements:` (tiles), each tile having `title`, `type` (the Looker viz type), `fields`, `filters`, `sorts`, layout (`row`/`col`/`width`/`height`), and optionally `dynamic_fields` (inline computed fields - Looker's equivalent of a Tableau calculated field, so port the `expression`, don't just treat the name as a real view field) and `listen` (maps a dashboard-level filter to the field on that tile it filters).

Ground rules:
- Use ONLY field/dimension/measure/join names you can actually see in the raw file text you read - never rename, "clean up", or invent one. If you're not sure a name is exactly right, say so as a gap rather than guessing.
- If a dashboard PDF is attached, use it to identify tile titles, approximate chart types, colors, and layout ONLY for what isn't already covered by dashboard LookML (or as a cross-check if it is). Visual-only observations from a PDF are lower confidence than LookML facts - label them as such (e.g. "from PDF, not LookML - confirm field names").
- Do NOT invent an audience, a job-to-be-done, a delivery target, or a field that isn't evidenced in the source material. Where the source is silent, write "Not specified in Looker source - needs confirmation" rather than guessing a plausible-sounding answer.
- Map Looker field types to Tableau roles: Looker `dimension`/`dimension_group` -> Tableau dimension; Looker `measure` -> Tableau measure. Note the Looker measure `type` (sum/count/average/...) since it affects the Tableau aggregation to use.
- Use the Looker viz type -> Tableau template mapping table below when a dashboard tile's `type:` matches an entry; only override it if the PDF clearly shows something different from what the LookML declares.
- Flag anything Tableau can't do the same way Looker did (e.g. a `looker_grid` table has no direct Tableau chart-template equivalent, a Looker join graph may need re-modeling as a Tableau data source relationship) rather than silently dropping it.
- **Tile-level `filters:` are load-bearing, not decoration.** When several tiles share one `explore` and nearly identical `fields`/`type`, differing mainly in their `filters:` block, that is Looker's way of saying "same chart, restricted to a different slice" - e.g. four tiles all filtering `some_view.some_dimension` to a different literal value each. Transcribe every tile's `filters:` block into the BRD VERBATIM (field name and exact literal value/expression, e.g. `data_state_fact.data_state: '"MISSING_IN_TRANSACTION_FACT_PENDING_JMS_EVENT_3_OR_MORE_HOURS"'` - keep the quoting exactly as written), even filters that look like plain date-range pickers (e.g. `create_hour_date: 72 hours` or `: this month`) - note those as a relative-date filter with its literal window, since Tableau needs the same restriction even if the build tooling can't yet automate a relative-date filter (flag that gap explicitly if so). Never omit a tile's filters just because they look similar across tiles - the difference between two similar tiles usually lives entirely in this block.
- **A Looker dimension_group name suffix encodes date/time granularity, not just a name.** `some_field.create_hour_hour` means "create_hour truncated/grouped to the Hour"; `some_field.create_hour_date` means truncated to the Day; likewise `_week`, `_month`, `_quarter`, `_year`. When a tile's `fields`/`sorts`/`pivots`/axis uses one of these suffixed names, say explicitly in the BRD which base field and which granularity it is (e.g. "create_hour, truncated to Hour") - don't just list the bare field name, since building the wrong granularity (e.g. Year/Quarter instead of Hour) produces a chart that looks built but shows the wrong thing.
- **A tile's `dynamic_fields` entry is a Tableau calculated field that must exist before the tile is built**, not a reference to something already in the data source. For each one, in the BRD: give it a name (use its `label`, or `dimension`/`measure` key), and translate its Looker `expression` into an equivalent Tableau calculation formula - a Looker `case(when(${view.field} = "X", "label"), when(...), "default")` becomes a Tableau `CASE [field] WHEN "X" THEN "label" WHEN ... ELSE "default" END` (or nested `IF`/`ELSEIF`, either is fine) referencing the same real field and the same literal match values verbatim. If the same dynamic_fields block (same expression) repeats across multiple tiles, it's the same one calculated field reused everywhere, not a separate one per tile - say so, so it only gets built once.
""" + LOOKER_TO_TABLEAU_MAPPING + """
Output ONLY the BRD as Markdown, starting with a `# BRD:` heading. Use this shape (adapt as the source material actually supports, don't pad empty sections):

# BRD: <name inferred from the dashboard title, or the Looker project/model name>

## Source
- Migrated from Looker (LookML + dashboard PDF where noted)
- What's known vs. not specified (be explicit about gaps)

## Data model
For each Looker view: its fields as a dimensions/measures table (name, type, Tableau role, notes).
For each explore: its joins, and what that implies for the Tableau data source relationships.

## Calculated fields
One entry per distinct `dynamic_fields` expression found anywhere in the dashboard LookML (de-duplicated - see the ground rule above): name, the Tableau calculation formula translated from its Looker `expression`, and which tiles use it.

## Dashboards
For each dashboard: title, and for each tile - title, Looker type -> Tableau chart-template mapping, fields used (with date/time fields annotated with their granularity per the ground rule above), the tile's filter(s) transcribed verbatim (field + exact literal value, including relative-date filters), layout (row/col/width/height if known), and confidence (LookML-sourced vs. PDF-visual-only).

## Gaps and open questions
Anything genuinely unresolved: no clean Tableau chart equivalent, ambiguous field mapping, audience/delivery target not stated, colors/formatting visible in the PDF but not captured structurally, a relative-date filter the build tooling can't automate yet, or any file you couldn't make sense of.

You have tools to read the source material - use them before writing:
- list_lookml_files: see every uploaded file's name.
- read_lookml_file: read one uploaded file's raw text, by filename. Read every uploaded file that could plausibly hold dimensions/measures/joins/dashboard tiles - don't skip a file just because its name or extension is ambiguous (`.txt` uploads are LookML too). If a file's content genuinely isn't LookML/YAML you can make sense of, say so as a gap rather than silently dropping it from the BRD.

Work through the material methodically: list the files, read each one, build up the data model and dashboard picture as you go. Once you're confident you understand it, write the final BRD as your plain-text response and stop calling tools - don't keep re-reading files past the point where it's adding anything.
"""

BRD_TOOLS = [
    {
        "name": "list_lookml_files",
        "description": "List every uploaded LookML/YAML file's filename, for use with read_lookml_file.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "read_lookml_file",
        "description": "Read one uploaded file's raw text, by filename (as listed by list_lookml_files). This is the only way to see a file's content - read it yourself and extract whatever LookML structure (dimensions, measures, joins, dashboard tiles) is actually there.",
        "input_schema": {
            "type": "object",
            "properties": {"filename": {"type": "string"}},
            "required": ["filename"],
        },
    },
]


def generate_brd_agentic(
    client,
    model: str,
    files: list,
    pdf_bytes: bytes = None,
    pdf_filename: str = None,
    max_rounds: int = 8,
    on_step=None,
) -> str:
    """Runs BRD generation as a tool-use loop. `files` is [(filename,
    raw_text), ...] (e.g. from lookml_extract.expand_lookml_uploads) - the
    model reads and interprets this raw LookML/YAML text itself via
    list_lookml_files/read_lookml_file; nothing is pre-parsed in Python.
    `on_step`, if given, is called with a short string before each round and
    before each tool call, for progress reporting in a UI. Returns raw
    markdown text; raises RuntimeError if the agent doesn't finish within
    `max_rounds` (it may be stuck re-reading files - a sign something in the
    source material is confusing it)."""
    files_by_name = {name: text for name, text in files}

    def run_tool(tool_name, tool_input):
        if tool_name == "list_lookml_files":
            return {"filenames": list(files_by_name.keys())}
        if tool_name == "read_lookml_file":
            fname = tool_input.get("filename")
            if fname not in files_by_name:
                return {"error": f"No uploaded file named '{fname}'. Call list_lookml_files to see what's available."}
            return {"filename": fname, "text": files_by_name[fname]}
        return {"error": f"Unknown tool '{tool_name}'"}

    content = [{
        "type": "text",
        "text": "Produce the BRD.md now. Use the tools available to you to read every uploaded source file before writing - start with list_lookml_files.",
    }]
    if pdf_bytes:
        content.append({
            "type": "document",
            "source": {
                "type": "base64",
                "media_type": "application/pdf",
                "data": base64.b64encode(pdf_bytes).decode("ascii"),
            },
            "title": pdf_filename or "Looker dashboard export",
        })
        content.append({
            "type": "text",
            "text": "The attached PDF is the Looker dashboard's exported view - use it for tile layout, chart types, colors, and titles wherever the LookML doesn't already cover them.",
        })

    messages = [{"role": "user", "content": content}]

    for round_num in range(max_rounds):
        if on_step:
            on_step(f"Round {round_num + 1}: thinking...")
        response = client.messages.create(
            model=model,
            max_tokens=8192,
            system=SYSTEM_PROMPT,
            tools=BRD_TOOLS,
            messages=messages,
        )
        assistant_content = [block.model_dump() for block in response.content]
        messages.append({"role": "assistant", "content": assistant_content})

        if response.stop_reason != "tool_use":
            return "".join(b["text"] for b in assistant_content if b["type"] == "text").strip()

        tool_results = []
        for block in assistant_content:
            if block["type"] == "tool_use":
                if on_step:
                    detail = f"({block['input']})" if block["input"] else "()"
                    on_step(f"{block['name']}{detail}")
                result = run_tool(block["name"], block["input"])
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block["id"],
                    "content": json.dumps(result, default=str)[:20000],
                })
        messages.append({"role": "user", "content": tool_results})

    raise RuntimeError(
        f"BRD agent didn't finish within {max_rounds} rounds - it may be stuck re-reading files. "
        "Try again, or check the LookML for something unusual that's confusing it."
    )
