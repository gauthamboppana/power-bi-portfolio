"""
Structural preview for the Tableau BRD -> Workbook Agent UI.

This is NOT a pixel-accurate render - Tableau Desktop has no headless render
API (see the parent repo's README on why), so nothing outside Desktop itself
can produce the actual chart pixels. What this gives instead:

1. A wireframe diagram of a dashboard's zone layout (worksheet placement,
   legends/filters/parameter controls) built directly from the same x/y/w/h
   zone geometry instantiate_dashboard_layout writes - accurate to the real
   structure, just not the real marks.
2. A plain-text summary of a worksheet's shelves/encodings (rows, columns,
   color, size, ...) parsed from its <table><view> XML.
3. A thin wrapper around the existing request_render / check_render tools so
   the one unavoidable manual step (reopen in Desktop, export an image) has
   somewhere to land and be displayed inline once the user does it.
"""

import re
from xml.etree import ElementTree as ET

SPACE = 100000  # 0-100000 coordinate space per axis, per instantiate_dashboard_layout

LEAF_TYPES = {
    "title": "Title",
    "color": "Legend",
    "filter": "Filter",
    "paramctrl": "Parameter control",
    "text": "Text",
}
CONTAINER_TYPES = {"layout-basic", "layout-flow"}


def _zone_rect(zone_el):
    try:
        return (
            float(zone_el.get("x", 0)),
            float(zone_el.get("y", 0)),
            float(zone_el.get("w", 0)),
            float(zone_el.get("h", 0)),
        )
    except (TypeError, ValueError):
        return None


def collect_dashboard_zones(root: ET.Element, dashboard_name: str):
    """Returns a list of {label, kind, x, y, w, h} (0-100000 space) for the
    named dashboard's drawable (leaf) zones, or None if the dashboard/its
    zones element isn't found."""
    dash = None
    for d in root.findall("./dashboards/dashboard"):
        if d.get("name") == dashboard_name:
            dash = d
            break
    if dash is None:
        return None

    zones_el = dash.find("zones")
    if zones_el is None:
        return []

    out = []

    def walk(el):
        type_v2 = el.get("type-v2")
        name = el.get("name")
        rect = _zone_rect(el)
        if type_v2 in CONTAINER_TYPES or type_v2 is None and name is None and rect is None:
            for child in el:
                if child.tag == "zone":
                    walk(child)
            return
        if rect is None:
            return
        if type_v2 in LEAF_TYPES:
            label = LEAF_TYPES[type_v2]
            param = el.get("param")
            if param:
                label = f"{label}: {param}"
            out.append({"label": label, "kind": type_v2, "rect": rect})
        elif name:
            out.append({"label": name, "kind": "worksheet", "rect": rect})
        # recurse regardless, in case a leaf-looking zone still nests children
        for child in el:
            if child.tag == "zone":
                walk(child)

    for top in zones_el:
        if top.tag == "zone":
            walk(top)
    return out


_KIND_COLORS = {
    "worksheet": ("#eef2ff", "#4f46e5"),
    "title": ("#fef9c3", "#a16207"),
    "color": ("#dcfce7", "#15803d"),
    "filter": ("#fee2e2", "#b91c1c"),
    "paramctrl": ("#e0f2fe", "#0369a1"),
    "text": ("#f3f4f6", "#374151"),
}


def dashboard_wireframe_svg(zones: list, width: int = 640, height: int = 420) -> str:
    """Renders the zone list from collect_dashboard_zones as an SVG wireframe."""
    if not zones:
        return f'<svg width="{width}" height="{height}"><text x="10" y="20" fill="#888">No zones found.</text></svg>'

    parts = [f'<svg width="{width}" height="{height}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg" font-family="system-ui, sans-serif">']
    parts.append(f'<rect x="0" y="0" width="{width}" height="{height}" fill="none" stroke="#ccc" stroke-width="2"/>')
    for z in zones:
        x, y, w, h = z["rect"]
        px = x / SPACE * width
        py = y / SPACE * height
        pw = max(w / SPACE * width, 1)
        ph = max(h / SPACE * height, 1)
        fill, stroke = _KIND_COLORS.get(z["kind"], ("#f3f4f6", "#374151"))
        parts.append(
            f'<rect x="{px:.1f}" y="{py:.1f}" width="{pw:.1f}" height="{ph:.1f}" '
            f'fill="{fill}" stroke="{stroke}" stroke-width="1.5" rx="4"/>'
        )
        label = z["label"]
        if len(label) > 42:
            label = label[:39] + "..."
        tx, ty = px + 6, py + 16
        parts.append(f'<text x="{tx:.1f}" y="{ty:.1f}" font-size="12" fill="{stroke}">{_escape(label)}</text>')
    parts.append("</svg>")
    return "\n".join(parts)


def _escape(s: str) -> str:
    return (
        s.replace("&", "&amp;")
        .replace("<", "&lt;")
        .replace(">", "&gt;")
        .replace('"', "&quot;")
    )


def worksheet_shelves(root: ET.Element, worksheet_name: str) -> dict:
    """Best-effort plain summary of a worksheet's shelves/encodings, parsed
    from its <table><view> XML - not a render, just what's wired to what."""
    ws = None
    for w in root.findall("./worksheets/worksheet"):
        if w.get("name") == worksheet_name:
            ws = w
            break
    if ws is None:
        return {"error": f"worksheet '{worksheet_name}' not found"}

    view = ws.find("./table/view")
    result = {"rows": None, "columns": None, "encodings": {}, "mark_class": None}
    if view is None:
        return result

    rows_el = view.find("rows")
    cols_el = view.find("cols")
    result["rows"] = rows_el.text if rows_el is not None else None
    result["columns"] = cols_el.text if cols_el is not None else None

    mark = ws.find(".//mark")
    if mark is not None:
        result["mark_class"] = mark.get("class")

    # Encodings can live under <table><view><encodings> or nested inside a
    # <panes><pane><encodings> - collect from every occurrence, same approach
    # server.py's _worksheet_color_field uses (ws_el.iter("encodings")).
    for encodings in ws.iter("encodings"):
        for enc in encodings:
            if enc.get("column"):
                result["encodings"].setdefault(enc.tag, enc.get("column"))

    return result
