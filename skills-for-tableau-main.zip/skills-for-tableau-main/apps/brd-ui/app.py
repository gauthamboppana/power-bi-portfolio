"""
Tableau BRD -> Workbook Agent (Streamlit UI)

Upload LookML + a Looker dashboard PDF + a blank starter workbook (.twb/
.twbx), click one button, and the app: extracts the LookML, generates a
BRD.md, then automatically drives the same build agent the chat interface
exposes to construct the data source, worksheets, and dashboard directly
into the uploaded workbook - no manual chat steps required for the happy
path. If the agent hits a genuinely blocking question, it pauses and asks
in the chat at the bottom of the page; answer there to let it continue.

Run locally:   streamlit run app.py
Deploy:        push this repo to GitHub, point Streamlit Community Cloud at
               it (share.streamlit.io) - no local filesystem access needed,
               since everything here works on uploaded files.

What this does NOT do: render/export images from Tableau Desktop (no API for
that - see the parent repo's README) or publish to Server/Cloud (Phase 2).
"""

import importlib.util
import io
import json
import sys
import tempfile
from pathlib import Path

import streamlit as st

from tools_schema import TOOLS
import preview
import lookml_extract
import brd_generator

# --------------------------------------------------------------------------
# Load server.py's functions directly (no MCP protocol involved here) -
# these are the exact same tool implementations the Claude Code plugin uses.
# --------------------------------------------------------------------------
REPO_ROOT = Path(__file__).resolve().parent.parent.parent  # apps/brd-ui -> repo root
SERVER_PY = REPO_ROOT / "mcp-server" / "server.py"
TEMPLATES_DIR_DEFAULT = str(REPO_ROOT / "chart-library" / "templates")

MAX_TOOL_ROUNDS = 40  # per agent turn - raised from 15 so a full dashboard
                       # build (datasource + several worksheets + layout +
                       # actions) can usually finish in one go.

# --------------------------------------------------------------------------
# Local settings persistence - by explicit user choice this includes the
# Anthropic API key in plaintext in a local file next to this script. That's
# a real tradeoff (anyone with file access on this machine, or a backup/sync
# of this folder, can read it) - .gitignore excludes it from the repo, but
# nothing stops it living on disk otherwise. Everything else here (model,
# template path, connection defaults) is non-secret.
# --------------------------------------------------------------------------
SETTINGS_FILE = Path(__file__).resolve().parent / ".ui_settings.json"
SETTINGS_KEYS = [
    "api_key", "model", "templates_dir", "output_dir",
    "ds_platform", "ds_server", "ds_database", "ds_schema", "ds_warehouse", "ds_username", "ds_password", "ds_excel_path",
]
SETTINGS_DEFAULTS = {
    "api_key": "", "model": "claude-sonnet-4-5", "templates_dir": TEMPLATES_DIR_DEFAULT, "output_dir": "",
    "ds_platform": "snowflake", "ds_server": "", "ds_database": "", "ds_schema": "public",
    "ds_warehouse": "", "ds_username": "", "ds_password": "", "ds_excel_path": "",
}


def load_settings() -> dict:
    if SETTINGS_FILE.exists():
        try:
            return json.loads(SETTINGS_FILE.read_text())
        except Exception:  # noqa: BLE001 - a corrupt/unreadable settings file shouldn't crash the app
            return {}
    return {}


def save_settings() -> None:
    try:
        SETTINGS_FILE.write_text(json.dumps({k: st.session_state.get(k, "") for k in SETTINGS_KEYS}, indent=2))
    except Exception:  # noqa: BLE001 - best-effort; a save failure shouldn't crash the app
        pass


@st.cache_resource
def load_server_module():
    if not SERVER_PY.exists():
        st.error(
            f"Can't find server.py at {SERVER_PY}. This app expects to sit "
            "inside the skills-for-tableau repo "
            "checkout (<repo>/mcp-server/server.py)."
        )
        st.stop()
    spec = importlib.util.spec_from_file_location("tableau_server", SERVER_PY)
    module = importlib.util.module_from_spec(spec)
    sys.modules["tableau_server"] = module
    spec.loader.exec_module(module)
    return module


server = load_server_module()

TOOL_FUNCTIONS = {t["name"]: getattr(server, t["name"]) for t in TOOLS if hasattr(server, t["name"])}

# Prompt caching: marking the LAST tool schema with cache_control caches the
# whole tools array as a prefix (all schemas, since they're static and
# repeat unchanged on every turn of a conversation). Built once at import
# time since TOOLS never changes at runtime.
TOOLS_CACHED = [dict(t) for t in TOOLS]
TOOLS_CACHED[-1] = {**TOOLS_CACHED[-1], "cache_control": {"type": "ephemeral"}}

SYSTEM_PROMPT = """You are a Tableau Desktop authoring agent. You build directly into a real, already-existing .twb/.twbx workbook using the tools available to you - you never fabricate XML by hand, and you never invent a field that doesn't already exist in the workbook (call inspect_workbook first, and re-check with it whenever you're unsure).

The workbook you are building into is at: {workbook_path}
The chart template/recipe library (if the user wants a recipe-matched chart) is at: {templates_dir}
{connection_block}
{brd_block}
Ground rules:
- You are usually run in an AUTOMATIC build mode: given a BRD, build the complete data source (if needed), every worksheet, and the full dashboard in one continuous pass, without pausing to ask the user to confirm each individual step. Only stop and ask a question when something is genuinely blocking (missing/ambiguous connection info, a field the BRD doesn't specify, an ordering conflict) - never ask permission to proceed with what the BRD already states.
- Ask ONE clarifying question at a time when something is genuinely ambiguous - never a multi-part questionnaire. If the BRD above already answers it, don't ask.
- Inspect before you build: call inspect_workbook (and list_calculated_fields) before proposing fields, chart types, or calculations, so everything you plan is grounded in what the data source actually has.
- A field_mapping value must be a field's real internal name (or caption) as inspect_workbook/list_calculated_fields actually shows it - never a Tableau Desktop UI auto-generated label like "<table/datasource name> (Count)" or "<field> (copy)". Those are display conveniences Desktop shows in its own field list; they are not real fields and instantiate_chart_recipe will correctly reject them as not found. If the BRD calls for a plain row-count measure and no count field already exists in the datasource, create one first (e.g. as a calculated field, COUNT([some_key_column]) or similar - or add it via create_datasource's fields list up front) and reference that real field's name, rather than guessing at a UI label.
- If inspect_workbook shows zero data sources, the workbook truly has no connection yet - call create_datasource FIRST, before anything else. Use the connection defaults above for server/database/schema/warehouse/username/excel_path if the platform matches; never invent connection details that aren't given to you. Only pass `password` to create_datasource if a password is explicitly given above - if none is given, don't pass one (Tableau Desktop prompts for it on open, the verified-safe default); if one IS given, pass it, but that specific attribute isn't verified against a real captured file the way the rest of the connection shape is, so say so plainly when you report what you built. Base the `fields` list you pass on the BRD's data model section (or on the LookML views/explores) - map each Looker dimension/measure to its real remote column name and the closest Tableau datatype, don't invent fields that aren't in the source.
- Build EVERY tile the BRD's dashboard section lists as its own separate instantiate_chart_recipe call, with that tile's own field_mapping and title - never reuse one tile's exact build for another tile, even when several tiles share the same chart type. Two tiles that look structurally similar (e.g. three column charts, each filtered to a different status value) still need three separate instantiate_chart_recipe calls.
- instantiate_chart_recipe's field_mapping only substitutes fields into shelf/encoding slots the template already has - it has no filter concept of its own. Whenever the BRD says a tile is restricted to a specific value of some field (e.g. "where data_state = X", a status column, a category) - even a value that isn't one of the template's mapped fields - call add_worksheet_filter on that worksheet right after instantiate_chart_recipe, with that tile's own filter field/value(s), using the EXACT literal value(s) the BRD gives (copy them verbatim - these often look like enum/constant strings such as `MISSING_IN_TRANSACTION_FACT_PENDING_JMS_EVENT_3_OR_MORE_HOURS`, not a human-friendly label). This is the ONLY way tile-specific filters get applied; skipping it for tiles that are supposed to differ only by filter value is exactly what produces multiple worksheets with different names/titles but numerically identical data - a well-known past failure mode here. add_worksheet_filter currently only supports exact-match string/boolean dimension filters; a relative-date filter the BRD calls out (e.g. "last 72 hours") has no automated tool yet - say so as a gap needing manual Desktop follow-up rather than building an unfiltered copy or silently approximating it a different way.
- If the BRD's "Calculated fields" section lists a field (ported from a Looker `dynamic_fields` expression), create it with add_calculated_field BEFORE building any worksheet that uses it - it does not exist in the data source yet no matter how real the BRD's formula looks. Build it once even if several tiles use it (don't recreate a duplicate per tile). Then reference it by name like any other field in field_mapping, filters, or add_worksheet_filter.
- When the BRD annotates a tile's date/time field with a specific granularity (e.g. "create_hour, truncated to Hour"), that granularity must actually land on the shelf - if the chart template's own field_slot substitutes your field in at a different derivation (e.g. the template was built with a Year/Quarter pivot and your field_mapping only swaps the field name, not the truncation level), the resulting chart will look built but show the wrong grain. Check the instantiated worksheet's rows/cols against what the BRD asked for; if the recipe library has no template at the right granularity and you have no tool to change a shelf's date part after instantiation, say so as a gap explicitly (don't report the tile done if its date grain doesn't match the BRD).
- When the BRD names a specific "Tableau template" for a tile (e.g. "Bar__Columns_"), use that exact template - call list_chart_templates and match the name precisely; never substitute a similarly-named template (e.g. "Bar (Side By Side)" is a different chart shape from "Bar (Columns)" despite the similar name - a wrong-but-similar template produces a wrong chart, not an approximation). If generate_chart_recipe returns a tokenization_warning for the named template, the template needs review before use - say so plainly rather than picking a different unreviewed template as a workaround. If the BRD's tile is a table/crosstab (`looker_grid`, or its Tableau template is explicitly "none"), build it with build_crosstab_worksheet instead of instantiate_chart_recipe - that tool builds a plain rows/cols/text-measure table directly, with no chart-recipe template involved (chart recipes are for actual charts and have no table equivalent, so never force a table into one or silently substitute some chart type instead of a table). It produces a plain, unstyled table - matching a source table's exact visual polish (custom fonts/colors/heatmap-style cell shading) is still a manual Desktop step, worth noting when you report the tile done.
- For a dashboard, EVERY worksheet you build for a BRD tile must end up placed in the dashboard via instantiate_dashboard_layout's `layout` - a worksheet built but left off the dashboard is a half-finished tile, not a completed one. Before reporting the dashboard done, count: does `layout` include every worksheet you built for this dashboard (other than tiles you explicitly flagged as gaps, e.g. tables with no chart-recipe path)? If not, that's not done yet - keep building rather than stopping with orphaned worksheets.
- When the BRD above describes a migrated dashboard (e.g. from Looker), it includes an ordering table of tiles (row/col/width, or an explicit "Order" column). Match that ordering when you call instantiate_dashboard_layout: build the `layout` rows in the same top-to-bottom order as the source, and reproduce the source's row/column grouping (tiles the source places side-by-side in the same row go in the same `layout` row; tiles the source stacks full-width each get their own `layout` row). Do not re-order or re-group tiles based on your own judgment of what looks better - the goal is a faithful recreation, not a redesign. If the BRD's ordering is ambiguous or missing, ask rather than guessing.
- Name the dashboard (and worksheets) after the source Looker dashboard/tile names given in the BRD - don't invent different names. If a name collides with something already in the workbook (e.g. rebuilding into a workbook that already has a same-named dashboard from a previous run), instantiate_dashboard_layout and instantiate_chart_recipe do NOT fail on that - they auto-rename to a free variant (" 2", " 3", ...) and return the actual name used in `dashboard_name`/`worksheet_name`. Always use that returned name (not the one you requested) in any later step that references it (placing a worksheet into a layout, wiring an add_dashboard_action). Only ask the user for a different name if something else about the request is genuinely ambiguous - a plain name collision is not a reason to stop and ask.
- After every edit, call validate_workbook and report the result plainly - don't claim something is done if validation failed.
- You cannot render or export images from Tableau Desktop (no API for that) and cannot publish to Server/Cloud - say so plainly if asked, rather than guessing at a workaround.
- Keep responses concise and concrete: what you built, into which worksheet/dashboard, and what (if anything) still needs the user's input or Desktop's manual UI.
"""


def build_system_prompt(workbook_path: str, templates_dir: str, brd_text: str, connection_defaults: dict = None) -> list:
    """Returns the system prompt as a cache-marked content block list (not a
    plain string) - cache_control on this block lets the API cache the whole
    system prompt (including the BRD text, which can be long) as a prefix, so
    it's billed at a fraction of the normal input-token price and re-read
    faster on every turn after the first, instead of being re-processed in
    full on every single message of the conversation."""
    brd_block = ""
    if brd_text:
        brd_block = f"\nThe user's BRD (business requirements document) follows - read it before asking anything it already answers:\n---BRD START---\n{brd_text}\n---BRD END---\n"
    connection_block = ""
    cd = connection_defaults or {}
    if cd.get("platform"):
        lines = [f"Data source connection defaults (from Settings - use these for create_datasource unless the user says otherwise):",
                 f"  platform: {cd.get('platform')}"]
        for label, key in (("server", "server"), ("database", "database"), ("schema", "schema"), ("warehouse", "warehouse"), ("username", "username"), ("password", "password"), ("excel_path", "excel_path")):
            if cd.get(key):
                lines.append(f"  {label}: {cd[key]}")
        connection_block = "\n" + "\n".join(lines) + "\n"
    text = SYSTEM_PROMPT.format(workbook_path=workbook_path, templates_dir=templates_dir, brd_block=brd_block, connection_block=connection_block)
    return [{"type": "text", "text": text, "cache_control": {"type": "ephemeral"}}]


def extract_text(uploaded_file) -> str:
    name = uploaded_file.name.lower()
    data = uploaded_file.getvalue()
    if name.endswith((".txt", ".md")):
        return data.decode("utf-8", errors="ignore")
    if name.endswith(".docx"):
        try:
            import docx
        except ImportError:
            return "[Could not read .docx - python-docx not installed]"
        doc = docx.Document(io.BytesIO(data))
        return "\n".join(p.text for p in doc.paragraphs)
    if name.endswith(".pdf"):
        try:
            from pypdf import PdfReader
        except ImportError:
            return "[Could not read .pdf - pypdf not installed]"
        reader = PdfReader(io.BytesIO(data))
        return "\n".join((page.extract_text() or "") for page in reader.pages)
    return data.decode("utf-8", errors="ignore")


# Tools that write into the workbook, and the parameter name each one takes
# the workbook path under (add_calculated_field/edit_calculated_field predate
# the workbook_path naming convention and still use `path`). Every one of
# these gets validate_workbook run automatically right after it, in Python -
# not left to the model to remember, per the system prompt's "after every
# edit, call validate_workbook" rule, which was previously just a request the
# model could forget or skip.
MUTATING_TOOLS = {
    "add_calculated_field": "path",
    "edit_calculated_field": "path",
    "create_datasource": "workbook_path",
    "instantiate_chart_recipe": "workbook_path",
    "add_worksheet_filter": "workbook_path",
    "build_crosstab_worksheet": "workbook_path",
    "instantiate_dashboard_layout": "workbook_path",
    "add_parameter": "workbook_path",
    "instantiate_lod_calculation": "workbook_path",
    "add_dashboard_action": "workbook_path",
}


def run_tool(name: str, tool_input: dict) -> dict:
    fn = TOOL_FUNCTIONS.get(name)
    if fn is None:
        return {"ok": False, "error": f"Unknown tool '{name}'"}
    try:
        result = fn(**tool_input)
    except TypeError as e:
        return {"ok": False, "error": f"Bad arguments for {name}: {e}"}
    except Exception as e:  # noqa: BLE001 - surface any tool failure to the chat, don't crash the app
        return {"ok": False, "error": f"{type(e).__name__}: {e}"}

    path_param = MUTATING_TOOLS.get(name)
    if path_param and result.get("ok"):
        workbook_path = tool_input.get(path_param)
        try:
            validation = server.validate_workbook(workbook_path) if workbook_path else {"ok": False, "error": "no workbook path in tool input"}
        except Exception as e:  # noqa: BLE001
            validation = {"ok": False, "error": f"{type(e).__name__}: {e}"}
        result["post_edit_validation"] = validation
        if not validation.get("passed", True):
            # Force this through as a tool error (is_error: true) rather than
            # a quiet note the model might skim past - the edit wrote
            # something, but the workbook doesn't validate, so treat the step
            # as unfinished until that's addressed.
            result["ok"] = False
            result["error"] = "Auto-validation after this edit failed - see post_edit_validation.issues. Fix before continuing."

    return result


# (tool name -> short label, and which input key names the thing it acted
# on) used to turn a raw tool call into one "key update" line instead of
# dumping the model's full narration + every tool call/result in the chat -
# per explicit feedback that the transcript was too noisy.
_TOOL_SUMMARY = {
    "create_datasource": ("Created data source", "datasource_name"),
    "instantiate_chart_recipe": ("Built worksheet", "new_worksheet_name"),
    "add_worksheet_filter": ("Filtered worksheet", "worksheet_name"),
    "build_crosstab_worksheet": ("Built table worksheet", "new_worksheet_name"),
    "instantiate_dashboard_layout": ("Assembled dashboard", "dashboard_name"),
    "add_dashboard_action": ("Added dashboard action", "action_type"),
    "add_calculated_field": ("Added calculated field", "field_name"),
    "edit_calculated_field": ("Edited calculated field", "field_name"),
    "add_parameter": ("Added parameter", "name"),
    "instantiate_lod_calculation": ("Added LOD calculation", "new_field_name"),
    "validate_workbook": ("Validated workbook", None),
}


def _summarize_tool_call(name: str, tool_input: dict) -> str:
    label, detail_key = _TOOL_SUMMARY.get(name, (name, None))
    detail = tool_input.get(detail_key) if detail_key else None
    return f"{label}: `{detail}`" if detail else label


def render_tool_call(name: str, tool_input: dict, result: dict = None):
    """One compact, collapsed line per tool call - only 'key updates'
    (mutating build actions), not routine inspection reads, unless a read
    failed too. Full input/result stay available inside the expander for
    anyone who wants to dig in."""
    is_mutating = name in MUTATING_TOOLS
    failed = result is not None and not result.get("ok", True)
    if not is_mutating and not failed:
        return  # routine inspection call that succeeded - not shown
    icon = "❌" if failed else "✅"
    with st.chat_message("assistant"):
        with st.expander(f"{icon} {_summarize_tool_call(name, tool_input)}", expanded=False):
            st.json(tool_input)
            if result is not None:
                st.json(result)


def render_transcript():
    """Redraws the full chat history from session state on every rerun.
    Only shows: user messages, the agent's final answer/question for each
    turn (text from a response that made no tool calls), and one compact
    line per key tool call (paired with its result by tool_use_id) - not
    the model's intermediate narration or routine inspection calls."""
    messages = st.session_state.messages
    results_by_id = {}
    for msg in messages:
        if msg["role"] == "user" and isinstance(msg["content"], list):
            for block in msg["content"]:
                if isinstance(block, dict) and block.get("type") == "tool_result":
                    raw = block.get("content")
                    try:
                        results_by_id[block["tool_use_id"]] = json.loads(raw) if isinstance(raw, str) else raw
                    except Exception:  # noqa: BLE001
                        results_by_id[block["tool_use_id"]] = {"raw": raw}

    for msg in messages:
        content = msg["content"]
        if isinstance(content, str):
            if msg["role"] == "user":
                with st.chat_message("user"):
                    st.markdown(content)
            continue
        if not isinstance(content, list):
            continue
        has_tool_use = any(isinstance(b, dict) and b.get("type") == "tool_use" for b in content)
        for block in content:
            if not isinstance(block, dict):
                continue
            btype = block.get("type")
            if btype == "text" and not has_tool_use and block["text"].strip():
                with st.chat_message("assistant"):
                    st.markdown(block["text"])
            elif btype == "tool_use":
                render_tool_call(block["name"], block["input"], results_by_id.get(block["id"]))


def run_agent_turn(user_text: str, api_key: str, model: str, templates_dir: str, connection_defaults: dict):
    """Runs one full agent turn: appends `user_text` as a user message, then
    loops on tool calls (same logic whether the turn was typed by the user in
    the chat box or kicked off automatically by the 'Generate & Build'
    button) until the model stops asking for tools or the round cap is hit.
    Renders everything live as it happens - this function IS the UI for a
    turn, not just the logic."""
    try:
        import anthropic
    except ImportError:
        st.error("The `anthropic` package isn't installed. Add it to requirements.txt and reinstall.")
        return

    # max_retries: the SDK retries transient failures (rate limits, momentary
    # overload/unavailability, network blips) internally with exponential
    # backoff before ever raising - 5 (up from the SDK default of 2) gives
    # more room to ride out a brief outage instead of failing the turn.
    client = anthropic.Anthropic(api_key=api_key, max_retries=5)
    system_prompt = build_system_prompt(
        st.session_state.workbook_path, templates_dir, st.session_state.brd_text, connection_defaults
    )

    st.session_state.messages.append({"role": "user", "content": user_text})
    with st.chat_message("user"):
        st.markdown(user_text)

    status = st.empty()
    for _ in range(MAX_TOOL_ROUNDS):
        status.markdown("_thinking..._")
        try:
            response = client.messages.create(
                model=model,
                max_tokens=4096,
                system=system_prompt,
                tools=TOOLS_CACHED,
                messages=st.session_state.messages,
            )
        except anthropic.APIError as e:
            # SDK-internal retries (max_retries above) are already
            # exhausted by the time we see this - a real, persistent
            # failure, not a blip. Don't corrupt session state with a
            # half-formed turn; just report it and stop this turn.
            status.empty()
            st.error(f"Claude API call failed after retries: {type(e).__name__}: {e}\n\nYour message is still in the conversation - try sending again.")
            return
        assistant_content = [block.model_dump() for block in response.content]
        st.session_state.messages.append({"role": "assistant", "content": assistant_content})

        if response.stop_reason != "tool_use":
            status.empty()
            with st.chat_message("assistant"):
                for block in assistant_content:
                    if block["type"] == "text":
                        st.markdown(block["text"])
            return

        status.empty()
        tool_results = []
        for block in assistant_content:
            if block["type"] == "tool_use":
                result = run_tool(block["name"], block["input"])
                render_tool_call(block["name"], block["input"], result)
                tool_results.append(
                    {
                        "type": "tool_result",
                        "tool_use_id": block["id"],
                        "content": json.dumps(result, default=str),
                        "is_error": not result.get("ok", True),
                    }
                )
        st.session_state.messages.append({"role": "user", "content": tool_results})
    else:
        st.session_state.hit_round_cap = True
        st.warning(f"Paused after {MAX_TOOL_ROUNDS} tool-call rounds so this doesn't run away. Click **Continue building** below, or ask a follow-up in the chat box.")


# --------------------------------------------------------------------------
# UI
# --------------------------------------------------------------------------
st.set_page_config(page_title="Tableau BRD -> Workbook Agent", page_icon="📊", layout="wide")
st.title("📊 Tableau BRD -> Workbook Agent")
st.caption(
    "Upload LookML + a Looker PDF + a blank starter workbook, click one button. The app writes a BRD.md, "
    "then builds the data source, worksheets, and dashboard straight into the workbook - no manual chat "
    "steps needed unless it hits a genuine question. Reopen the result in Tableau Desktop to check it."
)

if "work_dir" not in st.session_state:
    st.session_state.work_dir = tempfile.mkdtemp(prefix="tableau_ui_")
if "messages" not in st.session_state:
    st.session_state.messages = []  # Anthropic-format message list
if "workbook_path" not in st.session_state:
    st.session_state.workbook_path = None
if "brd_text" not in st.session_state:
    st.session_state.brd_text = ""
if "auto_build_pending" not in st.session_state:
    st.session_state.auto_build_pending = False
if "hit_round_cap" not in st.session_state:
    st.session_state.hit_round_cap = False

# Seed session_state from the saved settings file, once per browser session
# (never overwrites a value the user has already changed this session).
_saved_settings = load_settings()
for _k in SETTINGS_KEYS:
    if _k not in st.session_state:
        st.session_state[_k] = _saved_settings.get(_k, SETTINGS_DEFAULTS[_k])

with st.sidebar:
    st.header("⚙️ Settings")
    st.caption("Saved automatically to `.ui_settings.json` next to app.py, so these survive an app restart - use **Clear saved settings** below to forget them.")
    api_key = st.text_input(
        "Anthropic API key", type="password", key="api_key",
        help="Saved in plaintext in the local settings file, by your choice - anyone with access to this machine's filesystem could read it.",
    )
    model = st.selectbox("Model", ["claude-sonnet-4-5", "claude-opus-4-1", "claude-haiku-4-5"], key="model")
    templates_dir = st.text_input("Chart template library path", key="templates_dir")
    st.caption(
        "This UI can't drive Tableau Desktop's render/export step or publish to "
        "Server/Cloud - those still need a human in Desktop, same as the plugin."
    )

    st.divider()
    st.subheader("Data source connection defaults")
    st.caption(
        "Used when the agent needs to create a brand-new data source in a workbook that isn't "
        "connected yet (e.g. a truly blank starter .twb). Password is optional: leave it blank and "
        "Tableau Desktop prompts for it when the workbook is opened (the verified-safe default); "
        "fill it in and the agent will try to embed it in the connection XML too - that specific "
        "part is NOT verified against a real Desktop-saved file, so treat it as best-effort and check "
        "the result opens correctly. Either way, whatever you type here is saved locally (like the "
        "API key) and is also sent to the Anthropic API as part of the agent's context when it builds."
    )
    ds_platform = st.selectbox("Platform", ["snowflake", "postgres", "excel (live file link)", "hyper (local extract)"], key="ds_platform")
    if ds_platform.startswith("excel"):
        ds_excel_path = st.text_input(
            "Excel file path", placeholder="C:/Users/you/Downloads/Data.xlsx", key="ds_excel_path",
            help="Path on whatever machine will open the workbook - this is a live link to the file, not an upload.",
        )
        ds_server = ds_database = ds_schema = ds_warehouse = ds_username = ds_password = ""
    else:
        ds_server = st.text_input("Server", placeholder="myaccount.snowflakecomputing.com", key="ds_server")
        ds_database = st.text_input("Database", key="ds_database")
        ds_schema = st.text_input("Schema", key="ds_schema")
        ds_warehouse = st.text_input("Warehouse (Snowflake only)", key="ds_warehouse")
        ds_username = st.text_input("Username", key="ds_username")
        ds_password = st.text_input(
            "Password (optional)", type="password", key="ds_password",
            help="Leave blank for the verified-safe default (Desktop prompts on open). See caption above for the tradeoff if you fill it in.",
        )
        ds_excel_path = ""

    connection_defaults = {
        "platform": "hyper" if ds_platform.startswith("hyper") else ("excel" if ds_platform.startswith("excel") else ds_platform),
        "server": ds_server,
        "database": ds_database,
        "schema": ds_schema,
        "warehouse": ds_warehouse,
        "username": ds_username,
        "password": ds_password,
        "excel_path": ds_excel_path,
    }

    save_settings()  # auto-save on every change too, so a crash/close doesn't lose anything

    st.divider()
    sc1, sc2 = st.columns(2)
    with sc1:
        if st.button("💾 Save settings", use_container_width=True):
            save_settings()
            st.toast("Settings saved.", icon="💾")
    with sc2:
        if st.button("🗑️ Clear saved settings", use_container_width=True):
            for _k in SETTINGS_KEYS:
                st.session_state[_k] = SETTINGS_DEFAULTS[_k]
            if SETTINGS_FILE.exists():
                SETTINGS_FILE.unlink()
            st.rerun()


work_dir = Path(st.session_state.work_dir)

# --------------------------------------------------------------------------
# Step 1: uploads
# --------------------------------------------------------------------------
st.subheader("1. Upload your files")
up1, up2, up3 = st.columns(3)
with up1:
    workbook_upload = st.file_uploader("Starter workbook (.twb/.twbx)", type=["twb", "twbx"])
    st.caption(
        "⚠️ 'Blank' means no worksheets/dashboards yet. It can already be connected to a data source "
        "in Desktop, or left unconnected if Settings' connection defaults are filled in - the agent "
        "will call create_datasource itself in that case."
    )
with up2:
    lookml_uploads = st.file_uploader(
        "Looker files (or a .zip of them)", type=["lkml", "lookml", "txt", "zip"], accept_multiple_files=True, key="lookml_files",
    )
    st.caption("LookML is often exported as plain `.txt` - that's fine, upload it as-is.")
with up3:
    looker_pdf_upload = st.file_uploader("Looker dashboard PDF export", type=["pdf"], key="looker_pdf")

with st.expander("Advanced: upload a BRD directly instead of generating one from LookML"):
    brd_upload = st.file_uploader("Requirements document", type=["txt", "md", "docx", "pdf"], key="brd_upload_direct")

output_dir_input = st.text_input(
    "Output folder (optional)", key="output_dir",
    placeholder="Leave blank to use a temp folder, or paste a folder path - e.g. the same one as your starter workbook",
    help="The built .twb/.twbx is written here instead of a throwaway temp folder, so you can find it "
         "next to your other files (e.g. the same folder as the starter workbook you uploaded). It's saved "
         "under a distinct name so it never overwrites your original starter file, even if you point this "
         "at the exact same folder.",
)

if workbook_upload is not None:
    upload_path = Path(workbook_upload.name)
    if st.session_state.get("output_dir", "").strip():
        out_folder = Path(st.session_state["output_dir"].strip())
        if out_folder.is_dir():
            dest = out_folder / f"{upload_path.stem}_output{upload_path.suffix}"
        else:
            st.warning(f"Output folder '{out_folder}' doesn't exist on this machine - using a temp folder instead for this run.")
            dest = work_dir / workbook_upload.name
    else:
        dest = work_dir / workbook_upload.name
    if not dest.exists() or st.session_state.get("workbook_upload_name") != workbook_upload.name or st.session_state.get("workbook_dest_path") != str(dest):
        dest.write_bytes(workbook_upload.getvalue())
        st.session_state.workbook_path = str(dest)
        st.session_state.workbook_upload_name = workbook_upload.name
        st.session_state.workbook_dest_path = str(dest)
        st.session_state.messages = []  # fresh workbook -> fresh conversation
    st.caption(f"📁 Building into: `{dest}`")

if brd_upload is not None and st.session_state.get("brd_upload_name") != brd_upload.name:
    st.session_state.brd_text = extract_text(brd_upload)
    st.session_state.brd_upload_name = brd_upload.name
    st.session_state.brd_source = f"Uploaded ({brd_upload.name})"

have_brd_inputs = bool(lookml_uploads or looker_pdf_upload) or bool(st.session_state.brd_text)
go_clicked = st.button(
    "🚀 Generate BRD & Build Dashboard",
    type="primary",
    use_container_width=True,
    disabled=not (workbook_upload and have_brd_inputs and api_key),
)
if not api_key:
    st.caption("Enter your Anthropic API key in Settings (sidebar) to enable this.")
elif not workbook_upload:
    st.caption("Upload a starter workbook above to enable this.")
elif not have_brd_inputs:
    st.caption("Upload LookML and/or a Looker PDF above (or a BRD directly, in Advanced) to enable this.")

if go_clicked:
    if not st.session_state.brd_text or lookml_uploads or looker_pdf_upload:
        # No Python-side LookML parsing here - files are just decoded to raw
        # text (and zips expanded); the BRD agent below reads and interprets
        # the LookML/YAML content itself via tools. zip_skipped only covers
        # zip-handling failures (a corrupt zip, an undecodable member), not
        # LookML content issues - there's no longer a content-parse step to
        # fail.
        expanded_files, zip_skipped = lookml_extract.expand_lookml_uploads(lookml_uploads)
        st.session_state.looker_skipped_files = zip_skipped
        st.session_state.looker_uploaded_filenames = [name for name, _text in expanded_files]

        with st.spinner("Generating BRD..."):
            status = st.empty()
            try:
                import anthropic

                client = anthropic.Anthropic(api_key=api_key, max_retries=5)
                pdf_bytes = looker_pdf_upload.getvalue() if looker_pdf_upload else None
                pdf_name = looker_pdf_upload.name if looker_pdf_upload else None
                # Agentic: the model gets tools to list and read the raw
                # LookML files itself and works through them in a loop,
                # parsing/interpreting the LookML/YAML content directly -
                # same tool-use pattern the Tableau build agent uses.
                generated = brd_generator.generate_brd_agentic(
                    client, model, expanded_files, pdf_bytes, pdf_name,
                    on_step=lambda msg: status.markdown(f"_{msg}_"),
                )
                status.empty()
                st.session_state.brd_text = generated
                st.session_state.brd_source = "Generated from Looker (agentic)"
            except Exception as e:  # noqa: BLE001
                status.empty()
                st.error(f"BRD generation failed: {type(e).__name__}: {e}")
                st.session_state.brd_text = ""

    if st.session_state.brd_text:
        st.session_state.messages = []  # fresh BRD -> fresh build conversation
        st.session_state.hit_round_cap = False
        st.session_state.auto_build_pending = True

if st.session_state.get("looker_skipped_files"):
    with st.expander(f"⚠️ {len(st.session_state.looker_skipped_files)} file(s) skipped (zip issue)", expanded=False):
        for u in st.session_state.looker_skipped_files:
            st.text(f"{u['filename']}: {u['error']}")

# --------------------------------------------------------------------------
# Step 2: downloads (shown once each is ready; workbook download always
# reflects the current on-disk state, so it updates as the build progresses)
# --------------------------------------------------------------------------
st.subheader("2. Downloads")
dl1, dl2 = st.columns(2)
with dl1:
    if st.session_state.brd_text:
        st.download_button(
            "⬇️ Download BRD.md",
            data=st.session_state.brd_text,
            file_name="brd.md",
            mime="text/markdown",
            use_container_width=True,
        )
    else:
        st.caption("BRD not generated yet.")
with dl2:
    if st.session_state.workbook_path:
        current_bytes = Path(st.session_state.workbook_path).read_bytes()
        st.download_button(
            "⬇️ Download Tableau workbook",
            data=current_bytes,
            file_name=Path(st.session_state.workbook_path).name,
            use_container_width=True,
        )
    else:
        st.caption("Upload a starter workbook first.")

with st.expander("BRD text / uploaded LookML files", expanded=False):
    if st.session_state.brd_text:
        st.caption(f"Source: {st.session_state.get('brd_source', 'Uploaded')}")
        st.markdown(st.session_state.brd_text)
    if st.session_state.get("looker_uploaded_filenames"):
        st.divider()
        st.caption("LookML files the BRD agent read directly (no pre-parsing) to build the BRD above:")
        for _fn in st.session_state.looker_uploaded_filenames:
            st.text(f"- {_fn}")

# --------------------------------------------------------------------------
# Step 3: preview + available tools (secondary detail, collapsed by default)
# --------------------------------------------------------------------------
if st.session_state.workbook_path:
    with st.expander("Preview (structural, not a pixel render) & available tools", expanded=False):
        st.caption(
            "Not a pixel render (no headless render API exists for Tableau Desktop) - "
            "a structural wireframe from the same zone geometry the tools write, plus "
            "a spot for the one real export once you do it manually."
        )
        try:
            inspection = server.inspect_workbook(st.session_state.workbook_path)
        except Exception as e:  # noqa: BLE001
            inspection = {"ok": False, "error": str(e)}

        if not inspection.get("ok"):
            st.warning(f"Couldn't inspect workbook: {inspection.get('error', 'unknown error')}")
        else:
            dashboards = [d["name"] for d in inspection.get("dashboards", [])]
            worksheets = [w["name"] for w in inspection.get("worksheets", [])]

            tab_dash, tab_ws, tab_render, tab_tools = st.tabs(["Dashboard layout", "Worksheet shelves", "Manual render", "Available tools"])

            with tab_dash:
                if not dashboards:
                    st.caption("No dashboards built yet.")
                else:
                    chosen_dash = st.selectbox("Dashboard", dashboards, key="preview_dash")
                    tree, _, _ = server.load_workbook_xml(st.session_state.workbook_path)
                    zones = preview.collect_dashboard_zones(tree.getroot(), chosen_dash)
                    if zones is None:
                        st.warning("Dashboard not found - it may have just changed. Refresh by sending another chat message.")
                    else:
                        svg = preview.dashboard_wireframe_svg(zones)
                        st.markdown(f'<div>{svg}</div>', unsafe_allow_html=True)
                        with st.expander("Zone detail", expanded=False):
                            st.json(zones)

            with tab_ws:
                if not worksheets:
                    st.caption("No worksheets built yet.")
                else:
                    chosen_ws = st.selectbox("Worksheet", worksheets, key="preview_ws")
                    tree, _, _ = server.load_workbook_xml(st.session_state.workbook_path)
                    shelves = preview.worksheet_shelves(tree.getroot(), chosen_ws)
                    st.json(shelves)

            with tab_render:
                st.caption(
                    "The real render step still needs Tableau Desktop - there's no API for it. "
                    "This registers the request and gives the exported image somewhere to land."
                )
                renders_dir = str(work_dir / "_renders")
                target_options = dashboards + worksheets
                if target_options:
                    target_name = st.selectbox("Target to render", target_options, key="render_target")
                    if st.button("Request render"):
                        req = server.request_render(st.session_state.workbook_path, target_name, renders_dir)
                        st.session_state["last_render_request"] = req
                    if st.session_state.get("last_render_request"):
                        st.json(st.session_state["last_render_request"])
                        st.markdown(
                            "**Next:** reopen the downloaded workbook in Tableau Desktop, open this "
                            "worksheet/dashboard, export the image (File > Export Image), then drop it below."
                        )
                    exported = st.file_uploader("Drop the exported image here", type=["png", "jpg", "jpeg"], key="render_upload")
                    if exported is not None:
                        incoming = work_dir / "_renders" / "incoming"
                        incoming.mkdir(parents=True, exist_ok=True)
                        img_path = incoming / exported.name
                        img_path.write_bytes(exported.getvalue())
                        check = server.check_render(str(img_path))
                        st.image(str(img_path), caption=f"{target_name} (as exported)", use_container_width=True)
                        st.json(check)
                else:
                    st.caption("Build a worksheet or dashboard first.")

            with tab_tools:
                for t in TOOLS:
                    st.markdown(f"**{t['name']}** - {t['description']}")

# --------------------------------------------------------------------------
# Step 4: chat transcript + automatic build trigger
# --------------------------------------------------------------------------
st.divider()
st.subheader("3. Chat")
st.caption("The automatic build runs here too, so you can see exactly what it did. Answer any question it asks below.")

render_transcript()

if st.session_state.workbook_path and st.session_state.auto_build_pending:
    st.session_state.auto_build_pending = False
    kickoff = (
        "Build the complete Tableau dashboard described in the BRD above, end to end, in one continuous pass: "
        "create the data source first if the workbook doesn't have one yet (using the connection defaults), "
        "then build every worksheet the BRD's dashboard section lists, then assemble them into the dashboard "
        "matching the BRD's ordering exactly, then wire up any dashboard-level filters/actions it describes. "
        "Don't pause to ask for confirmation between steps - only ask if something is genuinely missing or "
        "ambiguous. Report what you built when done."
    )
    run_agent_turn(kickoff, api_key, model, templates_dir, connection_defaults)

if st.session_state.hit_round_cap and st.session_state.workbook_path:
    if st.button("▶️ Continue building"):
        st.session_state.hit_round_cap = False
        run_agent_turn("Continue.", api_key, model, templates_dir, connection_defaults)

# Must be a top-level call (not nested in a column/expander) - that's what
# makes it float to the bottom of the page and reliably accept typed input.
prompt = st.chat_input("Answer the agent's question, or ask for a follow-up change...", disabled=not st.session_state.workbook_path)
if prompt:
    if not api_key:
        st.error("Enter your Anthropic API key in Settings (sidebar) first.")
    else:
        run_agent_turn(prompt, api_key, model, templates_dir, connection_defaults)
