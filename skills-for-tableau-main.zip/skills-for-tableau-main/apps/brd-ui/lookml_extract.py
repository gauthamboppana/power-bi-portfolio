"""
LookML file handling for the Looker -> Tableau migration front end.

This module does NOT parse or interpret LookML/YAML content - it only
handles getting uploaded files (including zips of them) into plain
(filename, text) pairs. Actually reading and understanding the LookML
(dimensions, measures, joins, dashboard tiles) is done by the BRD-generation
agent itself, directly from this raw text - see brd_generator.py's
SYSTEM_PROMPT and its read_lookml_file tool. There is deliberately
no Python-side lkml/PyYAML parsing step here: LookML is heterogeneous
enough across Looker projects (brace-syntax views/explores/models vs.
YAML-ish dashboards, real-world quirks in either) that a general LLM reading
it directly is more robust than a brittle grammar parser that hard-fails
the whole file on one unexpected token - which is exactly the class of
problem a deterministic parser kept running into here.
"""

import io
import zipfile

LOOKML_EXTENSIONS = (".lkml", ".lookml", ".txt")


def expand_lookml_uploads(uploads) -> tuple:
    """Takes the list of Streamlit UploadedFile objects from the LookML
    uploader (which accepts .lkml/.lookml/.txt files AND .zip archives of
    them) and flattens it into a list of (filename, text) pairs - the raw
    material handed to the BRD agent, unparsed - plus a list of any
    skipped/unreadable zip members.

    A zip is expanded in-memory - members are matched by extension
    (LOOKML_EXTENSIONS), macOS resource-fork junk (__MACOSX/, files starting
    with "._") and directory entries are silently skipped, and each member's
    bytes are decoded as UTF-8 the same way a directly-uploaded file is.
    Nested zips are not expanded (not a real LookML export shape).
    """
    files = []
    skipped = []
    for f in uploads or []:
        name_lower = f.name.lower()
        if name_lower.endswith(".zip"):
            try:
                zf = zipfile.ZipFile(io.BytesIO(f.getvalue()))
            except zipfile.BadZipFile as e:
                skipped.append({"filename": f.name, "error": f"Not a valid zip file: {e}"})
                continue
            for info in zf.infolist():
                if info.is_dir():
                    continue
                member_name = info.filename
                base = member_name.rsplit("/", 1)[-1]
                if base.startswith("._") or member_name.startswith("__MACOSX/"):
                    continue
                if not base.lower().endswith(LOOKML_EXTENSIONS):
                    continue
                try:
                    text = zf.read(info).decode("utf-8", errors="ignore")
                except Exception as e:  # noqa: BLE001
                    skipped.append({"filename": f"{f.name}:{member_name}", "error": str(e)})
                    continue
                files.append((base, text))
        else:
            files.append((f.name, f.getvalue().decode("utf-8", errors="ignore")))
    return files, skipped
