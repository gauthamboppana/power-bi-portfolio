"""
Anthropic API tool schemas mirroring the tableau-desktop MCP server's tools.

These are hand-written JSON schemas for the subset of server.py functions this
UI exposes to the chat loop. Keep in sync with mcp-server/server.py by hand -
there is no MCP protocol involved here (the Streamlit app calls the same
Python functions directly), so this file is the only place the shapes are
declared for the Claude API.
"""

TOOLS = [
    {
        "name": "inspect_workbook",
        "description": "Inspect a .twb/.twbx workbook: data sources, fields (dimensions/measures/calcs), worksheets, dashboards. Call this first on any workbook before planning fields or charts.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "Path to the .twb/.twbx file"}},
            "required": ["path"],
        },
    },
    {
        "name": "list_calculated_fields",
        "description": "List existing calculated fields on a workbook (optionally scoped to one data source).",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "datasource_name": {"type": "string", "description": "Optional: internal datasource name to scope to"},
            },
            "required": ["path"],
        },
    },
    {
        "name": "add_calculated_field",
        "description": "Add a new calculated field to a data source (hand-written Tableau formula). Backs up the workbook first.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "datasource_name": {"type": "string"},
                "field_name": {"type": "string"},
                "formula": {"type": "string"},
                "caption": {"type": "string"},
                "datatype": {"type": "string", "enum": ["string", "integer", "real", "boolean", "date", "datetime"]},
                "role": {"type": "string", "enum": ["dimension", "measure"]},
            },
            "required": ["path", "datasource_name", "field_name", "formula"],
        },
    },
    {
        "name": "edit_calculated_field",
        "description": "Change an existing calculated field's formula.",
        "input_schema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "datasource_name": {"type": "string"},
                "field_name": {"type": "string"},
                "new_formula": {"type": "string"},
            },
            "required": ["path", "datasource_name", "field_name", "new_formula"],
        },
    },
    {
        "name": "create_datasource",
        "description": (
            "Add a brand-new data source (a live Snowflake/Postgres connection, a live Excel connection, "
            "or a local .hyper extract) to a workbook that has none yet. Use this FIRST when inspect_workbook "
            "shows zero data sources - nothing else can be built until a data source with real fields exists. "
            "Omit password unless the user explicitly provided one; the verified-safe default is to let "
            "Tableau Desktop prompt for it on open. Connection details (server/"
            "database/schema/warehouse/username/password, or the excel file path) come from what the user "
            "configured in the Config tab - use those values rather than asking the user to repeat them in "
            "chat, unless they're missing."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "datasource_name": {"type": "string", "description": "Internal name for this data source, e.g. 'client_dimension'"},
                "platform": {"type": "string", "enum": ["snowflake", "postgres", "excel", "hyper"]},
                "fields": {
                    "type": "array",
                    "description": "Every field to expose from this data source.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "name": {"type": "string"},
                            "remote_name": {"type": "string", "description": "Actual column name in the source table/query/sheet, if different from name"},
                            "datatype": {"type": "string", "enum": ["string", "integer", "real", "boolean", "date", "datetime"]},
                            "role": {"type": "string", "enum": ["dimension", "measure"]},
                            "caption": {"type": "string"},
                        },
                        "required": ["name", "datatype"],
                    },
                },
                "caption": {"type": "string"},
                "server": {"type": "string", "description": "Required for snowflake/postgres"},
                "database": {"type": "string", "description": "Required for snowflake/postgres"},
                "schema": {"type": "string", "description": "Schema name, snowflake/postgres only (default 'public')"},
                "warehouse": {"type": "string", "description": "Required for snowflake"},
                "username": {"type": "string"},
                "password": {"type": "string", "description": "Optional, snowflake/postgres only. Omit unless the user explicitly gave one - the verified-safe default is to leave this out and let Tableau Desktop prompt for it on open. If given, it gets embedded in the connection XML, which is NOT verified against a real captured file (unlike the rest of the connection shape) - say so when reporting what you built."},
                "table_name": {"type": "string", "description": "Schema-qualified table, e.g. 'REPORTING.CLIENT_DIMENSION' - exactly one of table_name/custom_sql required for snowflake/postgres"},
                "custom_sql": {"type": "string", "description": "A full SELECT statement - exactly one of table_name/custom_sql required for snowflake/postgres"},
                "hyper_path": {"type": "string", "description": "Path to an existing .hyper file - required for platform='hyper'"},
                "hyper_table_name": {"type": "string", "description": "Table name inside the .hyper file (default 'Extract')"},
                "excel_path": {"type": "string", "description": "Path to the .xlsx file (on whatever machine opens the workbook) - required for platform='excel'"},
                "excel_sheet_name": {"type": "string", "description": "Worksheet/tab name inside the Excel file, without a trailing '$' - required for platform='excel'"},
            },
            "required": ["workbook_path", "datasource_name", "platform", "fields"],
        },
    },
    {
        "name": "validate_workbook",
        "description": "Structural validation of the workbook XML (well-formedness, balanced formula syntax). Run this after every edit.",
        "input_schema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
        },
    },
    {
        "name": "list_lod_patterns",
        "description": "List the verified Level-of-Detail calculation patterns (fixed/include/exclude aggregate, average-of-group-totals, cohort-first-date) available to instantiate.",
        "input_schema": {"type": "object", "properties": {}},
    },
    {
        "name": "instantiate_lod_calculation",
        "description": "Build a real LOD calculated field from a verified pattern, substituting your own fields in place of the pattern's placeholders.",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "datasource_name": {"type": "string"},
                "pattern_name": {"type": "string"},
                "field_mapping": {"type": "object", "description": "placeholder -> real field name, e.g. {\"DIM\": \"Region\", \"MEASURE\": \"Profit\", \"AGG\": \"SUM\"}"},
                "new_field_name": {"type": "string"},
                "caption": {"type": "string"},
            },
            "required": ["workbook_path", "datasource_name", "pattern_name", "field_mapping", "new_field_name"],
        },
    },
    {
        "name": "add_parameter",
        "description": "Create a Tableau parameter. Only domain_type/datatype combos verified against real files are accepted: list+string, range+integer, range+real, any+date.",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "name": {"type": "string"},
                "domain_type": {"type": "string", "enum": ["list", "range", "any"]},
                "datatype": {"type": "string", "enum": ["string", "integer", "real", "date"]},
                "current_value": {"description": "Current value, type matching datatype"},
                "caption": {"type": "string"},
                "list_values": {"type": "array", "items": {}, "description": "Required for domain_type=list"},
                "range_min": {"description": "Required for domain_type=range"},
                "range_max": {"description": "Required for domain_type=range"},
                "range_granularity": {},
                "default_format": {"type": "string"},
            },
            "required": ["workbook_path", "name", "domain_type", "datatype", "current_value"],
        },
    },
    {
        "name": "list_chart_templates",
        "description": "List the 81-chart template library (real extracted Tableau chart XML patterns), by name.",
        "input_schema": {
            "type": "object",
            "properties": {"templates_dir": {"type": "string"}},
            "required": ["templates_dir"],
        },
    },
    {
        "name": "get_chart_template",
        "description": "Get one chart template's structural detail (mark type, shelves/encodings).",
        "input_schema": {
            "type": "object",
            "properties": {"templates_dir": {"type": "string"}, "name": {"type": "string"}},
            "required": ["templates_dir", "name"],
        },
    },
    {
        "name": "generate_chart_recipe",
        "description": "Get (or regenerate) a chart template's recipe: tokenized placeholders and the shelf/encoding role each one plays. Call this before instantiate_chart_recipe to know what field_mapping to pass.",
        "input_schema": {
            "type": "object",
            "properties": {"templates_dir": {"type": "string"}, "name": {"type": "string"}},
            "required": ["templates_dir", "name"],
        },
    },
    {
        "name": "instantiate_chart_recipe",
        "description": "Build a new worksheet directly from a chart recipe, substituting your target data source's real fields into the recipe's placeholders. Validates every mapped field exists and matches the expected role before writing. Does not attach the worksheet to a dashboard. If new_worksheet_name collides with an existing worksheet, it is auto-renamed (not rejected) - pass the chart's natural name freely and read the returned worksheet_name field for the name actually used before referencing it in a dashboard layout.",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "templates_dir": {"type": "string"},
                "recipe_name": {"type": "string"},
                "datasource_name": {"type": "string"},
                "field_mapping": {"type": "object", "description": "recipe placeholder -> real field name"},
                "new_worksheet_name": {"type": "string"},
            },
            "required": ["workbook_path", "templates_dir", "recipe_name", "datasource_name", "field_mapping", "new_worksheet_name"],
        },
    },
    {
        "name": "add_worksheet_filter",
        "description": "Bake a permanent, non-interactive exact-match filter into one worksheet (restrict it to rows where `field` is one of `values`) - NOT a dashboard quick-filter widget. Use this for the 'same chart template, one tile per category' pattern: after instantiate_chart_recipe, call this once per worksheet with that tile's own filter value(s), even if the field wasn't part of field_mapping. `field` must be an existing string/boolean dimension in the datasource; multiple `values` are OR'd together. Skipping this for tiles that should only differ by filter value produces worksheets with different names but numerically identical data.",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "worksheet_name": {"type": "string"},
                "datasource_name": {"type": "string"},
                "field": {"type": "string"},
                "values": {"type": "array", "items": {"type": "string"}, "description": "One or more literal values to match (OR'd together)"},
            },
            "required": ["workbook_path", "worksheet_name", "datasource_name", "field", "values"],
        },
    },
    {
        "name": "build_crosstab_worksheet",
        "description": "Build a plain rows/cols/text-measure crosstab table worksheet directly (mark class 'Text') - no chart-recipe template involved. This is the tool for a Looker `looker_grid` (or any plain table) tile: chart recipes are built from real charts and have no table equivalent, so never force a table into a chart template or substitute a different chart type - use this instead. rows/cols are ordered lists of bare field names (dimensions typically, nested when more than one given); text_fields is an ordered list of bare field names (usually measures) shown as text in each cell, at least one required. Every field must already exist in the datasource (create calculated fields first if needed). Auto-dedupes new_worksheet_name like instantiate_chart_recipe does - use the returned worksheet_name afterward. Builds a plain, unstyled table; call add_worksheet_filter after if the tile needs restricting to a value.",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "datasource_name": {"type": "string"},
                "new_worksheet_name": {"type": "string"},
                "rows": {"type": "array", "items": {"type": "string"}},
                "cols": {"type": "array", "items": {"type": "string"}},
                "text_fields": {"type": "array", "items": {"type": "string"}},
            },
            "required": ["workbook_path", "datasource_name", "new_worksheet_name", "rows", "cols", "text_fields"],
        },
    },
    {
        "name": "instantiate_dashboard_layout",
        "description": "Build a real <dashboard> from a grid layout of already-built worksheets, optionally with controls (legend/filter/parameter) placed below the title. If dashboard_name collides with an existing dashboard, it is auto-renamed (not rejected) - pass the source Looker dashboard's own name freely (no need to invent something different) and read the returned dashboard_name field for the name actually used before referencing it in add_dashboard_action calls.",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "dashboard_name": {"type": "string"},
                "layout": {
                    "type": "array",
                    "description": "Rows top-to-bottom; each row a list of worksheet names, or {worksheet, weight} objects for uneven column widths",
                    "items": {"type": "array"},
                },
                "title": {"type": "string"},
                "row_heights": {"type": "array", "items": {"type": "number"}},
                "controls": {
                    "type": "array",
                    "description": "Each item: {kind: legend, worksheet} | {kind: filter, worksheet, datasource_name, field} | {kind: parameter, parameter_name}",
                    "items": {"type": "object"},
                },
            },
            "required": ["workbook_path", "dashboard_name", "layout"],
        },
    },
    {
        "name": "add_dashboard_action",
        "description": "Wire a cross-sheet dashboard action. action_type: highlight (needs field_captions), url (needs url), nav (needs target_sheet), parameter (needs parameter_name+source_worksheet+source_field+agg_type+datasource_name), filter (needs target_worksheet+datasource_name+field_pairs).",
        "input_schema": {
            "type": "object",
            "properties": {
                "workbook_path": {"type": "string"},
                "dashboard_name": {"type": "string"},
                "action_type": {"type": "string", "enum": ["highlight", "url", "nav", "parameter", "filter"]},
                "caption": {"type": "string"},
                "source_worksheet": {"type": "string"},
                "target_worksheet": {"type": "string"},
                "target_sheet": {"type": "string"},
                "url": {"type": "string"},
                "field_captions": {"type": "string"},
                "datasource_name": {"type": "string"},
                "field_pairs": {"type": "array", "items": {"type": "object"}},
                "parameter_name": {"type": "string"},
                "source_field": {"type": "string"},
                "agg_type": {"type": "string", "enum": ["sum", "avg", "min", "max", "attr", "count", "countd"]},
                "auto_clear": {"type": "boolean"},
            },
            "required": ["workbook_path", "dashboard_name", "action_type", "caption"],
        },
    },
]
