# Tableau BRD -> Workbook Agent (Streamlit UI)

A chat UI on top of the same tools the `skills-for-tableau` plugin uses - for someone who wants to upload a BRD and a blank starter
workbook and talk to an agent, without using Claude Code directly.

## How it relates to the plugin

This app does **not** duplicate the plugin's logic - `app.py` imports
`../../mcp-server/server.py` directly and calls its
functions as plain Python (verified: the `@mcp.tool()` decorator returns the
original function unchanged, so this works without running an MCP server).
`tools_schema.py` is a hand-written mirror of those functions' signatures in
Anthropic API tool-schema form, since this app talks to the Claude API
directly rather than through Claude Code's tool-calling. Keep the two in sync
by hand if `server.py`'s tool signatures change.

The one thing this app cannot do that the plugin's Claude Code side can:
render/export from Tableau Desktop, or publish to Server/Cloud. Both remain
manual/Phase 2, same as documented in the parent repo's README.

## Repo layout this expects

```
<repo root>/
  mcp-server/server.py         <- imported directly by app.py
  chart-library/templates/     <- default templates_dir in the UI sidebar
  apps/brd-ui/
    app.py
    tools_schema.py
    preview.py
    lookml_extract.py
    brd_generator.py
    requirements.txt
```

`app.py` finds `server.py` through a path relative to its own location, so keep
`apps/brd-ui/` inside the repo checkout.

## Run locally

```bash
cd apps/brd-ui
pip install -r requirements.txt
streamlit run app.py
```

Paste your Anthropic API key into the sidebar (kept only in the browser
session, never written to disk). Upload a blank `.twb`/`.twbx` already
connected to your target data source, optionally a BRD file, then chat.

## Deploy on Streamlit Community Cloud

1. Push this repo to GitHub (the app needs `mcp-server/` and `chart-library/` alongside it).
2. On [share.streamlit.io](https://share.streamlit.io), point a new app at
   the repo, with `apps/brd-ui/app.py` as the entry file.
3. Add your Anthropic API key as a secret if you don't want each visitor
   pasting their own (`st.secrets["ANTHROPIC_API_KEY"]` - not currently wired
   into `app.py`; the sidebar field is the default so anyone can bring their
   own key without you managing shared billing).
4. Every push to the branch Streamlit is watching redeploys automatically.

Because the app works entirely on uploaded files (never a local path on your
machine), cloud hosting is fine here - there's no dependency on Tableau
Desktop or your filesystem until you download the result and reopen it
yourself.

## Preview panel

There's a "Preview" section under the working-file panel with three tabs. Important caveat up front: **none of this is a pixel-accurate render** - Tableau Desktop has no headless render API, so nothing outside Desktop itself can produce the real chart pixels (same limitation documented in the parent repo's README). What it gives instead:

- **Dashboard layout** - a wireframe SVG built directly from the same `x`/`y`/`w`/`h` zone geometry `instantiate_dashboard_layout` writes (`preview.py`'s `collect_dashboard_zones`/`dashboard_wireframe_svg`). Accurate to the real structure - worksheet placement, legends, filters, parameter controls - just boxes and labels instead of the actual marks. Updates immediately as the chat builds, no manual step.
- **Worksheet shelves** - a plain summary of one worksheet's mark type and rows/columns/color/size encodings, parsed from its `<table><view>` XML (`preview.py`'s `worksheet_shelves`). Tells you what's wired to what, not what it looks like.
- **Manual render** - wraps the existing `request_render`/`check_render` tools: pick a worksheet/dashboard, click "Request render" for the reopen-in-Desktop-and-export instructions, then drop the exported image back in to see it inline and get `check_render`'s corrupt/blank-image check. This is the one place the real pixels show up, and it still needs the one manual Desktop step - the panel just gives it somewhere to land instead of a separate ad hoc process.

## Reliability and cost - what's implemented

- **API retry/backoff** - the Anthropic client is constructed with `max_retries=5` (up from the SDK default of 2), which retries transient failures (rate limits, momentary overload/unavailability, network blips) internally with exponential backoff before ever raising. The chat loop also wraps the API call in `try/except anthropic.APIError` so a failure that survives all those retries shows a clean message instead of crashing the Streamlit run mid-turn.
- **Enforced post-edit validation** - every mutating tool (`add_calculated_field`, `edit_calculated_field`, `instantiate_chart_recipe`, `instantiate_dashboard_layout`, `add_parameter`, `instantiate_lod_calculation`, `add_dashboard_action`) automatically gets `validate_workbook` run right after it, in `run_tool` - not left to the model to remember from a system-prompt instruction. If validation fails, the tool call is forced to come back as an error (`is_error: true`) even though the write itself succeeded, so Claude can't quietly move on from a workbook that no longer validates.
- **Prompt caching** - the system prompt (which embeds the full BRD text) and the tool schema list both carry `cache_control: {"type": "ephemeral"}`, so a multi-turn conversation is billed at a fraction of the normal input-token price for that unchanging content after the first turn, instead of paying full price for it on every single message.

What's still not implemented (lower priority for this app's scope - see the reasoning behind that call in the conversation this was built from): no context/history trimming (a very long conversation can still grow past the window), no persisted run log, no token/cost counter shown in the UI, no streaming (the chat blocks on each API call rather than showing partial output).

## Looker -> Tableau migration: generating a BRD instead of writing one

Section "2b" in the sidebar is a second way to get a BRD, alongside uploading one directly: upload LookML files and/or a Looker dashboard PDF export, click "Extract & generate BRD," and an agent produces a `BRD.md` from them - which is then loaded into the chat exactly like an uploaded BRD would be (`tableau-report-cli` planning mode's BRD-intake rules apply the same either way).

This is a two-stage pipeline, not one LLM call blindly reading a PDF:

1. **Structured extraction (`lookml_extract.py`, no LLM involved)** - parses the actual LookML. Two different real syntaxes are in play: view/explore/model files (`.view.lkml`, `.explore.lkml`, `.model.lkml`) use LookML's brace syntax, parsed with the `lkml` package; dashboard files (`.dashboard.lookml`) are genuinely YAML, not brace-LookML, parsed with PyYAML - the extractor detects which is which by filename and falls back if that guess is wrong. Every dimension, measure, join, and dashboard tile (title, Looker viz type, fields, row/col/width/height) that comes out of this step is literal - nothing here is inferred or reworded. `LOOKER_TO_TABLEAU` in the same file maps common Looker viz types (`looker_column`, `looker_line`, `single_value`, `looker_pie`, ...) to real names in `chart-library/templates` (`Bar__Columns_`, `Line`, `KPI`, `Pie`, ...) so a match can go straight into a design contract's `matched_template` - a `looker_grid`/`table` tile has no chart-template equivalent and is flagged as needing Desktop judgment, not silently mapped to something wrong.
2. **BRD synthesis (`brd_generator.py`, one Anthropic API call)** - takes that extraction (authoritative) plus the dashboard PDF (visual reference, sent as a real PDF document content block so the model can actually look at chart types/colors/layout it shows), and writes the BRD.md. Its system prompt is explicit that LookML facts win over PDF impressions, that visual-only observations get labeled lower-confidence, and that an audience/delivery-target/field the source material doesn't state gets written as "not specified - needs confirmation," never invented.

If no dashboard LookML was uploaded (common - many teams only export the PDF), tile layout and chart type come entirely from the PDF and the generated BRD says so plainly, so the human reviewing it knows to double-check those tiles rather than trusting them at LookML-level confidence.

## What's genuinely new here vs. reused

- **Reused as-is:** every tool implementation (`inspect_workbook`,
  `add_calculated_field`, `instantiate_chart_recipe`,
  `instantiate_dashboard_layout`, `add_parameter`,
  `instantiate_lod_calculation`, `add_dashboard_action`, `validate_workbook`,
  ...) - same code, same backup-before-write/validate-after discipline.
- **New:** the tool-calling loop itself (`app.py`'s chat loop against the
  Anthropic Messages API), the tool schemas (`tools_schema.py`), the system
  prompt (a condensed version of `tableau-report-cli` (planning +
  authoring modes) + `tableau-datasource-authoring`'s rules, file
  upload/download handling, BRD text extraction (`.txt`/`.md`/`.docx`/`.pdf`),
  and the LookML-to-BRD pipeline (`lookml_extract.py` + `brd_generator.py`).
- **Not covered:** the validate -> render -> review -> fix loop's render step
  (manual export in Desktop - there's no API), Server/Cloud publish (Phase 2),
  and the qa attempt-history tracking the Claude Code side uses across
  retries (this app treats each chat as a single working session).
