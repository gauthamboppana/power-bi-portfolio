---
name: looker-to-tableau-migration
description: "Migrate Looker dashboards to Tableau: read LookML views, explores, models and YAML dashboard files (plus an optional dashboard PDF export), produce a literal, gap-honest BRD.md with the data model, translated dynamic_fields calcs, tile-by-tile chart mapping and verbatim tile filters, then hand off to tableau-report-cli planning to build the workbook. Triggers: Looker to Tableau, migrate LookML, convert Looker dashboard, lkml to twb"
metadata:
  version: 1.0.0
---

> **CRITICAL NOTES**
> 1. **Quote, never invent.** Use only field, view, explore and join names you can see in the LookML text. If unsure, list it as a gap.
> 2. LookML facts beat PDF impressions. Label anything that came only from a PDF as *"PDF-only — confirm"*.
> 3. Where the source is silent (audience, delivery, owner), write **"Not specified in Looker source — needs confirmation"**.

# Looker → Tableau Migration

```
LookML (+ PDF)  ->  BRD.md (this skill)  ->  tableau-report-cli planning  ->  datasource -> design -> authoring -> qa
```

| Step | Read |
|---|---|
| Read LookML correctly (both syntaxes, suffixes, dynamic fields, filters) | [references/reading-lookml.md](references/reading-lookml.md) |
| Map Looker viz types → Tableau recipes, and Looker concepts → Tableau | [references/mapping.md](references/mapping.md) |
| Write the BRD | [references/brd-template.md](references/brd-template.md) |

## Workflow

1. **Inventory.** List every uploaded file, including `.txt` and zipped files; they may be LookML. Read each one fully. Don't skip a file because of its name.
2. **Data model.** For each view, record dimensions, dimension_groups and measures with their Looker type → Tableau role and aggregation. For each explore, record its joins and what they imply for the Tableau data source (one table, a pre-joined `custom_sql`, or a relationship model that must be built in Desktop).
3. **Calcs.** Translate each distinct `dynamic_fields` expression once into a Tableau formula, and list the tiles that use it.
4. **Tiles.** For each dashboard element, record the title, the Looker `type` → Tableau recipe, the fields (with date granularity spelled out), the `filters:` transcribed **verbatim**, the layout (row/col/width/height) and a confidence level.
5. **Write `BRD.md`** with the template. Show it to the user and confirm the gaps.
6. **Hand off.** Start `tableau-report-cli` in `planning` mode with the BRD as input; its BRD intake pre-fills the spec from it. Data source creation follows `tableau-datasource-authoring`.

The Streamlit app in `apps/brd-ui` runs this same procedure through the Claude API, for users who don't work in an agent host.
