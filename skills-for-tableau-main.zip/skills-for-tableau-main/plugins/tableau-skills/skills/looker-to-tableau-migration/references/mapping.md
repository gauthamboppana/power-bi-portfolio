# Looker → Tableau mapping

## Viz types → chart-library recipes

| Looker `type:` | Tableau recipe | Intent |
|---|---|---|
| `looker_line` | `Line` | trend |
| `looker_column` | `Bar__Columns_` | comparison |
| `looker_bar` | `Bar__Rows_` | comparison |
| `looker_area` | `Area` | trend |
| `looker_scatter` | `Scatter_plots` | correlation |
| `single_value`, `looker_single_record` | `KPI` | single-value |
| `looker_pie` | `Pie` | composition |
| `looker_donut_multiples` | `Donut` | composition |
| `looker_waterfall` | `Waterfall` | composition |
| `looker_boxplot` | `Box_Plot` | distribution |
| `looker_bullet` | `Bullet` | single-value |
| `looker_funnel` | `Funnel` | composition |
| `looker_geo_choropleth`, `looker_map` | `Map_Basic` | geospatial |
| `looker_column_line` | `Bars___Line_Dual_Axis` | two measures |
| `looker_grid`, `table` | **none**: `build_crosstab_worksheet` | table |
| `text`, `button` | **none**: dashboard text, a Desktop step | — |

Use the exact recipe name; similar-sounding recipes are different charts. A `type:` not in this table has no established mapping, so flag it for chart-type judgment in the `design` mode. A stacked or percent variant (`stacking: normal` / `percent`) maps to `Stacked_Bar` / `Full_Stacked_Bar`.

## Concepts

| Looker | Tableau |
|---|---|
| view | table, or one relation in a data source |
| explore with joins | data source: pre-joined `custom_sql` (supported) or a relationship model (Desktop) |
| dimension / dimension_group | dimension (dates: date or datetime) |
| measure `type: sum/count/average/count_distinct` | measure with SUM / COUNT / AVG / COUNTD |
| measure `type: number` over other measures | aggregate calculated field |
| `dynamic_fields` | calculated field (`add_calculated_field`) |
| derived table / PDT | `custom_sql` or a `.hyper` extract |
| tile `filters:` (exact values) | `add_worksheet_filter` |
| tile relative-date filter | Desktop step (relative date filter) |
| dashboard filter + `listen:` | dashboard quick filter (`controls`, categorical fields only) |
| `row/col/width/height` (24-col grid) | grid rows for `instantiate_dashboard_layout`; group tiles by `row`, use `width` as `weight` |
| `liquid` / `parameter:` fields | parameter (`add_parameter`) + calc; review by hand |
| access filters / `user_attribute` | row-level security (server-side; out of scope) |
