# BRD.md template

Output Markdown starting with `# BRD:`. Adapt the sections to what the source supports, and don't pad empty ones.

```markdown
# BRD: <dashboard title, or Looker model/project name>

## Source
- Migrated from Looker: <files read>; dashboard PDF: <yes/no>
- Known vs. not specified: <explicit list>

## Audience and delivery
- Audience: Not specified in Looker source — needs confirmation
- Delivery: Not specified in Looker source — needs confirmation

## Data model
### View: <name>  (table: <sql_table_name>)
| Field | Looker type | Physical column | Tableau role | Aggregation / notes |
|---|---|---|---|---|

### Explore: <name>
- Joins: <view> ON <sql_on> (<relationship>)
- Tableau data source plan: single table | pre-joined custom_sql | relationship model (Desktop)

## Calculated fields
| Name | Tableau formula | Translated from (Looker expression) | Used by tiles |
|---|---|---|---|

## Dashboards
### <Dashboard title>
| # | Tile title | Looker type → Tableau recipe | Fields (with granularity) | Filters (verbatim) | Layout r/c/w/h | Confidence |
|---|---|---|---|---|---|---|

Dashboard filters: <name> → listens on <tile: field>, ...

## Gaps and open questions
- <no recipe for type X>, <relative-date filters needing Desktop>, <relationship model>, <PDF-only colors/formatting>, <unreadable files>
```

Confidence values: **LookML** (read from the source), **PDF-only** (visual inference — confirm field names), **Inferred** (avoid; explain why if used).
