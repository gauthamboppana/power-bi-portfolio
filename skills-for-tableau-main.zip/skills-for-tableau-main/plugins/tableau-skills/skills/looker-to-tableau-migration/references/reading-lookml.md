# Reading LookML correctly

## Two different syntaxes

**Views, explores and models** (`*.view.lkml`, `*.explore.lkml`, `*.model.lkml`, often just `.lkml` / `.txt`) use Looker's brace syntax:

```lookml
view: orders {
  sql_table_name: analytics.orders ;;
  dimension: status { type: string  sql: ${TABLE}.status ;; }
  dimension_group: created { type: time  timeframes: [hour, date, week, month]  sql: ${TABLE}.created_at ;; }
  measure: total_amount { type: sum  sql: ${amount} ;; }
}
explore: orders {
  join: customers { sql_on: ${orders.customer_id} = ${customers.id} ;; relationship: many_to_one }
}
```

**Dashboards** (`*.dashboard.lookml`, `*.dashboard.lkml`, sometimes `.lkml` / `.txt`) are **YAML**:

```yaml
- dashboard: ops_overview
  title: Ops Overview
  elements:
  - title: Pending events (3h+)
    type: looker_column
    explore: data_state_fact
    fields: [data_state_fact.create_hour_hour, data_state_fact.count]
    filters:
      data_state_fact.data_state: '"MISSING_IN_TRANSACTION_FACT_PENDING_JMS_EVENT_3_OR_MORE_HOURS"'
      data_state_fact.create_hour_date: 72 hours
    dynamic_fields: [{ dimension: status_bucket, label: Status Bucket,
                       expression: 'case(when(${orders.status} = "A", "Active"), "Other")' }]
    listen: { Region: customers.region }
    row: 0  col: 0  width: 12  height: 6
```

## Rules that are easy to get wrong

1. **Tile `filters:` are load-bearing.** Several tiles that share an explore, fields and type but differ only in `filters:` are the *same chart restricted to different slices*. Transcribe every filter verbatim, keeping the field and the exact literal including quotes. In Tableau each becomes `add_worksheet_filter` on its own worksheet. Missing them produces N identical charts.
2. **Relative date filters** (`72 hours`, `this month`, `7 days`) must be recorded with their literal window. They are not automatable by the build tools yet, so flag each one as a Desktop step.
3. **dimension_group suffixes encode granularity.** `created_hour` = created truncated to the hour; `_date` = day; `_week`, `_month`, `_quarter`, `_year` likewise. Always write *"created, truncated to Hour"*, not just the bare field name.
4. **`dynamic_fields` are calculated fields to create first.** They are not fields already in the data source. Translate the `expression`, keep the literal match values, and de-duplicate when the same expression repeats across tiles.
5. **`listen:`** maps a dashboard-level filter to the field it filters on each tile. In Tableau this becomes a dashboard quick filter (categorical fields only) applied to those worksheets.
6. **Measure `type`** (sum, count, count_distinct, average, number) decides the Tableau aggregation. `type: number` with a `sql:` expression over other measures is a calculated field (`SUM(a)/SUM(b)`), not a raw column.
7. `${TABLE}.column` gives the physical column name, which is the Tableau `remote_name` for `create_datasource`.
