---
name: tableau-chart-library
description: "Browse, extend and maintain the Tableau chart template and recipe library (81 charts extracted from real workbooks): find a recipe for a chart type, read its placeholder slots, add new chart types by extracting templates from a .twb/.twbx gallery, regenerate recipes and review tokenization warnings. Use when the library itself changes or is being explored; use tableau-report-cli to build charts into a workbook. Triggers: add chart type to library, extract Tableau templates, chart recipe, list Tableau chart templates"
metadata:
  version: 1.0.0
---

> **CRITICAL NOTES**
> 1. Call `get_chart_library_path` first and use its `templates_dir` everywhere.
> 2. Extract only from workbooks the user has the right to reuse. Templates carry the source's worksheet XML.

# Tableau Chart Library

## What a template and a recipe are

- **Template** (`<Name>.json`): one real worksheet's XML, its mark class and the fields it used, extracted from a real workbook.
- **Recipe** (`<Name>.recipe.json`): the same XML with every field reference replaced by a placeholder (`{{DIM1}}`, `{{MEA1}}`, `{{DATASOURCE}}`, `{{WORKSHEET_NAME}}`). It also has a `field_slots` list giving each placeholder's role, datatype and the shelves it occupies (`rows`, `columns`, `color`, `size`, `text`, `tooltip`, `detail`, `lod`). `instantiate_chart_recipe` fills these in.

The generated catalog of every recipe and its slots is in [../tableau-report-cli/references/chart-catalog.md](../tableau-report-cli/references/chart-catalog.md).

## Find a chart

1. `list_chart_templates(templates_dir)` lists names, marks and fields.
2. Open `<templates_dir>/<Name>.recipe.json` and read `field_slots`.
3. Check `tokenization_warning` (must be null for safe use) and `stripped_hardcoded_filters` (filters the source sheet had that were removed).

## Add chart types

1. Get a source workbook where **each worksheet is one example chart** (a "chart gallery" workbook), built on a simple dataset such as Superstore.
2. `extract_chart_templates(source_workbook, templates_dir)` writes one template per worksheet. A same-named template is overwritten, so rename the source sheets first if needed.
3. `generate_all_chart_recipes(templates_dir)`, then review every warning it returns.
4. Prove each new recipe: on a scratch copy of a starter workbook, run `instantiate_chart_recipe` → `validate_workbook` → reopen in Desktop.
5. Regenerate the catalog: `python build/build.py` (repo maintainers), then commit the template, recipe and catalog together.

## Quality bar for a new recipe

- No `tokenization_warning`.
- Instantiates against a second, differently named datasource (proves it isn't tied to the source's field names).
- Reopens in Desktop and renders as the intended chart.
- Has a clear, unique name. Worksheet names become recipe names, so avoid `Sheet 1`; several existing `Sheet_N` entries are candidates for renaming.
