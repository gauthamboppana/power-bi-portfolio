# `.hyper` extracts

Requires `pip install tableauhyperapi`. If it is missing, these three tools return an error saying so; everything else still works.

## Build

1. Confirm the source CSV and the grain (what one row means) with the user.
2. `create_hyper_extract(csv_path, hyper_path, table_name="Extract")`. Types are inferred from the first 500 rows (via pandas if installed, otherwise everything is text).
3. Check the inferred types with `query_hyper(hyper_path, 'SELECT * FROM "Extract" LIMIT 5')`. IDs that look numeric but should be strings are the usual surprise.
4. Connect it: `create_datasource(..., platform="hyper", hyper_path=...)`.

## Validate (required before calling it done)

```python
validate_data(hyper_path, "Extract", {
  "row_count_min": 1, "row_count_max": 5_000_000,
  "not_null_columns": ["order_id", "region"],
  "bounds": {"sales": [0, None], "discount": [0, 1]}
})
```

Pick bounds from the business meaning (discount 0–1, quantity ≥ 0). If you don't know them, ask the user instead of inventing plausible numbers. Then hand-check one aggregate against the source CSV (for example `SELECT SUM(sales) FROM "Extract"` against the same total computed in Python).
