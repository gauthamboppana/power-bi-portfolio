# Connections — `create_datasource`

Turns a blank `.twb` into one the other tools can build against, without a manual connect step in Desktop.

| `platform` | Kind | Required | Verified? |
|---|---|---|---|
| `postgres` | live | `server`, `database`, and one of `table_name` (schema-qualified) or `custom_sql` | ✅ against a Desktop-saved file |
| `excel` | live file link | `excel_path` (path on the machine that opens the workbook), `excel_sheet_name` (no trailing `$`) | ✅ except the boolean remote-type code |
| `hyper` | extract | `hyper_path` (exists; build it first), optional `hyper_table_name` (default `Extract`) | ✅ |
| `snowflake` | live | as postgres, plus `warehouse` | ⚠️ by analogy, not verified; tell the user |

## `fields`

List every field to expose:

```json
[
  {"name": "Client Name",  "remote_name": "NAME",          "datatype": "string", "role": "dimension"},
  {"name": "Total Amount", "remote_name": "TOTAL_AMOUNT",  "datatype": "real",   "role": "measure"},
  {"name": "Order Date",   "remote_name": "ORDER_DATE",    "datatype": "date"}
]
```

- `remote_name` = the exact column name in the table, query or sheet header. It defaults to `name`, which is only safe when the two match.
- `datatype`: `string | integer | real | boolean | date | datetime`.
- `role` defaults to measure for numbers and dimension for everything else.

Get the column list from the source: query the database, read the Excel header row, or `query_hyper("SELECT * FROM ... LIMIT 1")`. Don't guess.

## Rules

- **Passwords**: leave `password` unset. Desktop prompts on first open. Writing it is unverified and stores it in plain text. Pass it only if the user explicitly opts in after being told this.
- **Multiple tables**: only one relation is supported. Pre-join into one `custom_sql` SELECT, or build the relationship model in Desktop afterwards (a manual step).
- After writing, ask the user to open the workbook and check the Data Source tab before building worksheets on it.
