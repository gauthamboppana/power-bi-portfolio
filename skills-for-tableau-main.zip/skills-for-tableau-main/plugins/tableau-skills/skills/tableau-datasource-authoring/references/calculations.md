# Calculated fields, LOD calcs and parameters

## Calculated fields

```python
add_calculated_field(path, "Sample - Superstore", "Profit Ratio",
                     "SUM([Profit]) / SUM([Sales])", caption="Profit Ratio",
                     datatype="real", role="measure")
edit_calculated_field(path, "Sample - Superstore", "Profit Ratio", "ZN(SUM([Profit])) / SUM([Sales])")
```

- Reference fields as `[Field Name]`, using names from `inspect_workbook`.
- Aggregate calcs (`SUM(...)/SUM(...)`) are measures. Row-level string logic (`CASE`, `IF`) is usually a dimension.
- `validate_workbook` checks bracket, paren and quote balance only. Reopening in Desktop is the real syntax check, and a `query_hyper` spot-check on a known row verifies the result.

Common translations (useful for Looker `dynamic_fields`, SQL or Excel formulas):

| Source | Tableau |
|---|---|
| `case(when(${v.f} = "X", "A"), "B")` | `CASE [f] WHEN "X" THEN "A" ELSE "B" END` |
| `if(cond, a, b)` / SQL `CASE WHEN` | `IF cond THEN a ELSE b END` |
| `coalesce(x, 0)` | `ZN([x])` or `IFNULL([x], 0)` |
| `count_distinct` | `COUNTD([x])` |
| `date_trunc('month', d)` | `DATETRUNC('month', [d])` |
| `sum(x) / NULLIF(sum(y), 0)` | `IF SUM([y]) = 0 THEN NULL ELSE SUM([x]) / SUM([y]) END` |

## LOD calculations — use the verified patterns

Don't hand-write `{FIXED ...}` from scratch. Call `list_lod_patterns()`, then `instantiate_lod_calculation(...)`:

| Pattern key | Formula | Typical use |
|---|---|---|
| `fixed_aggregate` | `{FIXED [DIM] : AGG([MEASURE])}` | Region total regardless of view |
| `include_aggregate` | `{INCLUDE [DIM] : AGG([MEASURE])}` | Avg per-order sales on a region view |
| `exclude_aggregate` | `{EXCLUDE [DIM] : AGG([MEASURE])}` | Company total next to region breakdown |
| `average_of_group_totals` | `{EXCLUDE [DIM]:AGG({FIXED [DIM2] : SUM([MEASURE])})}` | Avg of each region's total |
| `cohort_first_date` | `{FIXED [DIM] : MIN([DATE_FIELD])}` | Customer acquisition date (cohorts) |

```python
instantiate_lod_calculation(path, "Sample - Superstore", "cohort_first_date",
                            {"DIM": "Customer Name", "DATE_FIELD": "Order Date"},
                            "First Order Date")
```

`AGG` slots take an aggregation name (`SUM`, `AVG`, `MIN`, `MAX`, `COUNT`, `COUNTD`, ...); field slots take field names. The tool checks that every mapped field exists and every aggregation is real. If you need a shape none of the patterns cover, use `add_calculated_field` and tell the user the pattern library could gain an example.

## Parameters

| `domain_type` | `datatype` | Needs |
|---|---|---|
| `list` | `string` | `list_values` |
| `range` | `integer` / `real` | `range_min`, `range_max`, optional `range_granularity` |
| `any` | `date` | `current_value` ISO (`"2024-01-31"`), optional `default_format` |

Other combinations are refused (unverified XML). Don't hand-write them; ask whether a real example workbook is available to extract from.

A parameter does nothing until something uses it: a calc that references `[Parameters].[Top N]`, a dashboard control (`instantiate_dashboard_layout` → `controls`), or a parameter action (`add_dashboard_action`).
