---
name: tableau-datasource-authoring
description: "Author the data layer of a Tableau workbook: connect a blank .twb to Postgres, Excel, Snowflake or a .hyper extract, add or edit calculated fields, build FIXED/INCLUDE/EXCLUDE LOD calcs from verified patterns, add parameters, and build and validate .hyper extracts from CSV. Use for data-source work beneath a report; use tableau-report-cli for worksheets and dashboards. Triggers: Tableau calculated field, LOD, FIXED calc, Tableau parameter, hyper extract, connect Tableau to postgres, tds"
metadata:
  version: 1.0.0
---

> **CRITICAL NOTES**
> 1. Read [../../common/TABLEAU-CORE.md](../../common/TABLEAU-CORE.md) first. Back up, validate, never invent a field.
> 2. Tool priority: **Hyper API tools** for extracts → **MCP XML tools** for connections, calcs and parameters → **Desktop UI** only when no tool fits (tell the user it is a manual step).
> 3. Run `validate_workbook` after every write and report the backup path the tool returned.

# Tableau Data Source Authoring

| Task | Read |
|---|---|
| Connect a blank workbook to data (`create_datasource`) | [references/connections.md](references/connections.md) |
| Calculated fields, LOD calcs, parameters | [references/calculations.md](references/calculations.md) |
| Build, query and validate `.hyper` extracts | [references/extracts.md](references/extracts.md) |

## Workflow

1. `inspect_workbook` to see what datasources, fields and calcs already exist. Use the exact `datasource_name` (name or caption) it shows.
2. Make the change with the matching tool.
3. `validate_workbook`. If it fails, restore the backup and retry.
4. For extracts, run `validate_data` and spot-check one value with `query_hyper`.
5. Ask the user to reopen in Desktop and check the Data Source tab (connections) or the calc editor (formulas). The tool's checks are structural; Tableau's calculation engine is the real judge.

## Hand-off checklist (before report authoring starts)

- [ ] Every field the spec needs exists, with the right role and datatype
- [ ] Every calc and LOD passed `validate_workbook`
- [ ] Extracts passed `validate_data`
- [ ] Parameters that dashboards will control exist
- [ ] The user confirmed the workbook reopens cleanly, or this is flagged as pending

Out of scope here: row-level security, permissions and refresh schedules. Those are server features; see `tableau-server-cli`.
