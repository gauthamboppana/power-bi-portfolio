---
name: tableau-report-cli
description: "Plan, design, author and verify Tableau workbooks and dashboards: requirements to approved spec, chart and layout choice from an 81-chart recipe library, direct .twb/.twbx authoring (worksheets, grid dashboards, quick filters, legends, parameter controls, actions) and a validate-render-review-fix loop. Use for report or visual work. Use tableau-datasource-authoring for connections, calcs, LODs or extracts, and tableau-server-cli to publish or render on Server/Cloud. Triggers: build Tableau dashboard, create worksheet, Tableau chart, edit twb, add dashboard filter, Tableau visual QA"
metadata:
  version: 1.0.0
---

> **CRITICAL NOTES**
> 1. Read [../../common/TABLEAU-CORE.md](../../common/TABLEAU-CORE.md) once per session before changing a workbook. Its safety rules (back up, validate, never invent a field) apply to every mode.
> 2. Every change goes through the `tableau-desktop` MCP tools ([catalog](../../common/MCP-TOOLS.md)). Hand-edit `.twb` XML only for a mechanical bulk change no tool covers, and run `validate_workbook` afterwards.
> 3. Start every session on a workbook with `inspect_workbook`, and every chart task with `get_chart_library_path`.

# Tableau Reports — CLI Skill

This skill covers the Tableau report lifecycle end to end. It is a **mode dispatcher**: pick the mode that matches the request, then read that mode's reference file in full before acting.

## Mode Selection

| Mode | Use when the request... | Examples | Read first |
|---|---|---|---|
| `planning` | creates a new report or dashboard and needs requirements, data inspection, a spec and approval | "build a sales dashboard", "here's a BRD, make the workbook" | [references/planning.md](references/planning.md) |
| `design` | decides what it should look like: chart type, encodings, layout, controls, actions | "which chart for this?", "lay out this dashboard", "critique this design" | [references/design.md](references/design.md), then [references/chart-catalog.md](references/chart-catalog.md) |
| `authoring` | changes the workbook file: worksheets, dashboards, filters, legends, parameter controls, actions | "add a treemap of sales by category", "put these 3 sheets on a dashboard", "add a region filter" | [references/authoring.md](references/authoring.md) |
| `qa` | verifies a build: structural and data checks, render, visual review, fix loop with retry cap | "check the dashboard", "does this render right?", "validate my workbook" | [references/qa.md](references/qa.md) |

## Mode Boundary Rules

- Classify by **intent**, not by which file is open.
- `design` decides; `authoring` writes. Choosing a chart is `design`; calling `instantiate_chart_recipe` is `authoring`.
- A focused edit to an existing workbook goes straight to `authoring`. It runs a short design step only when the chart type is undecided.
- Data-source changes (connections, calcs, LODs, parameters, extracts) belong to `tableau-datasource-authoring`. Publishing, refreshing or rendering on a server belongs to `tableau-server-cli`.
- Nothing is done until `qa` logs a pass for every worksheet and dashboard touched, or the user has answered an escalation.

A greenfield request runs the modes in this order:

```
planning -> (tableau-datasource-authoring) -> design -> authoring -> qa -> (tableau-server-cli publish)
```

## Contracts between modes

The `report_spec`, `design` and `dashboard` YAML documents are defined in [../../common/DESIGN-CONTRACT.md](../../common/DESIGN-CONTRACT.md). Each mode reads the previous document and does not re-decide it.
