# Mode: qa — validate → render → review → fix

A closed loop per **target** (one worksheet or dashboard), not a checklist run once. Ideally the QA step runs as a separate agent (`TableauQA`) that did not build the target, so the work isn't grading itself.

Use `renders_dir = <workbook folder>/_renders` throughout.

## The loop

1. **History first.** `qa_get_attempts(renders_dir, target)`. Read prior failure notes so you don't repeat a fix that already failed.
2. **Structure.** `validate_workbook(path)`. If it fails, stop and route to authoring; don't render a broken file.
3. **Data.** If an extract is involved, run `validate_data(hyper_path, table, rules)` (row-count range, key columns not null, plausible bounds), then spot-check one value by hand with `query_hyper`. If you don't know sensible bounds, ask the user rather than invent them.
4. **Render.**
   - *Server/Cloud available*: publish and render with `tableau-server-cli` (`render` command), saving into `renders_dir/incoming/`.
   - *Desktop only*: run `request_render(workbook_path, target, renders_dir)` and give the user its exact instructions (reload, open the target, File → Export Image, save as the given filename). Confirm the file arrived with `list_pending_renders`; don't proceed on assumption.
5. **Technical check.** `check_render(image)` catches corrupt or blank images.
6. **Regression.** If a baseline exists, run `pixel_diff(baseline, new)`. A large diff means look closer; it is not an automatic fail.
7. **Visual review.** Open the image and check:
   - no error banners, "!" marks or blank panes
   - no cut-off or overlapping text; axes readable
   - captions, not raw field names, on axes and legends
   - the mark type and encodings match the `design` block
   - consistent colors across the dashboard
   - the story agrees with step 3's numbers
8. **Log.** `qa_log_attempt(renders_dir, target, passed, notes)` on every pass and every fail. A fail note names the check and the specific defect.
9. **Route on fail.** Data defects go to `tableau-datasource-authoring`; structural or visual defects go to `authoring`. Then loop from step 2.
10. **Retry cap.** At **3 logged failures**, stop. Show the user the full history and say continuing to loop is unlikely to help without revisiting the spec or design. This stop is not overridable by the calling agent.
11. **Baseline.** Run `approve_baseline` only after explicit approval: a thorough pass at step 7, or the user's sign-off.

## Verdicts

Report exactly one verdict per target: **pass**, **fail → routed (attempt n/3)**, or **escalated**. Never "mostly working".
