# Mode: authoring

Writes the workbook: worksheets, dashboards, controls and actions, built against the `design` / `dashboard` YAML. Assumes the data source is sound (if not, use `tableau-datasource-authoring` first) and the chart type is decided (if not, run `design` first).

## Order of operations

```
inspect_workbook
  -> get_chart_library_path
  -> per worksheet: instantiate_chart_recipe | build_crosstab_worksheet
       -> add_worksheet_filter (if the design lists worksheet_filters)
       -> validate_workbook
  -> instantiate_dashboard_layout (grid + controls)
       -> validate_workbook
  -> add_dashboard_action (one call per action)
       -> validate_workbook
  -> hand off to qa
```

Use the **returned** `worksheet_name` / `dashboard_name` in later calls. Colliding names are auto-suffixed.

## 1. Worksheet from a recipe

1. Read the recipe's slots: the `field_slots` in `<templates_dir>/<name>.recipe.json`, or `generate_chart_recipe(templates_dir, name)`. Each slot has `placeholder`, `role`, `datatype`, `shelf_locations`.
2. Build `field_mapping` from real fields in `inspect_workbook`. Match role exactly, and keep datatype compatible.
   ```json
   {"DIM1": "Category", "DIM2": "Product Name", "DIM3": "Sub-Category",
    "MEA1": {"field": "Sales", "caption": "Total Sales"}}
   ```
3. `instantiate_chart_recipe(workbook_path, templates_dir, "Treemap", "Sample - Superstore", field_mapping, "Sales Treemap")`.
4. If it returns an error about a missing field or a role mismatch, fix the mapping and retry. Do not fall back to Desktop for a mapping error.
5. If the recipe has a `tokenization_warning`, tell the user the template needs review. Don't silently pick a different recipe.

## 2. Plain table

`build_crosstab_worksheet(workbook_path, datasource_name, name, rows=["Region"], cols=["Segment"], text_fields=["Sales", "Profit"])`. The result is an unstyled table; cell shading and fonts are a Desktop step.

## 3. Baked-in worksheet filter

`add_worksheet_filter(workbook_path, worksheet_name, datasource_name, field, values)` takes a string/boolean field and exact values (OR'd). Calling it again for the same field replaces the earlier filter. Use it for the tile-per-value pattern.

## 4. Dashboard

```python
instantiate_dashboard_layout(
  workbook_path, "Weekly Sales Review",
  layout=[[{"worksheet": "Sales Trend", "weight": 2}, "Sales by Region"], ["Sub-Category Ranking"]],
  title="Weekly Sales Review",
  row_heights=[2, 1],
  controls=[
    {"kind": "legend", "worksheet": "Sales by Region"},
    {"kind": "filter", "worksheet": "Sales by Region", "datasource_name": "Sample - Superstore", "field": "Region", "mode": "dropdown"},
    {"kind": "parameter", "parameter_name": "Top N", "mode": "compact"},
  ])
```

Controls can only be added at creation time. To change them, rebuild the dashboard; the new one is auto-suffixed, so tell the user the old one is still in the file.

## 5. Actions

| `action_type` | Required arguments |
|---|---|
| `highlight` | `field_captions` (as Tableau's dialog shows it, e.g. `"Category"`, `"MONTH(Order Date)"`) |
| `url` | `url` |
| `nav` | `target_sheet` |
| `parameter` | `parameter_name`, `source_worksheet`, `datasource_name`, `source_field` (on that worksheet's shelf), `agg_type` (`attr` for dimensions) |
| `filter` | `target_worksheet`, `datasource_name`, `field_pairs: [{"source_field": "Region", "target_field": "Region"}]` |

## 6. When there is no automated path

Fall back to Desktop for: a chart with no recipe, a non-grid layout, measure, date or range quick filters, and formatting polish. Give the user the design block and the exact click path. Mark the item in your report as **Desktop step, not verified by tools**.

Raw XML edits are acceptable only for mechanical bulk changes (for example renaming a caption across 30 sheets). Back up first and run `validate_workbook` after.

## Anti-patterns

- Building before a design contract exists.
- Hand-editing XML for something a tool covers.
- Reporting "done" after the write. The next step is always `qa`.
