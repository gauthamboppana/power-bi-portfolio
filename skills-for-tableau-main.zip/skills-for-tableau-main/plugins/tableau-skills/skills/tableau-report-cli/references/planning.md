# Mode: planning

Runs a new report build: **Define → Inspect → Spec → Approve → Build → Validate → Fix → (Publish)**. This mode gathers requirements and locks a spec, then hands off. It does not write XML, pick charts or run QA itself.

Do not use it for a surgical edit to an existing workbook (go to `authoring`) or a data-only change (go to `tableau-datasource-authoring`).

## Operating principles

- **One question at a time.** Ask the single most useful question, wait for the answer, then ask the next. Never send a questionnaire.
- **Don't re-ask what is known.** If the request or BRD already answers a round, skip it and say what you took from it.
- **Inspect before locking.** Never assume schema, field names or grain. Run `inspect_workbook` first.
- **The approval gate is real.** Show the spec and wait for an explicit yes before any build step.

## Starting from a BRD

When the user provides a BRD or requirements document:

1. Read it fully first. Pre-fill every round it answers: audience, data sources, dashboards and worksheets, filters and actions, delivery.
2. Tell the user which items came from the document and which you still need to ask about.
3. Still run Round 2's data inspection. A document describing intent does not replace looking at the real schema.
4. The BRD becomes the `report_spec` YAML, a plan. The build is always direct edits to a real workbook file, never "save as JSON and rename to .twb".

For a Looker source, generate the BRD with `looker-to-tableau-migration` first.

## Rounds

**Round 0 — Environment and starter workbook.**
- Desktop only, or Server/Cloud with a Personal Access Token? This decides whether rendering is manual and whether publishing is in scope.
- Starter workbook: the user's `.twb`/`.twbx` already connected to the data, an existing workbook to extend, or a blank `.twb` you connect with `create_datasource` (see `tableau-datasource-authoring`). Record its path. The build cannot start without it.

**Round 1 — Audience and job to be done.** Who reads it, how often, and what decision does it support?

**Round 2 — Data inventory and scope boundary.** Run `inspect_workbook` and catalog the dimensions, measures and grain. Cut scope to what the data supports, and list anything cut in `out_of_scope` with the reason.

**Round 3 — Dashboard architecture.** One line per worksheet: purpose, intent (trend / comparison / distribution / composition / ranking / correlation / single-value / geospatial / calendar / table), filters, and the actions that connect worksheets.

**Round 4 — Delivery.** Desktop file only, or publish to Server/Cloud (which project, which site)?

## Output

Write `_brief/report-spec.md` next to the workbook, using the `report_spec` schema in [../../../common/DESIGN-CONTRACT.md](../../../common/DESIGN-CONTRACT.md). Show it and ask for approval or changes.

## After approval — implementation sequence

1. **Data layer** → `tableau-datasource-authoring`: connections, calcs, LODs and parameters the spec needs.
2. **Design** → `design` mode: one `design` block per worksheet plus a `dashboard` block per dashboard.
3. **Authoring** → `authoring` mode: build against those blocks.
4. **QA** → `qa` mode for every worksheet and dashboard.
5. **Publish** (if in scope) → `tableau-server-cli`.
6. **Report back**: what was built, where the file is, what was verified, and each spec item that changed or became a Desktop step, with the reason.

## Routing failures

- Data-level failure (row counts, nulls, bounds, a calc's output) → `tableau-datasource-authoring` / `TableauDataEngineer`.
- Structural or visual failure (broken XML, wrong chart, unreadable layout) → `authoring` / `TableauReportDeveloper`.
- A target at **3 logged failures**: stop. Show the user the full `qa_get_attempts` history and ask how to proceed. Repeated failure usually means the spec or design is wrong, not the XML.
