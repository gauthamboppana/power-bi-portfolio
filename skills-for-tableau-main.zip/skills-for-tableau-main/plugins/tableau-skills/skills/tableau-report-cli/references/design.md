# Mode: design

Decides what each worksheet and dashboard should look like, and why. Output is the `design` and `dashboard` YAML from [../../../common/DESIGN-CONTRACT.md](../../../common/DESIGN-CONTRACT.md). This mode never writes the workbook.

## Step 0 — Know the data

Run `inspect_workbook` (and `list_calculated_fields` if needed). Note the grain, each field's role (dimension/measure) and datatype. Only encode fields that exist and have validated; a calc that hasn't passed `validate_workbook` is not ready.

## Step 1 — Pick the chart from the library first

1. `get_chart_library_path` → `templates_dir`.
2. Find the intent in the table below, then confirm the candidate in [chart-catalog.md](chart-catalog.md). The catalog lists each recipe's placeholder slots, their roles and the shelves they occupy.
3. **The recipe's slots must fit your fields.** If a recipe needs `DIM1` (string, color) + `MEA1` (real, size), map a string dimension and a numeric measure. Putting a date into a string slot risks a worksheet that won't reopen.
4. Record the exact recipe name as `matched_template`, and fill `field_mapping`.

| Intent | Default | Library recipes | Avoid |
|---|---|---|---|
| Trend over time | Line | `Line`, `Multiple_Line`, `Dual-Line`, `Cumulative_Line`, `Small_Multi-Line`, `Sparkline`, `Highlighted_Line_1/2`, `Area`, `Stacked_Area`, `Small_Multi-Area`, `Bar_Over_Time` | Pie/donut |
| Compare categories | Bar (horizontal when labels are long) | `Bar__Rows_`, `Bar__Columns_`, `Bar__Side_By_Side_`, `Bar_in_Bar`, `Small_Multi-Bars`, `Lollipop__H_/__V_`, `Bar___Avg_Line`, `Rounded_Bar`, `Butterfly__Method_1_/2_` | 3-D, radar |
| Distribution | Histogram / box plot | `Histogram_1_Measure`, `Histogram_2_Measures`, `Box_Plot`, `Dot_Plot`, `Barcode` | One stacked bar hiding spread |
| Part-to-whole | Stacked bar / treemap; pie only ≤ 5 slices | `Stacked_Bar`, `Full_Stacked_Bar`, `Full_Stacked_Area`, `Treemap`, `Donut`, `Pie`, `Waterfall`, `Waterfall_Chart` | Pie with > 5 slices |
| Funnel / stages | Funnel | `Funnel`, `Easy_Funnel`, `Advanced_Funnel_Chart` | Unsorted bars |
| Ranking | Sorted bar | `Pareto__Method_1_`, `Pareto__method2_`, `Bump`, `Lollipop__H_` | Unsorted table |
| Correlation | Scatter | `Scatter_plots`, `Scatter_Plots__Customized_`, `Bubble`, `Stacked_Bubble`, `Quadrant___Dynamic_` | Dual axis implying a false relationship |
| Single value | BAN / KPI | `BANS`, `KPI`, `KPI___Bar`, `Bullet`, `Progress_Bar` | One number buried in a table |
| Geospatial | Filled / symbol map | `Map_Basic`, `Map_with_Symbols`, `Map_without_Background`, `Map_Night_Vision` | Bars for a location story |
| Calendar patterns | Highlight table | `Calender`, `Heatmap`, `Cricle_Timeline` | A line when the point is day-of-week |
| Two measures / change | Dual axis, slope, barbell | `Bars___Line_Dual_Axis`, `Slope`, `Barbell` | Two separate charts when the comparison is the point |
| Survey / sentiment | Diverging bar | `Likert_Chart` | Pie per question |
| Cohorts | Cohort grid | `Cohort_Analysis`, `Customer_Cohorts`, `Customer_Cohorts___of_Total`, `Customer_Cohort_Sales_Contribution` | — (needs the cohort LOD from `tableau-datasource-authoring`) |
| Plain table | Crosstab | none: use `build_crosstab_worksheet` | Forcing a table into a chart recipe |

If nothing fits, set `matched_template: null`, explain the chart in `notes`, and flag it as a Desktop step. Alternatively, propose adding it to the library (`tableau-chart-library`).

Fallback encoding rule, most to least accurate: **position → length → angle → area → color hue**. Don't use color alone when position or length would show the comparison.

## Step 2 — Worksheet-level decisions

- **Title = the insight** ("Profit fell in the West in Q3"), not the field list.
- **Captions, not raw names**: set `caption` in `field_mapping` when the source name is ugly (`TOTAL_AMT_USD` → "Total Amount").
- **Tile-per-value pattern**: when N tiles share a chart and differ only by a category value, use the same recipe N times plus a `worksheet_filters` entry each. Skipping the filter produces N identical charts with different titles.
- The same category gets the same color on every worksheet of a dashboard.

## Step 3 — Dashboard layout

- Use a grid whenever possible; `instantiate_dashboard_layout` builds grids directly. Use `weight` for uneven widths and `row_heights` for uneven heights.
- Common shapes: BAN row on top (`row_heights: [1, 3]`); hero chart + side panel (`[{worksheet: A, weight: 2}, B]`); 2×2 small multiples.
- Include only the worksheets the audience's job needs.
- Controls: a legend only for a color-encoded worksheet; categorical filters only on fields already on that worksheet's shelves; parameter controls only for parameters that exist or are planned in the data step.
- Actions: filter actions for drill-down, highlight for cross-chart brushing, nav for multi-dashboard flows, parameter actions for "click to set Top N or metric".
- Anything a grid can't express (floating, tabs, overlays), and measure or date range filters, go into `layout_notes` as Desktop steps.

## Common gotchas

- A tone or intent declared in the spec that never shows up in an encoding choice.
- Raw database names left on axes and legends.
- A chart picked because it is familiar, not because it matches the intent.
- A recipe chosen by a similar-sounding name: `Bar__Side_By_Side_` is not `Bar__Columns_`. Match names exactly against the catalog.
