#!/usr/bin/env python3
"""
tsc_ops.py - small CLI over tableauserverclient (TSC) for the skills-for-tableau
`tableau-server-cli` skill: list, publish, render, refresh and download on
Tableau Server / Tableau Cloud.

Auth comes from environment variables (never pass secrets on the command line):

    TABLEAU_SERVER_URL   e.g. https://prod-useast-a.online.tableau.com
    TABLEAU_SITE         site content URL ("" for the Default site on Server)
    TABLEAU_PAT_NAME     Personal Access Token name
    TABLEAU_PAT_SECRET   Personal Access Token secret

Every command prints one JSON object to stdout: {"ok": true, ...} or
{"ok": false, "error": "..."}.

    python tsc_ops.py whoami
    python tsc_ops.py projects
    python tsc_ops.py workbooks --project "Sales"
    python tsc_ops.py publish  --file out/sales.twbx --project "Sales" [--name "Sales Review"] [--mode overwrite|createnew]
    python tsc_ops.py views    --workbook "Sales Review" --project "Sales"
    python tsc_ops.py render   --workbook "Sales Review" --project "Sales" --view "Weekly Sales Review" --out _renders/incoming/x.png
    python tsc_ops.py pdf      --workbook "Sales Review" --project "Sales" --view "Weekly Sales Review" --out x.pdf
    python tsc_ops.py refresh  --workbook "Sales Review" --project "Sales" [--wait]
    python tsc_ops.py download --workbook "Sales Review" --project "Sales" --out downloaded/
"""

import argparse
import json
import os
import sys
from pathlib import Path

try:
    import tableauserverclient as TSC
except ImportError:  # pragma: no cover
    print(json.dumps({"ok": False, "error": "tableauserverclient not installed: pip install tableauserverclient"}))
    sys.exit(1)


def out(ok=True, **kw):
    print(json.dumps({"ok": ok, **kw}, indent=2, default=str))
    sys.exit(0 if ok else 1)


def connect():
    missing = [v for v in ("TABLEAU_SERVER_URL", "TABLEAU_PAT_NAME", "TABLEAU_PAT_SECRET") if not os.environ.get(v)]
    if missing:
        out(False, error=f"Missing environment variables: {', '.join(missing)}")
    auth = TSC.PersonalAccessTokenAuth(
        os.environ["TABLEAU_PAT_NAME"], os.environ["TABLEAU_PAT_SECRET"], site_id=os.environ.get("TABLEAU_SITE", "")
    )
    server = TSC.Server(os.environ["TABLEAU_SERVER_URL"], use_server_version=True)
    return server, auth


def find_project(server, name):
    matches = [p for p in TSC.Pager(server.projects) if p.name == name]
    if not matches:
        out(False, error=f"No project named '{name}'. Run `projects` to list them.")
    if len(matches) > 1:
        out(False, error=f"{len(matches)} projects are named '{name}' (nested projects). Rename or use a unique name.",
            candidates=[{"id": p.id, "parent_id": p.parent_id} for p in matches])
    return matches[0]


def find_workbook(server, name, project=None):
    matches = [w for w in TSC.Pager(server.workbooks)
               if w.name == name and (project is None or w.project_name == project)]
    if not matches:
        out(False, error=f"No workbook '{name}'" + (f" in project '{project}'" if project else "") + ".")
    if len(matches) > 1:
        out(False, error=f"Workbook name '{name}' is ambiguous; pass --project.",
            candidates=[{"id": w.id, "project": w.project_name} for w in matches])
    return matches[0]


def find_view(server, wb, view_name):
    server.workbooks.populate_views(wb)
    for v in wb.views:
        if v.name == view_name:
            return v
    out(False, error=f"No view '{view_name}' in workbook '{wb.name}'.", views=[v.name for v in wb.views])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("whoami")
    sub.add_parser("projects")
    p = sub.add_parser("workbooks"); p.add_argument("--project")
    p = sub.add_parser("publish"); p.add_argument("--file", required=True); p.add_argument("--project", required=True)
    p.add_argument("--name"); p.add_argument("--mode", choices=["overwrite", "createnew"], default="overwrite")
    for c in ("views", "render", "pdf", "refresh", "download"):
        p = sub.add_parser(c); p.add_argument("--workbook", required=True); p.add_argument("--project")
        if c in ("render", "pdf"):
            p.add_argument("--view", required=True); p.add_argument("--out", required=True)
        if c == "render":
            p.add_argument("--width", type=int); p.add_argument("--height", type=int)
        if c == "pdf":
            p.add_argument("--landscape", action="store_true")
        if c == "refresh":
            p.add_argument("--wait", action="store_true")
        if c == "download":
            p.add_argument("--out", required=True)
    a = ap.parse_args()

    server, auth = connect()
    try:
        with server.auth.sign_in(auth):
            if a.cmd == "whoami":
                out(server_url=server.server_address, site_id=server.site_id, user_id=server.user_id,
                    api_version=server.version)

            if a.cmd == "projects":
                out(projects=[{"id": p.id, "name": p.name, "parent_id": p.parent_id} for p in TSC.Pager(server.projects)])

            if a.cmd == "workbooks":
                wbs = [w for w in TSC.Pager(server.workbooks) if not a.project or w.project_name == a.project]
                out(workbooks=[{"id": w.id, "name": w.name, "project": w.project_name, "updated_at": w.updated_at} for w in wbs])

            if a.cmd == "publish":
                path = Path(a.file)
                if not path.is_file():
                    out(False, error=f"File not found: {path}")
                proj = find_project(server, a.project)
                item = TSC.WorkbookItem(project_id=proj.id, name=a.name or path.stem)
                mode = TSC.Server.PublishMode.Overwrite if a.mode == "overwrite" else TSC.Server.PublishMode.CreateNew
                wb = server.workbooks.publish(item, str(path), mode)
                out(workbook_id=wb.id, name=wb.name, project=a.project, webpage_url=wb.webpage_url)

            wb = find_workbook(server, a.workbook, a.project)

            if a.cmd == "views":
                server.workbooks.populate_views(wb)
                out(workbook=wb.name, views=[{"id": v.id, "name": v.name, "content_url": v.content_url} for v in wb.views])

            if a.cmd == "render":
                view = find_view(server, wb, a.view)
                opts = TSC.ImageRequestOptions(imageresolution=TSC.ImageRequestOptions.Resolution.High, maxage=1,
                                               viz_width=a.width, viz_height=a.height)
                server.views.populate_image(view, opts)
                Path(a.out).parent.mkdir(parents=True, exist_ok=True)
                Path(a.out).write_bytes(view.image)
                out(image_path=str(Path(a.out).resolve()), view=view.name, bytes=len(view.image))

            if a.cmd == "pdf":
                view = find_view(server, wb, a.view)
                opts = TSC.PDFRequestOptions(
                    page_type=TSC.PDFRequestOptions.PageType.A4,
                    orientation=(TSC.PDFRequestOptions.Orientation.Landscape if a.landscape
                                 else TSC.PDFRequestOptions.Orientation.Portrait),
                    maxage=1,
                )
                server.views.populate_pdf(view, opts)
                Path(a.out).parent.mkdir(parents=True, exist_ok=True)
                Path(a.out).write_bytes(view.pdf)
                out(pdf_path=str(Path(a.out).resolve()), view=view.name, bytes=len(view.pdf))

            if a.cmd == "refresh":
                job = server.workbooks.refresh(wb)
                if job is None:
                    out(workbook=wb.name, job_id=None, note="Server returned no job (nothing to refresh, or a live connection).")
                if a.wait:
                    job = server.jobs.wait_for_job(job)
                out(workbook=wb.name, job_id=job.id, finish_code=getattr(job, "finish_code", None),
                    completed_at=getattr(job, "completed_at", None))

            if a.cmd == "download":
                Path(a.out).mkdir(parents=True, exist_ok=True)
                path = server.workbooks.download(wb.id, filepath=a.out)
                out(downloaded_to=str(Path(path).resolve()))
    except TSC.ServerResponseError as e:
        out(False, error=f"Server error {e.code}: {e.summary} - {e.detail}")
    except Exception as e:  # noqa: BLE001
        out(False, error=f"{type(e).__name__}: {e}")


if __name__ == "__main__":
    main()
