---
name: tableau-server-cli
description: "Operate Tableau Server and Tableau Cloud with a Personal Access Token through tableauserverclient: list projects and workbooks, publish a .twbx, render a view to PNG or PDF (the automated render step of the QA loop), trigger and wait on extract refreshes, and download workbooks. Use after authoring, or to pull a published workbook down for editing. Triggers: publish Tableau workbook, Tableau Cloud, Tableau Server REST, render view image, refresh extract, download twbx"
metadata:
  version: 0.1.0
---

> **CRITICAL NOTES**
> 1. **Secrets stay in environment variables**: `TABLEAU_SERVER_URL`, `TABLEAU_SITE`, `TABLEAU_PAT_NAME`, `TABLEAU_PAT_SECRET`. Never put a PAT in chat, a file in the repo, a command line or a workbook.
> 2. Publishing with `--mode overwrite` replaces what viewers see. Confirm the project and workbook name with the user before the first publish of a session.
> 3. Status: written against the `tableauserverclient` API and checked locally, but **not yet exercised against a live site**. Report any failure verbatim.

# Tableau Server / Cloud — CLI Skill

All operations go through [scripts/tsc_ops.py](scripts/tsc_ops.py), a thin JSON-in/JSON-out wrapper over `tableauserverclient`.

```bash
pip install tableauserverclient
python scripts/tsc_ops.py whoami          # check auth first
```

## Commands

| Goal | Command |
|---|---|
| Check auth | `whoami` |
| List projects | `projects` |
| List workbooks | `workbooks [--project P]` |
| Publish | `publish --file wb.twbx --project P [--name N] [--mode overwrite\|createnew]` |
| List views | `views --workbook N [--project P]` |
| Render PNG | `render --workbook N --project P --view V --out _renders/incoming/V.png [--width W --height H]` |
| Render PDF | `pdf --workbook N --project P --view V --out V.pdf [--landscape]` |
| Refresh extract | `refresh --workbook N --project P [--wait]` |
| Download | `download --workbook N --project P --out folder/` |

A view's name is the worksheet or dashboard name. Views exist only for sheets that aren't hidden. A worksheet used only inside a dashboard may be hidden, so render the dashboard instead.

## Automated render loop (replaces the manual Desktop export)

The QA loop in `tableau-report-cli` ([qa.md](../tableau-report-cli/references/qa.md)) changes only at step 4:

1. `publish --file <workbook> --project <sandbox project> --mode overwrite`. Use a sandbox or dev project, not production.
2. `refresh --wait` if the workbook uses an extract that must be current.
3. `render --view <target> --out <renders_dir>/incoming/<target>.png`.
4. Continue with `check_render` → `pixel_diff` → visual review → `qa_log_attempt` as usual.

`render` passes `maxage=1` so the server returns a fresh image rather than a cached one.

## Publishing workflow

1. Run `validate_workbook` locally and pass QA before publishing to a shared project.
2. `projects` to confirm the exact target project name. Nested projects can share a name; the script refuses ambiguous names.
3. `publish`. Report the returned `webpage_url`.
4. Live connections with prompted passwords need credentials set on the server (Desktop "embed password" or the web UI's data source settings). The script doesn't set connection credentials; tell the user.

## Out of scope (for now)

Permissions, schedules, subscriptions, row-level security, Metadata API (GraphQL) lineage queries. Use the Tableau web UI or extend `tsc_ops.py`.
