# tableau-desktop MCP server

A local stdio MCP server (Python) that reads and writes real Tableau workbook files (`.twb` / `.twbx`) and `.hyper` extracts. Every skill in this repo that changes a workbook goes through these tools, because they back the file up before each write and validate it afterwards.

## Install

```bash
pip install -r requirements.txt
python server.py --selftest     # should end with "All self-tests passed."
```

`tableauhyperapi` is optional. Without it everything works except `create_hyper_extract`, `query_hyper` and `validate_data`.

## Register

The plugin bundles register it for you. To register it by hand, see `mcp-setup/README.md` in the repository.

| Env var | Default | Meaning |
|---|---|---|
| `TABLEAU_CHART_LIBRARY` | `<repo>/chart-library/templates` | Folder holding the chart `*.json` / `*.recipe.json` files. Returned by `get_chart_library_path`. |

## Tools (32)

The full catalog with when-to-use notes is in [../common/MCP-TOOLS.md](../common/MCP-TOOLS.md).

| Group | Tools |
|---|---|
| Inspect | `list_workbooks`, `inspect_workbook`, `list_calculated_fields`, `validate_workbook` |
| Data source | `create_datasource`, `add_calculated_field`, `edit_calculated_field`, `add_parameter`, `list_lod_patterns`, `instantiate_lod_calculation` |
| Extracts | `create_hyper_extract`, `query_hyper`, `validate_data` |
| Chart library | `get_chart_library_path`, `extract_chart_templates`, `list_chart_templates`, `get_chart_template`, `generate_chart_recipe`, `generate_all_chart_recipes` |
| Worksheets | `instantiate_chart_recipe`, `build_crosstab_worksheet`, `add_worksheet_filter` |
| Dashboards | `instantiate_dashboard_layout`, `add_dashboard_action` |
| Render + QA loop | `request_render`, `list_pending_renders`, `check_render`, `pixel_diff`, `approve_baseline`, `qa_log_attempt`, `qa_get_attempts`, `reset_qa_attempts` |
