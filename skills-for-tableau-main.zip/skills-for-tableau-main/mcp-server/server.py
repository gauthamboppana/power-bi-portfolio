#!/usr/bin/env python3
"""
Tableau MCP server for skills-for-tableau (Desktop-first; workbook XML authoring)

Exposes tools for:
  - Inspecting and editing Tableau workbooks (.twb / .twbx) - worksheets,
    dashboards, data sources, calculated fields
  - Building and validating .hyper extracts (data model layer)
  - A file-based render/validate loop (since Tableau Desktop has no
    programmatic render API - see README.md for why)

Run standalone for a smoke test:  python server.py --selftest
"""

import argparse
import io
import json
import os
import re
import shutil
import statistics
import sys
import urllib.parse
import uuid
import zipfile
from datetime import datetime
from pathlib import Path
from xml.etree import ElementTree as ET

from mcp.server.fastmcp import FastMCP

mcp = FastMCP("tableau-desktop")

# --------------------------------------------------------------------------
# Helpers
# --------------------------------------------------------------------------

BACKUP_DIRNAME = "_backups"


def _err(msg: str) -> dict:
    return {"ok": False, "error": msg}


def _ok(**kwargs) -> dict:
    return {"ok": True, **kwargs}


def _dedupe_name(desired: str, existing: set) -> str:
    """
    If `desired` is free in `existing`, return it unchanged. Otherwise
    append " 2", " 3", ... until a free name is found. Used so a rebuild
    over the same starter workbook (e.g. a dashboard/worksheet name that
    matches the source Looker dashboard's own name, run twice) doesn't hard
    fail on a name collision - it just gets a numbered variant instead.
    """
    if desired not in existing:
        return desired
    n = 2
    while f"{desired} {n}" in existing:
        n += 1
    return f"{desired} {n}"


def _backup_dir_for(path: Path) -> Path:
    # Keep backups alongside the workbook, in a sibling _backups folder,
    # rather than scattering .bak files next to the real files.
    d = path.parent / BACKUP_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d


def backup_file(path: str) -> dict:
    """Copy a file to <sibling>/_backups/<name>.<timestamp><ext> before editing it."""
    p = Path(path)
    if not p.exists():
        return _err(f"File not found: {path}")
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    dest = _backup_dir_for(p) / f"{p.stem}.{ts}{p.suffix}"
    shutil.copy2(p, dest)
    return _ok(backup_path=str(dest))


def _is_twbx(path: Path) -> bool:
    return path.suffix.lower() == ".twbx"


def _find_twb_in_zip(zf: zipfile.ZipFile) -> str:
    for name in zf.namelist():
        if name.lower().endswith(".twb"):
            return name
    raise ValueError("No .twb file found inside the .twbx package")


def load_workbook_xml(path: str):
    """
    Returns (ElementTree, kind, extra) where kind is 'twb' or 'twbx'.
    For 'twbx', extra is the inner .twb member name (needed to write back).
    """
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"Workbook not found: {path}")

    if _is_twbx(p):
        with zipfile.ZipFile(p, "r") as zf:
            bad = zf.testzip()
            if bad:
                raise ValueError(f"Corrupt entry in .twbx: {bad}")
            member = _find_twb_in_zip(zf)
            with zf.open(member) as f:
                tree = ET.parse(f)
        return tree, "twbx", member
    elif p.suffix.lower() == ".twb":
        tree = ET.parse(p)
        return tree, "twb", None
    else:
        raise ValueError(f"Not a Tableau workbook file (.twb/.twbx): {path}")


def save_workbook_xml(path: str, tree: ET.ElementTree, kind: str, member: str):
    """Writes the (possibly modified) XML tree back to disk, preserving .twbx packaging."""
    p = Path(path)
    if kind == "twb":
        tree.write(p, encoding="utf-8", xml_declaration=True)
        return

    # twbx: rewrite the zip, replacing only the .twb member, copying everything else byte-for-byte
    buf = io.BytesIO()
    tree.write(buf, encoding="utf-8", xml_declaration=True)
    new_twb_bytes = buf.getvalue()

    tmp_path = p.with_suffix(p.suffix + ".tmp")
    with zipfile.ZipFile(p, "r") as zin, zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            data = zin.read(item.filename)
            if item.filename == member:
                data = new_twb_bytes
            zout.writestr(item, data)
    tmp_path.replace(p)


def _find_datasource(root: ET.Element, name_or_caption: str):
    for ds in root.findall("./datasources/datasource"):
        if ds.get("name") == name_or_caption or ds.get("caption") == name_or_caption:
            return ds
    return None


def _column_info(col: ET.Element) -> dict:
    calc = col.find("calculation")
    return {
        "name": col.get("name"),
        "caption": col.get("caption"),
        "datatype": col.get("datatype"),
        "role": col.get("role"),
        "type": col.get("type"),
        "is_calculated_field": calc is not None,
        "formula": calc.get("formula") if calc is not None else None,
    }


# --------------------------------------------------------------------------
# Tools: discovery / inspection
# --------------------------------------------------------------------------


@mcp.tool()
def list_workbooks(folder: str) -> dict:
    """List .twb/.twbx workbook files found recursively under `folder`."""
    base = Path(folder)
    if not base.exists():
        return _err(f"Folder not found: {folder}")
    results = []
    for ext in ("*.twb", "*.twbx"):
        for f in base.rglob(ext):
            if BACKUP_DIRNAME in f.parts:
                continue
            stat = f.stat()
            results.append({
                "path": str(f),
                "name": f.name,
                "size_bytes": stat.st_size,
                "modified": datetime.fromtimestamp(stat.st_mtime).isoformat(timespec="seconds"),
            })
    return _ok(workbooks=results)


@mcp.tool()
def inspect_workbook(path: str) -> dict:
    """
    Parse a .twb/.twbx and summarize its data sources (with fields and
    calculated fields), worksheets, and dashboards. Read-only.
    """
    try:
        tree, kind, _ = load_workbook_xml(path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    datasources = []
    for ds in root.findall("./datasources/datasource"):
        cols = [_column_info(c) for c in ds.findall("./column")]
        conn = ds.find(".//connection")
        datasources.append({
            "name": ds.get("name"),
            "caption": ds.get("caption"),
            "connection_class": conn.get("class") if conn is not None else None,
            "field_count": len(cols),
            "calculated_field_count": sum(1 for c in cols if c["is_calculated_field"]),
            "fields": cols,
        })

    worksheets = []
    for ws in root.findall("./worksheets/worksheet"):
        mark = ws.find(".//mark")
        worksheets.append({
            "name": ws.get("name"),
            "mark_class": mark.get("class") if mark is not None else None,
        })

    dashboards = []
    for db in root.findall("./dashboards/dashboard"):
        zone_sheets = sorted({
            z.get("name") for z in db.findall(".//zone") if z.get("name")
        })
        dashboards.append({
            "name": db.get("name"),
            "referenced_worksheets": zone_sheets,
        })

    return _ok(
        kind=kind,
        datasources=datasources,
        worksheets=worksheets,
        dashboards=dashboards,
    )


@mcp.tool()
def list_calculated_fields(path: str, datasource_name: str = None) -> dict:
    """List calculated fields (name, formula, datatype) across one or all data sources."""
    try:
        tree, _, _ = load_workbook_xml(path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    out = []
    for ds in root.findall("./datasources/datasource"):
        if datasource_name and ds.get("name") != datasource_name and ds.get("caption") != datasource_name:
            continue
        for col in ds.findall("./column"):
            info = _column_info(col)
            if info["is_calculated_field"]:
                info["datasource"] = ds.get("caption") or ds.get("name")
                out.append(info)
    return _ok(calculated_fields=out)


# --------------------------------------------------------------------------
# Tools: authoring (mutating - always backs up first)
# --------------------------------------------------------------------------


@mcp.tool()
def add_calculated_field(
    path: str,
    datasource_name: str,
    field_name: str,
    formula: str,
    caption: str = None,
    datatype: str = "string",
    role: str = "dimension",
) -> dict:
    """
    Add a new calculated field to a data source inside a .twb/.twbx.
    Always backs up the workbook first. `field_name` should be the internal
    name (e.g. "Profit Ratio") - it will be wrapped in [brackets] automatically
    if not already. `datatype` is one of: string, integer, real, boolean, date,
    datetime. `role` is 'dimension' or 'measure'.
    """
    bkp = backup_file(path)
    if not bkp["ok"]:
        return bkp

    try:
        tree, kind, member = load_workbook_xml(path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    ds = _find_datasource(root, datasource_name)
    if ds is None:
        names = [d.get("name") for d in root.findall("./datasources/datasource")]
        return _err(f"Data source '{datasource_name}' not found. Available: {names}")

    internal_name = field_name if field_name.startswith("[") else f"[{field_name}]"
    # Guard against duplicate field names
    for col in ds.findall("./column"):
        if col.get("name") == internal_name:
            return _err(f"A field named {internal_name} already exists in this data source.")

    col = ET.SubElement(ds, "column")
    col.set("caption", caption or field_name)
    col.set("name", internal_name)
    col.set("datatype", datatype)
    col.set("role", role)
    col.set("type", "nominal" if role == "dimension" else "quantitative")
    calc = ET.SubElement(col, "calculation")
    calc.set("class", "tableau")
    calc.set("formula", formula)

    try:
        save_workbook_xml(path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    return _ok(
        message=f"Added calculated field {internal_name} to {datasource_name}.",
        backup_path=bkp["backup_path"],
        next_step="Reopen the workbook in Tableau Desktop to confirm it loads and the formula is valid.",
    )


@mcp.tool()
def edit_calculated_field(path: str, datasource_name: str, field_name: str, new_formula: str) -> dict:
    """Update the formula of an existing calculated field. Backs up first."""
    bkp = backup_file(path)
    if not bkp["ok"]:
        return bkp

    try:
        tree, kind, member = load_workbook_xml(path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    ds = _find_datasource(root, datasource_name)
    if ds is None:
        return _err(f"Data source '{datasource_name}' not found.")

    internal_name = field_name if field_name.startswith("[") else f"[{field_name}]"
    target = None
    for col in ds.findall("./column"):
        if col.get("name") == internal_name:
            target = col
            break
    if target is None:
        return _err(f"Calculated field {internal_name} not found in {datasource_name}.")

    calc = target.find("calculation")
    if calc is None:
        return _err(f"{internal_name} exists but is not a calculated field (no <calculation> node).")
    calc.set("formula", new_formula)

    try:
        save_workbook_xml(path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    return _ok(
        message=f"Updated formula for {internal_name}.",
        backup_path=bkp["backup_path"],
        next_step="Reopen in Tableau Desktop to confirm the new formula is valid.",
    )


_DATASOURCE_PLATFORMS = {"snowflake", "postgres", "hyper", "excel"}

_DATATYPE_TO_VIZ_TYPE = {
    "string": "nominal",
    "boolean": "nominal",
    "date": "ordinal",
    "datetime": "ordinal",
    "integer": "quantitative",
    "real": "quantitative",
}

# OLE DB remote-type codes and default aggregation, for excel-direct's
# <metadata-records> - verified against a real Desktop-saved .twb with a
# live excel-direct connection for string/datetime/integer/real (130, 7, 20,
# 5 respectively, each paired with the aggregation shown there). boolean's
# code (11, OLE DB VARIANT_BOOL) was a guess for excel specifically (that
# reference file had no boolean column) - but it's now independently
# corroborated: a real live-Postgres .twb's <metadata-records> also uses 11
# for boolean, which is a meaningful cross-check since OLE DB type codes are
# generally connector-agnostic DBTYPE enum values, not vendor-specific.
# That same Postgres reference's other codes do NOT match excel's -
# string=129 (not 130), real=131 (not 5), datetime=135 (not 7) - proving
# remote-type codes vary by source connector and this table must stay
# excel-only; it is NOT currently used for postgres/snowflake, which don't
# emit <metadata-records> at all (see create_datasource's Known limitation
# note). If postgres/snowflake ever gain metadata-records support, these
# Postgres-verified codes (129/131/11/135 for string/real/boolean/datetime;
# integer was not observed as its own remote-type in that file - postgres
# integer columns in it were typed real) are the ones to use, not this
# excel table.
_DATATYPE_TO_REMOTE_TYPE = {"string": "130", "datetime": "7", "date": "7", "integer": "20", "real": "5", "boolean": "11"}
_DATATYPE_TO_DEFAULT_AGGREGATION = {"string": "Count", "boolean": "Count", "date": "Year", "datetime": "Year", "integer": "Sum", "real": "Sum"}


def _connection_attrs(platform: str, server: str, database: str, schema: str, warehouse: str, username: str, password: str = None) -> dict:
    # postgres CONNECTION-LEVEL attrs (server/port/dbname/username/
    # authentication/one-time-sql/sslmode/workgroup-auth-mode) are verified
    # against a real, live-connected .twb (Tableau Desktop-saved, federated
    # datasource over Azure Postgres, multi-table relationship model) - that
    # file has NO `schema` attribute on the <connection> element itself;
    # schema only ever appears embedded in each <relation>'s bracketed
    # "[schema].[table]" reference (see table_name handling below), never as
    # a connection-level attribute. An earlier version of this function
    # added one anyway despite claiming verification - that was wrong and
    # has been removed; `schema` is still accepted as a parameter here
    # because it's needed to build the relation's table reference, just not
    # written onto <connection>. (The single-custom-SQL-relation shape
    # create_datasource's custom_sql path builds was verified separately
    # against a different real reference earlier in this project, though
    # that file's <connection> also had no schema attribute, consistent
    # with what's confirmed here.)
    # snowflake is NOT yet verified against a real sample - attrs
    # (including whether `schema` belongs on <connection> for snowflake,
    # unlike postgres) are a best-effort analogy to the postgres shape and
    # should be treated as unconfirmed until a real snowflake-connected
    # .twb is seen.
    #
    # `password`, if given, is NOT part of that verified shape - the real
    # reference files had no password attribute at all (they were unsaved
    # live connections; Tableau prompted for the password on open). Writing
    # one here is a best-effort addition, not a confirmed-real pattern -
    # only done when the caller explicitly opts in by passing a value.
    if platform == "snowflake":
        attrs = {
            "class": "snowflake", "server": server, "dbname": database, "schema": schema,
            "warehouse": warehouse or "", "username": username or "",
            "authentication": "username-password", "one-time-sql": "",
        }
    elif platform == "postgres":
        attrs = {
            "class": "postgres", "server": server, "port": "5432", "dbname": database,
            "username": username or "", "authentication": "username-password",
            "one-time-sql": "", "sslmode": "require", "workgroup-auth-mode": "",
        }
    else:
        raise ValueError(f"_connection_attrs called for non-live platform: {platform}")
    if password:
        attrs["password"] = password
    return attrs


@mcp.tool()
def create_datasource(
    workbook_path: str,
    datasource_name: str,
    platform: str,
    fields: list,
    caption: str = None,
    server: str = None,
    database: str = None,
    schema: str = "public",
    warehouse: str = None,
    username: str = None,
    password: str = None,
    table_name: str = None,
    custom_sql: str = None,
    hyper_path: str = None,
    hyper_table_name: str = "Extract",
    excel_path: str = None,
    excel_sheet_name: str = None,
) -> dict:
    """
    Add a brand-new data source (a live database connection, a live Excel
    connection, or a local .hyper extract) to a workbook that has none yet -
    this is what turns a truly blank .twb into one the other tools can build
    against, without requiring you to first connect it by hand in Tableau
    Desktop.

    `platform`: one of "snowflake", "postgres", "excel", "hyper".
      - "snowflake" / "postgres": a LIVE database connection. Requires
        `server`, `database`, and exactly one of `table_name`
        (schema-qualified table, e.g. "REPORTING.CLIENT_DIMENSION") or
        `custom_sql` (a full SELECT). `warehouse` is required for snowflake.
        `password` is OPTIONAL and should normally be omitted - the
        verified-safe default is to leave it out and let Tableau Desktop
        prompt for it the first time the workbook is opened. Only pass it
        if the caller explicitly opted in; see the Known limitation note
        below about why this is unverified.
      - "excel": a LIVE connection to an .xlsx file (stays linked to the
        file, re-reads it on refresh - not a baked-in extract). Requires
        `excel_path` (the .xlsx file's path - a path on whatever machine
        will open the workbook, since this is a file link, not upload) and
        `excel_sheet_name` (the worksheet/tab name inside it, without a
        trailing "$"). Every field's `remote_name` must be the exact column
        header text in that sheet's header row.
      - "hyper": a local extract. Requires `hyper_path` (an existing .hyper
        file - build one first with create_hyper_extract) and, optionally,
        `hyper_table_name` if it isn't the default "Extract".

    `fields`: list of dicts describing every field to expose from this data
    source, e.g.
      [{"name": "Client Name", "remote_name": "NAME", "datatype": "string", "role": "dimension"},
       {"name": "Total Amount", "remote_name": "TOTAL_AMOUNT_JMS", "datatype": "real", "role": "measure"}]
    `remote_name` is the actual column name in the source table/query/sheet
    (defaults to `name` if omitted - only safe when they already match).
    `datatype` is one of: string, integer, real, boolean, date, datetime.
    `role` is 'dimension' or 'measure' (defaults to 'measure' for
    integer/real, 'dimension' otherwise).

    Known limitation: the postgres and excel connection shapes (federated
    wrapper, named-connection id scheme, connection attributes,
    relation/cols placement, and for excel the dual
    "_.fcp.ObjectModelEncapsulateLegacy.{true,false}...relation" tags plus
    <metadata-records> remote-type codes) were reverse-engineered from real
    Desktop-saved .twb files with live Postgres and live excel-direct
    connections respectively - not guessed. snowflake uses the postgres
    shape by analogy and is NOT yet verified against a real
    snowflake-connected file - treat it as unconfirmed until one is checked.
    excel's boolean remote-type code (11) is a guess (the reference file had
    no boolean column) - everything else about excel is verified. Always
    open the result in Desktop and check the Data Source tab before
    building further.

    Postgres known gap: only a single relation (one table_name, or one
    custom_sql query) is supported - a real Postgres data source can also
    be built as a multi-table relationship model (Tableau's relationship
    canvas joining several `<relation type="table">` entries inside a
    `<relation type="collection">` wrapper, each with its own per-table
    `<metadata-records>` schema metadata), which this tool does not build.
    If a BRD's Looker explore has multiple joined views, either pre-join
    them into one custom_sql query (what this tool supports today) or build
    the relationship model by hand in Desktop afterward. Also, this tool's
    postgres/snowflake output does not write <metadata-records> at all
    (unlike the excel path) - the real custom-SQL-relation reference this
    shape was checked against didn't establish whether that's required;
    Tableau appears to populate it from the live connection on open, but
    this hasn't been independently confirmed against a real custom-SQL
    postgres file that includes it.

    `password` is a separate, additional unverified bit: the real reference
    files this connector shape was reverse-engineered from had no password
    attribute at all (they were unsaved live connections - Tableau prompted
    for the password on open). Passing `password` here writes a best-effort
    `password="..."` attribute onto the connection element; it is NOT
    confirmed to be the real, correct way Tableau Desktop stores an
    embedded password (or that Desktop will accept/honor it), only done
    when the caller explicitly opts in. Prefer leaving it unset.
    """
    if platform not in _DATASOURCE_PLATFORMS:
        return _err(f"platform must be one of {sorted(_DATASOURCE_PLATFORMS)}, got '{platform}'.")
    if not fields:
        return _err("`fields` must be a non-empty list.")

    if platform in ("snowflake", "postgres"):
        if not server or not database:
            return _err(f"platform='{platform}' requires `server` and `database`.")
        if bool(table_name) == bool(custom_sql):
            return _err("Provide exactly one of `table_name` or `custom_sql` (not both, not neither).")
        if platform == "snowflake" and not warehouse:
            return _err("platform='snowflake' requires `warehouse`.")
    elif platform == "excel":
        if not excel_path or not excel_sheet_name:
            return _err("platform='excel' requires `excel_path` and `excel_sheet_name`.")
    else:  # hyper
        if not hyper_path:
            return _err("platform='hyper' requires `hyper_path`.")
        if not Path(hyper_path).exists():
            return _err(f".hyper file not found: {hyper_path}")

    for f in fields:
        if "name" not in f or "datatype" not in f:
            return _err(f"Every field needs at least 'name' and 'datatype'. Bad entry: {f}")
        if f["datatype"] not in _DATATYPE_TO_VIZ_TYPE:
            return _err(f"Unsupported datatype '{f['datatype']}' on field '{f['name']}'. Use one of {sorted(_DATATYPE_TO_VIZ_TYPE)}.")

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    if _find_datasource(root, datasource_name) is not None:
        return _err(f"A data source named '{datasource_name}' already exists - choose a different name or use the existing one.")

    datasources_el = root.find("./datasources")
    if datasources_el is None:
        datasources_el = ET.SubElement(root, "datasources")

    ds = ET.SubElement(datasources_el, "datasource", {
        "caption": caption or datasource_name,
        "inline": "true",
        "name": datasource_name,
        "version": "18.1",
    })
    ET.SubElement(ds, "aliases", {"enabled": "yes"})

    if platform == "hyper":
        # Local extract: simple non-federated connection, same shape as the
        # plugin's own create_hyper_extract output expects to be pointed at.
        relation_name = hyper_table_name
        conn = ET.SubElement(ds, "connection", {"class": "hyper", "dbname": str(Path(hyper_path).resolve())})
        ET.SubElement(conn, "relation", {"name": hyper_table_name, "table": f"[{hyper_table_name}]", "type": "table"})
    elif platform == "excel":
        # Live Excel: verified against a real Desktop-saved .twb with a live
        # excel-direct connection. Unlike a database connection, the schema
        # (an embedded <columns> block) and field bindings (<metadata-records>)
        # are written directly, not queried later - there's no live schema to
        # ask. Tableau also writes the relation TWICE, under two differently
        # -named tags that are otherwise byte-identical, as a forward/backward
        # -compat mechanism for a feature flag - both are reproduced here so
        # the workbook opens correctly regardless of which flag state the
        # opening Desktop version is on.
        named_conn_id = f"excel-direct.{uuid.uuid4().hex[:8]}"
        relation_name = excel_sheet_name
        federated = ET.SubElement(ds, "connection", {"class": "federated"})
        named_conns = ET.SubElement(federated, "named-connections")
        named_conn = ET.SubElement(named_conns, "named-connection", {"caption": datasource_name, "name": named_conn_id})
        ET.SubElement(named_conn, "connection", {
            "class": "excel-direct", "cleaning": "yes", "compat": "no", "dataRefreshTime": "",
            "filename": str(Path(excel_path).as_posix()), "interpretationMode": "0",
            "password": "", "server": "", "validate": "no",
        })

        for flag in ("false", "true"):
            relation = ET.SubElement(federated, f"_.fcp.ObjectModelEncapsulateLegacy.{flag}...relation", {
                "connection": named_conn_id, "name": relation_name,
                "table": f"[{relation_name}$]", "type": "table",
            })
            columns_el = ET.SubElement(relation, "columns", {
                "header": "yes", "header-row": "1", "outcome": "1",
            })
            for i, f in enumerate(fields):
                remote_name = f.get("remote_name", f["name"])
                ET.SubElement(columns_el, "column", {"datatype": f["datatype"], "name": remote_name, "ordinal": str(i)})

        metadata_records = ET.SubElement(federated, "metadata-records")
        for i, f in enumerate(fields):
            datatype = f["datatype"]
            internal_name = f["name"] if f["name"].startswith("[") else f"[{f['name']}]"
            remote_name = f.get("remote_name", f["name"])
            rec = ET.SubElement(metadata_records, "metadata-record", {"class": "column"})
            for tag, val in (
                ("remote-name", remote_name), ("remote-type", _DATATYPE_TO_REMOTE_TYPE[datatype]),
                ("local-name", internal_name), ("parent-name", f"[{relation_name}]"),
                ("remote-alias", remote_name), ("ordinal", str(i)), ("local-type", datatype),
                ("aggregation", _DATATYPE_TO_DEFAULT_AGGREGATION[datatype]), ("contains-null", "true"),
                ("collation", ""),
            ):
                el = ET.SubElement(rec, tag)
                el.text = val
    else:
        # Live connection: Tableau Desktop always wraps a real database
        # connection as class="federated", with the actual per-platform
        # <connection> nested inside named-connections, and <relation>/<cols>
        # as siblings of that nesting, not children of the inner connection.
        # Verified against a real Desktop-saved .twb with a live Postgres
        # connection - every element here (federated wrapper, named-connection
        # id scheme, <relation type="table"> with a schema-qualified two-part
        # `table` attribute, <cols> placement) matches that file.
        named_conn_id = f"{platform}.{uuid.uuid4().hex[:20]}"
        federated = ET.SubElement(ds, "connection", {"class": "federated"})
        named_conns = ET.SubElement(federated, "named-connections")
        named_conn = ET.SubElement(named_conns, "named-connection", {"caption": server, "name": named_conn_id})
        ET.SubElement(named_conn, "connection", _connection_attrs(platform, server, database, schema, warehouse, username, password))

        if custom_sql:
            relation_name = "Custom SQL Query"
            relation = ET.SubElement(federated, "relation", {"connection": named_conn_id, "name": relation_name, "type": "text"})
            relation.text = custom_sql
        else:
            if "." in table_name:
                table_schema, table_only = table_name.rsplit(".", 1)
            else:
                table_schema, table_only = schema, table_name
            relation_name = table_only
            ET.SubElement(federated, "relation", {
                "connection": named_conn_id, "name": relation_name,
                "table": f"[{table_schema}].[{table_only}]", "type": "table",
            })

        cols_el = ET.SubElement(federated, "cols")
        for f in fields:
            internal_name = f["name"] if f["name"].startswith("[") else f"[{f['name']}]"
            remote_name = f.get("remote_name", f["name"])
            ET.SubElement(cols_el, "map", {"key": internal_name, "value": f"[{relation_name}].[{remote_name}]"})

    for f in fields:
        internal_name = f["name"] if f["name"].startswith("[") else f"[{f['name']}]"
        datatype = f["datatype"]
        role = f.get("role") or ("measure" if datatype in ("integer", "real") else "dimension")
        ET.SubElement(ds, "column", {
            "caption": f.get("caption", f["name"]),
            "datatype": datatype,
            "name": internal_name,
            "role": role,
            "type": _DATATYPE_TO_VIZ_TYPE[datatype],
        })

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    return _ok(
        message=f"Added data source '{datasource_name}' ({platform}) with {len(fields)} field(s).",
        backup_path=bkp["backup_path"],
        next_step=(
            "Reopen in Tableau Desktop and check the Data Source tab: for a live connection, "
            "enter the password when prompted and confirm the field list matches; for hyper, "
            "confirm the extract loads. This was written directly, not queried from a live "
            "schema, so verify field names/types match before building worksheets against it."
        ),
    )


# --------------------------------------------------------------------------
# Tools: validation
# --------------------------------------------------------------------------


def _balanced(s: str, open_c: str, close_c: str) -> bool:
    depth = 0
    for ch in s:
        if ch == open_c:
            depth += 1
        elif ch == close_c:
            depth -= 1
            if depth < 0:
                return False
    return depth == 0


def _strip_string_literals(s: str) -> str:
    """Drop the content of every double-quoted string literal in a Tableau
    calculation formula before checking bracket/paren balance. A formula like
    THEN "Pending Parking Event (>= 3 hours" is completely valid Tableau
    syntax - the unmatched '(' is just part of a label's display text, not
    part of the formula's own grouping structure - so counting brackets
    across the raw formula text produces false positives on any label that
    happens to contain a lone '(' or ')' character (a very ordinary thing for
    real-world labels to do, e.g. ported verbatim from a source system's own
    text). Tableau calc syntax escapes a literal double-quote inside a string
    as two consecutive quotes (""), matching SQL - handled the same way here
    so an escaped quote doesn't prematurely end the literal."""
    out = []
    i, n, in_string = 0, len(s), False
    while i < n:
        ch = s[i]
        if in_string:
            if ch == '"':
                if i + 1 < n and s[i + 1] == '"':
                    i += 2
                    continue
                in_string = False
            i += 1
            continue
        if ch == '"':
            in_string = True
            i += 1
            continue
        out.append(ch)
        i += 1
    return "".join(out)


@mcp.tool()
def validate_workbook(path: str) -> dict:
    """
    Structural validation of a .twb/.twbx: zip integrity, well-formed XML,
    required sections present, and a best-effort sanity check on every
    calculated field's formula (balanced brackets/parens/quotes).
    This is NOT a substitute for opening it in Tableau Desktop - it catches
    obvious breakage before you spend a reload cycle on it.
    """
    issues = []
    p = Path(path)
    if not p.exists():
        return _err(f"File not found: {path}")

    if _is_twbx(p):
        try:
            with zipfile.ZipFile(p, "r") as zf:
                bad = zf.testzip()
                if bad:
                    issues.append(f"Corrupt zip entry: {bad}")
        except zipfile.BadZipFile as e:
            return _ok(passed=False, issues=[f"Not a valid zip file: {e}"])

    try:
        tree, kind, _ = load_workbook_xml(path)
    except Exception as e:
        return _ok(passed=False, issues=issues + [f"XML parse failed: {e}"])
    root = tree.getroot()

    if root.tag != "workbook":
        issues.append(f"Unexpected root element <{root.tag}>, expected <workbook>")
    if root.find("./datasources") is None:
        issues.append("Missing <datasources> section")
    if root.find("./worksheets") is None:
        issues.append("Missing <worksheets> section")

    formula_issues = []
    for ds in root.findall("./datasources/datasource"):
        for col in ds.findall("./column"):
            calc = col.find("calculation")
            if calc is None:
                continue
            formula = calc.get("formula") or ""
            stripped = _strip_string_literals(formula)
            checks = [
                _balanced(stripped, "(", ")"),
                _balanced(stripped, "[", "]"),
                formula.count('"') % 2 == 0,
            ]
            if not all(checks):
                formula_issues.append({
                    "datasource": ds.get("caption") or ds.get("name"),
                    "field": col.get("name"),
                    "formula": formula,
                })
    if formula_issues:
        issues.append({"unbalanced_formulas": formula_issues})

    return _ok(passed=len(issues) == 0, issues=issues)


# --------------------------------------------------------------------------
# Tools: data model layer (Hyper API) - guarded import
# --------------------------------------------------------------------------


def _hyper_available():
    try:
        import tableauhyperapi  # noqa: F401
        return True
    except ImportError:
        return False


@mcp.tool()
def create_hyper_extract(csv_path: str, hyper_path: str, table_name: str = "Extract") -> dict:
    """
    Build a .hyper extract from a CSV file. Infers column types from the
    first 500 rows (via pandas if available, else treats everything as text).
    Requires the `tableauhyperapi` package (pip install tableauhyperapi).
    """
    if not _hyper_available():
        return _err(
            "tableauhyperapi is not installed. Run: pip install tableauhyperapi"
        )
    from tableauhyperapi import (
        HyperProcess, Telemetry, Connection, CreateMode,
        TableDefinition, SqlType, TableName, Inserter,
    )

    csv_p = Path(csv_path)
    if not csv_p.exists():
        return _err(f"CSV not found: {csv_path}")

    try:
        import pandas as pd
        df = pd.read_csv(csv_p)
        dtype_map = {
            "int64": SqlType.big_int(),
            "float64": SqlType.double(),
            "bool": SqlType.bool(),
            "datetime64[ns]": SqlType.timestamp(),
        }
        columns = []
        for col in df.columns:
            sql_type = dtype_map.get(str(df[col].dtype), SqlType.text())
            columns.append(TableDefinition.Column(col, sql_type))
        rows = df.itertuples(index=False, name=None)
    except ImportError:
        import csv as csvmod
        with open(csv_p, newline="", encoding="utf-8") as f:
            reader = csvmod.reader(f)
            header = next(reader)
            rows_list = list(reader)
        columns = [TableDefinition.Column(h, SqlType.text()) for h in header]
        rows = rows_list

    table_def = TableDefinition(table_name=TableName(table_name), columns=columns)

    with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
        with Connection(endpoint=hp.endpoint, database=hyper_path, create_mode=CreateMode.CREATE_AND_REPLACE) as conn:
            conn.catalog.create_table(table_def)
            with Inserter(conn, table_def) as inserter:
                inserter.add_rows(rows=rows)
                inserter.execute()

    return _ok(message=f"Created {hyper_path} with table '{table_name}'.", row_count_source=str(csv_p))


@mcp.tool()
def query_hyper(hyper_path: str, sql: str) -> dict:
    """Run a read-only SQL query against a .hyper extract and return rows."""
    if not _hyper_available():
        return _err("tableauhyperapi is not installed. Run: pip install tableauhyperapi")
    from tableauhyperapi import HyperProcess, Telemetry, Connection

    if not Path(hyper_path).exists():
        return _err(f".hyper file not found: {hyper_path}")

    with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
        with Connection(endpoint=hp.endpoint, database=hyper_path) as conn:
            result = conn.execute_list_query(sql)
    return _ok(rows=result, row_count=len(result))


@mcp.tool()
def validate_data(hyper_path: str, table_name: str, rules: dict) -> dict:
    """
    Run data-level validation checks against a .hyper extract table.
    `rules` example:
      {
        "row_count_min": 1, "row_count_max": 1000000,
        "not_null_columns": ["revenue", "region"],
        "bounds": {"revenue": [0, null]}
      }
    Returns a pass/fail per rule plus the actual observed values.
    """
    if not _hyper_available():
        return _err("tableauhyperapi is not installed. Run: pip install tableauhyperapi")
    from tableauhyperapi import HyperProcess, Telemetry, Connection

    if not Path(hyper_path).exists():
        return _err(f".hyper file not found: {hyper_path}")

    results = []
    with HyperProcess(telemetry=Telemetry.DO_NOT_SEND_USAGE_DATA_TO_TABLEAU) as hp:
        with Connection(endpoint=hp.endpoint, database=hyper_path) as conn:
            row_count = conn.execute_scalar_query(f'SELECT COUNT(*) FROM "{table_name}"')

            if "row_count_min" in rules:
                results.append({
                    "rule": "row_count_min", "expected": rules["row_count_min"],
                    "actual": row_count, "passed": row_count >= rules["row_count_min"],
                })
            if "row_count_max" in rules:
                results.append({
                    "rule": "row_count_max", "expected": rules["row_count_max"],
                    "actual": row_count, "passed": row_count <= rules["row_count_max"],
                })

            for col in rules.get("not_null_columns", []):
                nulls = conn.execute_scalar_query(
                    f'SELECT COUNT(*) FROM "{table_name}" WHERE "{col}" IS NULL'
                )
                results.append({
                    "rule": f"not_null:{col}", "expected": 0,
                    "actual": nulls, "passed": nulls == 0,
                })

            for col, bounds in rules.get("bounds", {}).items():
                lo, hi = bounds
                if lo is not None:
                    below = conn.execute_scalar_query(
                        f'SELECT COUNT(*) FROM "{table_name}" WHERE "{col}" < {lo}'
                    )
                    results.append({
                        "rule": f"min_bound:{col}>={lo}", "actual_violations": below,
                        "passed": below == 0,
                    })
                if hi is not None:
                    above = conn.execute_scalar_query(
                        f'SELECT COUNT(*) FROM "{table_name}" WHERE "{col}" > {hi}'
                    )
                    results.append({
                        "rule": f"max_bound:{col}<={hi}", "actual_violations": above,
                        "passed": above == 0,
                    })

    all_passed = all(r["passed"] for r in results)
    return _ok(passed=all_passed, row_count=row_count, checks=results)


# --------------------------------------------------------------------------
# Tools: render / validate loop (file-based hand-off, see README)
# --------------------------------------------------------------------------


@mcp.tool()
def request_render(workbook_path: str, target_name: str, renders_dir: str) -> dict:
    """
    Register a render request for a human to fulfill in Tableau Desktop
    (reload the workbook, select `target_name` worksheet/dashboard, File >
    Export Image, save into <renders_dir>/incoming/). Writes a small JSON
    marker into <renders_dir>/pending/ so the request is tracked.
    """
    pending = Path(renders_dir) / "pending"
    pending.mkdir(parents=True, exist_ok=True)
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in target_name)
    ts = datetime.now().strftime("%Y%m%d-%H%M%S")
    request_file = pending / f"{safe_name}.{ts}.json"
    suggested_filename = f"{safe_name}.{ts}.png"
    request_file.write_text(json.dumps({
        "workbook_path": workbook_path,
        "target_name": target_name,
        "requested_at": datetime.now().isoformat(timespec="seconds"),
        "suggested_filename": suggested_filename,
    }, indent=2), encoding="utf-8")
    return _ok(
        request_file=str(request_file),
        instructions=(
            f"In Tableau Desktop: reload '{workbook_path}', open '{target_name}', "
            f"File > Export Image, save as '{suggested_filename}' into {Path(renders_dir) / 'incoming'}."
        ),
        expected_incoming_path=str(Path(renders_dir) / "incoming" / suggested_filename),
    )


@mcp.tool()
def list_pending_renders(renders_dir: str) -> dict:
    """List outstanding render requests and whether their expected image has arrived yet."""
    pending = Path(renders_dir) / "pending"
    incoming = Path(renders_dir) / "incoming"
    out = []
    if pending.exists():
        for f in sorted(pending.glob("*.json")):
            req = json.loads(f.read_text(encoding="utf-8"))
            expected = incoming / req["suggested_filename"]
            out.append({**req, "request_file": str(f), "arrived": expected.exists()})
    return _ok(requests=out)


@mcp.tool()
def check_render(image_path: str) -> dict:
    """
    Basic technical sanity checks on an exported render image: is it a
    readable image, its dimensions, and whether it looks suspiciously blank
    (near-zero pixel variance, e.g. an all-white export). Does NOT judge
    whether the content is correct - do that by reading the image directly
    and comparing it against the data validation results and the design
    intent.
    """
    try:
        from PIL import Image
    except ImportError:
        return _err("Pillow is not installed. Run: pip install Pillow")

    p = Path(image_path)
    if not p.exists():
        return _err(f"Image not found: {image_path}")

    try:
        img = Image.open(p).convert("L")  # grayscale for a quick variance check
    except Exception as e:
        return _err(f"Could not open image (corrupt export?): {e}")

    pixels = list(img.getdata())
    stdev = statistics.pstdev(pixels) if len(pixels) > 1 else 0

    return _ok(
        width=img.width,
        height=img.height,
        pixel_stdev=round(stdev, 2),
        possibly_blank=stdev < 3.0,
        note="possibly_blank=true means unusually low variance (near-solid color) - check the export wasn't empty.",
    )


@mcp.tool()
def pixel_diff(baseline_path: str, new_path: str, diff_out_path: str = None) -> dict:
    """
    Compare a new render against an approved baseline image. Returns the
    percentage of differing pixels. A high percentage is a FLAG for review,
    not an automatic failure - legitimate data changes will also show up
    as diffs.
    """
    try:
        from PIL import Image, ImageChops
    except ImportError:
        return _err("Pillow is not installed. Run: pip install Pillow")

    bp, np_ = Path(baseline_path), Path(new_path)
    if not bp.exists():
        return _err(f"Baseline image not found: {baseline_path}")
    if not np_.exists():
        return _err(f"New image not found: {new_path}")

    base_img = Image.open(bp).convert("RGB")
    new_img = Image.open(np_).convert("RGB")

    resized = False
    if base_img.size != new_img.size:
        new_img = new_img.resize(base_img.size)
        resized = True

    diff = ImageChops.difference(base_img, new_img)
    diff_data = list(diff.getdata())
    differing = sum(1 for px in diff_data if any(c > 10 for c in px))
    total = len(diff_data)
    pct = round(100 * differing / total, 2) if total else 0.0

    if diff_out_path:
        diff.save(diff_out_path)

    return _ok(
        diff_percent=pct,
        resized_new_image_to_match_baseline=resized,
        diff_image=diff_out_path,
        flag_for_review=pct > 2.0,
    )


@mcp.tool()
def approve_baseline(new_path: str, baseline_path: str) -> dict:
    """
    Promote a reviewed render to become the new baseline for future
    pixel_diff comparisons. Only call this after explicit human or LLM
    visual-review approval - never automatically after a passing check.
    """
    np_, bp = Path(new_path), Path(baseline_path)
    if not np_.exists():
        return _err(f"New image not found: {new_path}")
    bp.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(np_, bp)
    return _ok(message=f"Baseline updated: {baseline_path}")


# --------------------------------------------------------------------------
# Tools: fix loop state tracking
#
# The QA agent and builder agents (datasource/report) hand a target back and
# forth across a fix loop: build -> validate -> fail -> fix -> validate again.
# These tools give that loop real, file-backed state instead of relying on an
# agent "remembering" how many attempts have happened - agents don't reliably
# carry that across separate invocations, so the retry cap has to live here.
# --------------------------------------------------------------------------

QA_LOG_DIRNAME = "_qa"


def _qa_log_path(renders_dir: str, target_name: str) -> Path:
    safe_name = "".join(c if c.isalnum() or c in "-_" else "_" for c in target_name)
    d = Path(renders_dir).parent / QA_LOG_DIRNAME
    d.mkdir(parents=True, exist_ok=True)
    return d / f"{safe_name}.json"


@mcp.tool()
def qa_log_attempt(renders_dir: str, target_name: str, passed: bool, notes: str = "") -> dict:
    """
    Record one fix-loop attempt (pass or fail) for a named worksheet/dashboard
    target. Call this every time the QA agent finishes a validate pass -
    whether it passed or failed - so the attempt count is accurate. Returns
    the running attempt number and history.
    """
    log_path = _qa_log_path(renders_dir, target_name)
    history = json.loads(log_path.read_text(encoding="utf-8")) if log_path.exists() else []
    history.append({
        "attempt": len(history) + 1,
        "passed": passed,
        "notes": notes,
        "timestamp": datetime.now().isoformat(timespec="seconds"),
    })
    log_path.write_text(json.dumps(history, indent=2), encoding="utf-8")
    return _ok(attempt_number=len(history), passed=passed, history=history)


@mcp.tool()
def qa_get_attempts(renders_dir: str, target_name: str) -> dict:
    """
    Get the fix-loop history for a target: attempt count, whether the most
    recent attempt passed, and every prior failure's notes. Call this before
    starting a fix so you know how many retries have already happened and
    don't repeat a fix that already failed.
    """
    log_path = _qa_log_path(renders_dir, target_name)
    if not log_path.exists():
        return _ok(attempt_count=0, last_passed=None, history=[])
    history = json.loads(log_path.read_text(encoding="utf-8"))
    return _ok(
        attempt_count=len(history),
        last_passed=history[-1]["passed"] if history else None,
        history=history,
    )


@mcp.tool()
def reset_qa_attempts(renders_dir: str, target_name: str) -> dict:
    """Clear the fix-loop history for a target - use when starting fresh work on it, not to dodge a retry cap."""
    log_path = _qa_log_path(renders_dir, target_name)
    if log_path.exists():
        log_path.unlink()
    return _ok(message=f"Cleared QA attempt history for {target_name}.")


# --------------------------------------------------------------------------
# Tools: chart template library
#
# Extracts each worksheet from a seed workbook (e.g. a Tableau Public
# reference file with many chart types) into a standalone, catalogable
# template: its full worksheet XML plus which fields/datasource it depends
# on. This is READ-ONLY against the seed workbook - it doesn't modify it.
#
# What this does NOT yet do: clone a template into a different workbook and
# remap its field references to that workbook's own data. That "instantiate"
# step needs to rewrite datasource-dependencies, column-instance names,
# shelf-sort references, and repository-location/id fields consistently -
# real work, being built next. For now, templates are for cataloging and
# for a human to reference/copy from in Desktop, and for the field/mark
# metadata to inform tableau-report-cli design mode's chart recommendations.
# --------------------------------------------------------------------------

CHART_TEMPLATE_DIRNAME = "chart_templates"

# Where the bundled 81-chart library lives. In the plugin bundle this is
# <plugin root>/chart-library/templates; TABLEAU_CHART_LIBRARY overrides it.
DEFAULT_CHART_LIBRARY = os.environ.get(
    "TABLEAU_CHART_LIBRARY",
    str(Path(__file__).resolve().parent.parent / "chart-library" / "templates"),
)


@mcp.tool()
def get_chart_library_path() -> dict:
    """
    Return the absolute path of the bundled chart template/recipe library
    (set by the TABLEAU_CHART_LIBRARY env var, else <repo>/chart-library/templates).
    Call this first and pass the result as `templates_dir` to
    list_chart_templates, get_chart_template, generate_chart_recipe and
    instantiate_chart_recipe.
    """
    p = Path(DEFAULT_CHART_LIBRARY)
    if not p.is_dir():
        return _err(f"Chart library not found at {p}. Set TABLEAU_CHART_LIBRARY to the folder holding the *.recipe.json files.")
    recipes = sorted(f.name[:-len(".recipe.json")] for f in p.glob("*.recipe.json"))
    return _ok(templates_dir=str(p), recipe_count=len(recipes), recipes=recipes)


def _safe_template_filename(name: str) -> str:
    safe = "".join(c if c.isalnum() or c in "-_ " else "_" for c in name).strip()
    return safe.replace(" ", "_") + ".json"


@mcp.tool()
def extract_chart_templates(source_workbook: str, templates_dir: str) -> dict:
    """
    Parse every worksheet in `source_workbook` (a .twb/.twbx - e.g. a
    downloaded chart-gallery file where each sheet is one chart type) and
    save each as a standalone template JSON under `templates_dir`, named
    after the worksheet. Catalogs by the worksheet/page name, per-field
    with datatype/role, and mark type. Does not modify the source workbook.
    Re-running overwrites templates with the same name.
    """
    try:
        tree, kind, _ = load_workbook_xml(source_workbook)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    out_dir = Path(templates_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    catalog = []
    skipped = []
    for ws in root.findall("./worksheets/worksheet"):
        name = ws.get("name")
        if not name:
            continue
        mark = ws.find(".//mark")
        mark_class = mark.get("class") if mark is not None else None

        deps = []
        for dep in ws.findall(".//datasource-dependencies"):
            fields = [{
                "name": c.get("name"),
                "caption": c.get("caption"),
                "datatype": c.get("datatype"),
                "role": c.get("role"),
            } for c in dep.findall("column")]
            deps.append({"datasource": dep.get("datasource"), "fields": fields})

        ds_captions = {
            d.get("name"): d.get("caption")
            for d in ws.findall(".//table/view/datasources/datasource")
        }

        try:
            raw_xml = ET.tostring(ws, encoding="unicode")
        except Exception as e:
            skipped.append({"name": name, "reason": f"serialize failed: {e}"})
            continue

        record = {
            "name": name,
            "mark_class": mark_class,
            "datasource_dependencies": deps,
            "datasource_captions": ds_captions,
            "source_workbook": str(source_workbook),
            "extracted_at": datetime.now().isoformat(timespec="seconds"),
            "worksheet_xml": raw_xml,
        }
        filename = _safe_template_filename(name)
        (out_dir / filename).write_text(json.dumps(record, indent=2), encoding="utf-8")

        field_summary = sorted({f["caption"] or f["name"] for d in deps for f in d["fields"]})
        catalog.append({
            "name": name,
            "mark_class": mark_class,
            "template_file": filename,
            "field_count": len(field_summary),
            "fields": field_summary,
        })

    return _ok(
        templates_extracted=len(catalog),
        skipped=skipped,
        catalog=catalog,
        templates_dir=str(out_dir),
    )


@mcp.tool()
def list_chart_templates(templates_dir: str) -> dict:
    """
    List available chart templates (name, mark type, fields used) without
    the full XML payload - use this to browse the library when deciding
    what to build. Call get_chart_template for the full record.
    """
    out_dir = Path(templates_dir)
    if not out_dir.exists():
        return _ok(templates=[])
    templates = []
    for f in sorted(out_dir.glob("*.json")):
        if f.name.endswith(".recipe.json"):
            continue
        try:
            record = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        field_summary = sorted({
            fl["caption"] or fl["name"]
            for d in record.get("datasource_dependencies", [])
            for fl in d.get("fields", [])
        })
        templates.append({
            "name": record.get("name"),
            "mark_class": record.get("mark_class"),
            "template_file": f.name,
            "fields": field_summary,
            "source_workbook": record.get("source_workbook"),
        })
    return _ok(templates=templates, count=len(templates))


@mcp.tool()
def get_chart_template(templates_dir: str, name: str) -> dict:
    """Get the full record (including worksheet XML) for one named chart template."""
    out_dir = Path(templates_dir)
    f = out_dir / _safe_template_filename(name)
    if not f.exists():
        available = [p.stem for p in out_dir.glob("*.json")] if out_dir.exists() else []
        return _err(f"No template named '{name}'. Available: {available}")
    return _ok(template=json.loads(f.read_text(encoding="utf-8")))


# --------------------------------------------------------------------------
# Tools: chart recipes (structured, parametrized upgrade of raw templates)
#
# A "template" (above) is a raw extracted worksheet - useful as a reference,
# but every field reference in it is specific to the seed workbook. A
# "recipe" tokenizes those field references into stable placeholders
# ({{DIM1}}, {{MEA1}}, {{DATASOURCE}}, ...) and records which shelf/encoding
# role each one plays (rows, columns, color, size, text/label, tooltip,
# detail, lod). This is the mirror of Power BI's per-visual-type reference
# docs (cartesian.md, card.md, ...) - except derived from real Tableau XML
# instead of a published schema, since Tableau doesn't publish one.
#
# This does NOT yet instantiate a recipe into a target workbook (substituting
# real field names back in, fixing up datasource-dependencies, and inserting
# the result as a new <worksheet> is the next increment) - it produces the
# parametrized pattern that instantiation would consume.
# --------------------------------------------------------------------------


def _tokenize_worksheet_xml(record: dict):
    """
    Returns (xml_template, field_slots, datasource_token_map, error,
    stripped_filters). stripped_filters lists any hardcoded
    <filter>/<groupfilter function="member"> block(s) auto-removed from the
    source template (see the comment further down) - empty when none were
    found. See module docstring above the chart-recipe tools for what this
    does.
    """
    raw_xml = record["worksheet_xml"]
    name = record["name"]
    deps = record.get("datasource_dependencies", [])
    ds_captions = record.get("datasource_captions", {})

    fields, seen = [], set()
    for dep in deps:
        for f in dep.get("fields", []):
            bare = (f.get("name") or "").strip("[]")
            if not bare or bare in seen:
                continue
            seen.add(bare)
            fields.append({**f, "bare": bare, "datasource": dep.get("datasource")})

    dim_i = mea_i = other_i = 0
    slot_map, slots = {}, []
    for f in fields:
        role = f.get("role")
        if role == "dimension":
            dim_i += 1
            ph = f"DIM{dim_i}"
        elif role == "measure":
            mea_i += 1
            ph = f"MEA{mea_i}"
        else:
            other_i += 1
            ph = f"FLD{other_i}"
        slot_map[f["bare"]] = ph
        slots.append({
            "placeholder": ph,
            "role": role,
            "datatype": f.get("datatype"),
            "original_name": f.get("name"),
            "original_caption": f.get("caption"),
            "shelf_locations": [],
        })

    ds_ids = sorted({dep.get("datasource") for dep in deps if dep.get("datasource")}, key=len, reverse=True)
    ds_token_map = {ds: (f"DATASOURCE{i+1}" if len(ds_ids) > 1 else "DATASOURCE") for i, ds in enumerate(ds_ids)}

    xml_t = raw_xml
    # Strip Tableau-Public-specific publish metadata - irrelevant noise that
    # could reference a completely different site once reused elsewhere.
    xml_t = re.sub(r"<repository-location\b.*?/>\s*", "", xml_t, flags=re.DOTALL)
    xml_t = xml_t.replace(f'<worksheet name="{name}">', '<worksheet name="{{WORKSHEET_NAME}}">', 1)

    # The visible chart title (<layout-options><title><formatted-text><run>...)
    # is a completely separate piece of text from the <worksheet name="..">
    # attribute above, and templates extracted from a real source workbook
    # often carry whatever literal title text that source workbook's author
    # happened to type there (e.g. a leftover "<Sheet Name> Chart" placeholder
    # someone never renamed, or a title describing that source's own data) -
    # left alone, that literal text would appear unchanged on every
    # instantiation, regardless of the new worksheet's actual name/purpose.
    # Normalize it to a single run of {{WORKSHEET_NAME}}, so every
    # instantiated chart's visible title actually matches the worksheet it's
    # built for - this does mean any custom bold/color run-formatting on the
    # original title is not preserved, which is an acceptable tradeoff
    # against showing flatly wrong or vestigial title text.
    xml_t = re.sub(
        r'(<title>\s*<formatted-text>).*?(</formatted-text>\s*</title>)',
        r'\1<run>{{WORKSHEET_NAME}}</run>\2',
        xml_t, count=1, flags=re.DOTALL,
    )

    for ds in ds_ids:
        xml_t = xml_t.replace(ds, f"{{{{{ds_token_map[ds]}}}}}")
    for ds, cap in ds_captions.items():
        if cap:
            xml_t = xml_t.replace(f'caption="{cap}"', 'caption="{{DATASOURCE_CAPTION}}"')

    pairs = []
    for f in fields:
        pairs.append((f["bare"], slot_map[f["bare"]]))
        cap = f.get("caption")
        if cap and cap != f["bare"]:
            pairs.append((cap, slot_map[f["bare"]]))
    pairs.sort(key=lambda p: len(p[0]), reverse=True)  # longest-first avoids partial-substring clobbering
    for literal, ph in pairs:
        xml_t = xml_t.replace(literal, f"{{{{{ph}}}}}")

    # Classify shelf/encoding role per placeholder by re-parsing the
    # tokenized XML (braces are swapped for a parse-safe marker first, since
    # {{...}} isn't valid inside some XML contexts we care about matching).
    ph_by_name = {s["placeholder"]: s for s in slots}
    try:
        parse_safe = xml_t.replace("{{", "__").replace("}}", "__")
        root = ET.fromstring(parse_safe)
    except ET.ParseError as e:
        return xml_t, slots, ds_token_map, f"XML re-parse failed after tokenizing: {e}", []

    def mark_location(text, loc):
        if not text:
            return
        for m in re.finditer(r"__(\w+?)__", text):
            token = m.group(1)
            if token in ph_by_name and loc not in ph_by_name[token]["shelf_locations"]:
                ph_by_name[token]["shelf_locations"].append(loc)

    table = root.find(".//table")
    if table is not None:
        rows_el, cols_el = table.find("rows"), table.find("cols")
        mark_location(rows_el.text if rows_el is not None else None, "rows")
        mark_location(cols_el.text if cols_el is not None else None, "columns")
        for pane in table.findall(".//panes/pane"):
            enc = pane.find("encodings")
            if enc is None:
                continue
            for child in enc:
                mark_location(child.get("column"), child.tag)  # color/size/text/tooltip/detail/shape/lod/label

    # A <filter> whose <groupfilter function="member" member="..."> enumerates
    # specific literal data values (e.g. member="2021") is a snapshot of
    # whatever the *source* reference workbook's view happened to be
    # filtered to at extraction time - not something field_mapping can
    # override (field_mapping only substitutes field/column names, never
    # filter *values*). Left in place, every future instantiation of this
    # recipe silently inherits that one workbook's specific filter
    # regardless of the caller's real data - which is exactly how this
    # class of bug shipped a hardcoded "member=2021/2022" filter into three
    # unrelated builds of the "Bar (Side By Side)" template. A reusable
    # template whose whole point is being reused across different data can
    # never legitimately depend on one specific literal value surviving
    # from extraction, so - the same way the repository-location strip
    # above treats Tableau-Public-specific publish metadata as noise to
    # remove, not preserve - this is stripped automatically rather than
    # merely flagged: the <filter> block and its matching <slices><column>
    # entry are removed, and the stripped values are reported back (not
    # silently dropped) so a human can sanity-check the removal.
    # Critical distinction: a member value like member="2021" is a plain
    # literal, unrelated to any tokenized field - safe to treat as
    # incidental noise. But a member value like
    # member="&quot;[{{DATASOURCE}}].[sum:{{MEA1}}:qk]&quot;" itself embeds a
    # {{...}} placeholder - meaning this is a "Measure Names" filter
    # selecting WHICH mapped measures appear on the shelf, the mechanism
    # multi-measure patterns (Barbell, Funnel, Min/Max/Avg, ...) depend on
    # to work at all. Stripping that would silently break the chart, not
    # fix a bug. So: only auto-strip when EVERY member value in the filter
    # is placeholder-free; if even one value references a placeholder (or
    # the filter is a mix of both), leave it untouched and surface a
    # blocking tokenization_warning instead of guessing which part is safe
    # to remove.
    ambiguous_filters = []
    stripped_filter_values = []

    def _strip_member_filter(m):
        block = m.group(0)
        values = re.findall(r'\bmember="([^"]*)"', block)
        if not values:
            return block  # not a member-enumeration filter - leave untouched
        col_m = re.search(r'<filter\b[^>]*\bcolumn="([^"]*)"', block)
        column = col_m.group(1) if col_m else None
        if any("{{" in v for v in values):
            # At least one value is field-placeholder-driven - could be
            # legitimate (Measure Names selection) or a mix of that and
            # incidental literals. Don't guess which: leave the filter as
            # written and flag for human review instead of silently acting.
            ambiguous_filters.append({"column": column, "values": values})
            return block
        stripped_filter_values.append({"column": column, "values": values})
        return ""

    xml_t = re.sub(r'<filter\b[^>]*>.*?</filter>\s*', _strip_member_filter, xml_t, flags=re.DOTALL)

    if ambiguous_filters:
        return xml_t, slots, ds_token_map, (
            f"Recipe has {len(ambiguous_filters)} filter(s) with member value(s) that reference "
            f"field placeholders, mixed with possibly-hardcoded literals - not auto-stripped "
            f"because that could silently break a legitimate pattern (e.g. a Measure Names filter "
            f"selecting which mapped measures a multi-measure chart shows): {ambiguous_filters}. "
            "Review manually: if a value is genuinely just extraction-source noise, remove it by "
            "hand from the xml_template and regenerate; if it's selecting mapped measures/fields, "
            "leave it as-is."
        ), stripped_filter_values

    if stripped_filter_values:
        stripped_cols = {sf["column"] for sf in stripped_filter_values if sf["column"]}

        def _strip_matching_slice(m):
            block = m.group(0)
            remaining = re.sub(
                r'<column>\s*([^<]*?)\s*</column>\s*',
                lambda cm: "" if cm.group(1).strip() in stripped_cols else cm.group(0),
                block,
            )
            # If every <column> entry was removed, drop the whole <slices> wrapper too.
            if not re.search(r'<column>', remaining):
                return ""
            return remaining

        xml_t = re.sub(r'<slices>.*?</slices>\s*', _strip_matching_slice, xml_t, flags=re.DOTALL)

    # Re-validate the XML still parses after stripping, so a malformed strip
    # surfaces as a clear warning rather than a silently broken template.
    if stripped_filter_values:
        try:
            ET.fromstring(xml_t.replace("{{", "__").replace("}}", "__"))
        except ET.ParseError as e:
            return xml_t, slots, ds_token_map, (
                f"Auto-removing hardcoded filter value(s) {stripped_filter_values} left the XML "
                f"malformed ({e}) - needs manual review before this recipe is usable."
            ), stripped_filter_values

    return xml_t, slots, ds_token_map, None, stripped_filter_values


@mcp.tool()
def generate_chart_recipe(templates_dir: str, name: str) -> dict:
    """
    Convert one raw chart template into a structured, parametrized recipe:
    field references become stable placeholders ({{DIM1}}, {{MEA1}},
    {{DATASOURCE}}, ...) tagged with which shelf/encoding role each plays
    (rows, columns, color, size, text, tooltip, detail, lod). Writes
    <name>.recipe.json alongside the template. This is a read step over the
    template - it doesn't touch any real workbook.
    """
    out_dir = Path(templates_dir)
    f = out_dir / _safe_template_filename(name)
    if not f.exists():
        available = [p.stem for p in out_dir.glob("*.json") if not p.name.endswith(".recipe.json")]
        return _err(f"No template named '{name}'. Available: {available}")
    record = json.loads(f.read_text(encoding="utf-8"))

    xml_t, slots, ds_token_map, error, stripped_filters = _tokenize_worksheet_xml(record)
    recipe = {
        "name": record["name"],
        "mark_class": record.get("mark_class"),
        "datasource_tokens": list(ds_token_map.values()),
        "field_slots": slots,
        "xml_template": xml_t,
        "tokenization_warning": error,
        "stripped_hardcoded_filters": stripped_filters,
        "source_template": f.name,
        "generated_at": datetime.now().isoformat(timespec="seconds"),
    }
    recipe_path = out_dir / (f.stem + ".recipe.json")
    recipe_path.write_text(json.dumps(recipe, indent=2), encoding="utf-8")

    return _ok(
        recipe_file=recipe_path.name,
        field_slots=[{k: v for k, v in s.items() if k != "original_name" or True} for s in slots],
        tokenization_warning=error,
        stripped_hardcoded_filters=stripped_filters,
    )


@mcp.tool()
def generate_all_chart_recipes(templates_dir: str) -> dict:
    """Run generate_chart_recipe over every template in templates_dir. Returns a summary and any warnings."""
    out_dir = Path(templates_dir)
    if not out_dir.exists():
        return _err(f"Templates dir not found: {templates_dir}")
    results = []
    for f in sorted(out_dir.glob("*.json")):
        if f.name.endswith(".recipe.json"):
            continue
        record = json.loads(f.read_text(encoding="utf-8"))
        name = record.get("name")
        if not name:
            continue
        r = generate_chart_recipe(templates_dir, name)
        results.append({
            "name": name,
            "ok": r["ok"],
            "warning": r.get("tokenization_warning"),
            "stripped_hardcoded_filters": r.get("stripped_hardcoded_filters") or [],
            "field_count": len(r.get("field_slots", [])) if r["ok"] else None,
        })
    warnings = [r for r in results if r.get("warning")]
    stripped = [r for r in results if r.get("stripped_hardcoded_filters")]
    return _ok(
        recipes_generated=sum(1 for r in results if r["ok"]),
        total=len(results),
        warnings=warnings,
        recipes_with_stripped_filters=stripped,
        results=results,
    )


def _safe_recipe_filename(name: str) -> str:
    return _safe_template_filename(name)[:-len(".json")] + ".recipe.json"


def _target_datasource_columns(ds: ET.Element) -> dict:
    """Bare-name -> {role, datatype, is_calculated} for every column (raw or calculated) in a target datasource element."""
    out = {}
    for col in ds.findall("./column"):
        bare = (col.get("name") or "").strip("[]")
        if not bare:
            continue
        out[bare] = {
            "role": col.get("role"),
            "datatype": col.get("datatype"),
            "is_calculated": col.find("calculation") is not None,
        }
    return out


@mcp.tool()
def instantiate_chart_recipe(
    workbook_path: str,
    templates_dir: str,
    recipe_name: str,
    datasource_name: str,
    field_mapping: dict,
    new_worksheet_name: str,
) -> dict:
    """
    Build a real, working worksheet in `workbook_path` from a chart recipe,
    substituting your target datasource's real fields in place of the
    recipe's placeholders. This is the instantiation step that turns the
    template/recipe library from a reference into an actual build.

    If `new_worksheet_name` collides with a worksheet already in the
    workbook, it is NOT rejected - it's auto-suffixed (" 2", " 3", ...)
    to a free name instead, so you can safely pass the chart's natural
    name (e.g. matching the source Looker tile's title) without first
    checking for collisions. The response's `worksheet_name` field is the
    name actually used (`renamed: true` when it differs from what you
    asked for) - use that value, not your original request, when placing
    this worksheet into a dashboard layout.

    `field_mapping`: {"DIM1": "Sub-Category", "MEA1": {"field": "Sales", "caption": "Total Sales"}}
    - keys are the placeholders from the recipe's field_slots (call
      generate_chart_recipe first to see them)
    - values are either a bare target field internal name (string, without
      brackets - must already exist in `datasource_name`, as a raw column or
      a calculated field), or a dict with "field" and optional "caption"

    Backs up the workbook before writing. Does NOT run validate_workbook or
    the render loop for you - always run those after, and treat "the file
    saved" as the start of verification, not the end of it. The new
    worksheet is not attached to any dashboard - add it there separately if
    needed.

    Known limitation: this assumes your mapped field's datatype is
    compatible with the recipe's original slot (e.g. swapping one string
    dimension for another). Substituting a field of a meaningfully
    different datatype (e.g. a date into a slot built from a string) may
    produce a worksheet that fails to reopen cleanly in Desktop - that's
    exactly what the validate/render/fix loop after this is for.
    """
    recipe_path = Path(templates_dir) / _safe_recipe_filename(recipe_name)
    if not recipe_path.exists():
        available = [p.name[:-len(".recipe.json")] for p in Path(templates_dir).glob("*.recipe.json")] if Path(templates_dir).exists() else []
        return _err(f"No recipe named '{recipe_name}'. Available: {available}. Run generate_chart_recipe first.")
    recipe = json.loads(recipe_path.read_text(encoding="utf-8"))
    if recipe.get("tokenization_warning"):
        return _err(f"Recipe '{recipe_name}' has an unresolved tokenization warning: {recipe['tokenization_warning']}. Fix the recipe before instantiating from it.")

    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    ds = _find_datasource(root, datasource_name)
    if ds is None:
        names = [d.get("name") for d in root.findall("./datasources/datasource")]
        return _err(f"Data source '{datasource_name}' not found in {workbook_path}. Available: {names}")

    existing_ws_names = {w.get("name") for w in root.findall("./worksheets/worksheet")}
    requested_worksheet_name = new_worksheet_name
    new_worksheet_name = _dedupe_name(new_worksheet_name, existing_ws_names)
    ws_renamed = new_worksheet_name != requested_worksheet_name

    target_columns = _target_datasource_columns(ds)
    slots = recipe["field_slots"]
    slot_by_placeholder = {s["placeholder"]: s for s in slots}

    missing = [ph for ph in slot_by_placeholder if ph not in field_mapping]
    if missing:
        return _err(
            f"field_mapping is missing entries for: {missing}. "
            f"Recipe field_slots: {[(s['placeholder'], s['role'], s['original_caption'] or s['original_name']) for s in slots]}"
        )

    resolved = {}  # placeholder -> (bare_field_name, caption_or_None)
    role_errors = []
    for ph, value in field_mapping.items():
        if ph not in slot_by_placeholder:
            continue  # ignore extra keys the caller passed that aren't real slots
        if isinstance(value, dict):
            field, caption = value.get("field"), value.get("caption")
        else:
            field, caption = value, None
        bare = (field or "").strip("[]")
        target_info = target_columns.get(bare)
        if target_info is None:
            role_errors.append(f"{ph}: field '{bare}' not found in datasource '{datasource_name}' (add it first, or check spelling/caption vs internal name)")
            continue
        expected_role = slot_by_placeholder[ph]["role"]
        if expected_role and target_info["role"] and target_info["role"] != expected_role:
            role_errors.append(f"{ph}: recipe expects a {expected_role}, but '{bare}' is a {target_info['role']}")
            continue
        resolved[ph] = (bare, caption)

    if role_errors:
        return _err("field_mapping has problems: " + "; ".join(role_errors))

    xml_t = recipe["xml_template"]

    fresh_uuid = "{" + str(uuid.uuid4()).upper() + "}"
    xml_t = re.sub(r'<simple-id uuid="\{[0-9A-Fa-f-]+\}" />', f'<simple-id uuid="{fresh_uuid}" />', xml_t)

    xml_t = xml_t.replace("{{WORKSHEET_NAME}}", new_worksheet_name)
    xml_t = xml_t.replace("{{DATASOURCE_CAPTION}}", ds.get("caption") or ds.get("name") or "")
    xml_t = xml_t.replace("{{DATASOURCE}}", ds.get("name") or "")

    for ph, (bare, caption) in resolved.items():
        if caption:
            xml_t = xml_t.replace('caption="{{' + ph + '}}"', f'caption="{caption}"')
        xml_t = xml_t.replace("{{" + ph + "}}", bare)

    leftover = sorted(set(re.findall(r"\{\{(\w+)\}\}", xml_t)))
    if leftover:
        return _err(f"Unresolved placeholders after substitution: {leftover} - this shouldn't happen if field_mapping covered every field_slot; check for a recipe bug.")

    try:
        new_ws_el = ET.fromstring(xml_t)
    except ET.ParseError as e:
        return _err(f"Instantiated worksheet XML is not well-formed: {e}. Nothing was written.")

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    worksheets_el = root.find("./worksheets")
    if worksheets_el is None:
        worksheets_el = ET.SubElement(root, "worksheets")
    worksheets_el.append(new_ws_el)

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    ws_message = f"Instantiated '{recipe_name}' as new worksheet '{new_worksheet_name}' in {workbook_path}."
    if ws_renamed:
        ws_message += (
            f" Note: a worksheet named '{requested_worksheet_name}' already existed in this "
            f"workbook, so this one was saved as '{new_worksheet_name}' instead - use that name "
            f"when placing it into a dashboard layout."
        )
    return _ok(
        message=ws_message,
        worksheet_name=new_worksheet_name,
        requested_worksheet_name=requested_worksheet_name,
        renamed=ws_renamed,
        backup_path=bkp["backup_path"],
        field_mapping_used={ph: bare for ph, (bare, _c) in resolved.items()},
        next_steps=[
            "Run validate_workbook to catch structural issues before opening Desktop.",
            "Reopen the workbook in Tableau Desktop to confirm it loads cleanly - this is the real test, not the XML validation.",
            "The new worksheet is not on any dashboard yet - add it manually if needed.",
            "Run the request_render / check_render / pixel_diff loop (TableauQA agent / tableau-report-cli qa mode) before treating this chart as done.",
        ],
    )


@mcp.tool()
def add_worksheet_filter(
    workbook_path: str,
    worksheet_name: str,
    datasource_name: str,
    field: str,
    values: list,
) -> dict:
    """
    Add a permanent, non-interactive data filter to one worksheet, restricting
    it to rows where `field` equals one of `values`. This is a baked-in
    filter on the worksheet's query (what Tableau calls a categorical/context
    filter) - NOT a dashboard quick-filter widget a viewer can change. For
    the interactive kind, use a {kind: "filter", ...} entry in
    instantiate_dashboard_layout's `controls` instead.

    This is the tool for the common "same chart template, N tiles, one
    category each" pattern - e.g. four tiles all built from the same
    Bar-Over-Time recipe with the same field_mapping, each restricted to a
    different status value. instantiate_chart_recipe has no filter concept
    of its own (deliberately - a recipe's field_mapping only ever substitutes
    fields into slots that already exist in the template); call this
    separately, once per worksheet, right after instantiating it, whenever
    the source spec calls for a tile-specific filter. Skipping this step for
    tiles that are supposed to differ only by filter value is exactly what
    produces multiple worksheets that look distinct (different names/titles)
    but return numerically identical results.

    `field` must be a nominal (string or boolean) dimension that already
    exists as a raw column in `datasource_name` - it does NOT need to already
    be used on the worksheet's shelves; this tool adds the column-instance
    for it if missing (using the plain-dimension naming convention verified
    against real reference workbooks: derivation "None" -> "[none:<field>:nk]").
    Other data types (dates, numbers) are not supported yet - only
    exact-match string/boolean filtering.

    `values`: list of one or more literal strings/booleans to match (as they
    appear in the data, e.g. ["PRESENT_IN_TRANSACTION_FACT"]). Multiple
    values are OR'd together (row matches if `field` equals any of them).
    Calling this again for the same worksheet+field replaces any previous
    filter on that exact field rather than stacking a second one.

    Backs up the workbook before writing. Run validate_workbook after (the
    calling app may do this automatically).
    """
    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    ds = _find_datasource(root, datasource_name)
    if ds is None:
        names = [d.get("name") for d in root.findall("./datasources/datasource")]
        return _err(f"Data source '{datasource_name}' not found in {workbook_path}. Available: {names}")

    ws_el = root.find(f"./worksheets/worksheet[@name='{worksheet_name}']")
    if ws_el is None:
        names = [w.get("name") for w in root.findall("./worksheets/worksheet")]
        return _err(f"Worksheet '{worksheet_name}' not found in {workbook_path}. Available: {names}")

    if not values or not isinstance(values, list):
        return _err("values must be a non-empty list of literal strings/booleans to match.")

    bare = (field or "").strip("[]")
    target_cols = _target_datasource_columns(ds)
    info = target_cols.get(bare)
    if info is None:
        return _err(f"Field '{bare}' not found in datasource '{datasource_name}'. Available: {sorted(target_cols)}")
    if info["role"] != "dimension":
        return _err(f"Field '{bare}' is a {info['role']}, not a dimension - only dimension exact-match filters are supported.")
    if info["datatype"] not in ("string", "boolean"):
        return _err(f"Field '{bare}' has datatype '{info['datatype']}' - only string/boolean fields are supported by this tool today.")

    view = ws_el.find("./table/view")
    if view is None:
        return _err(f"Worksheet '{worksheet_name}' has no <table><view> - not a normal chart worksheet.")

    qualified_bare = f"none:{bare}:nk"
    ci_name = f"[{qualified_bare}]"
    qualified_full = f"[{datasource_name}].{ci_name}"

    dep = None
    for d in view.findall("datasource-dependencies"):
        if d.get("datasource") == datasource_name:
            dep = d
            break
    if dep is None:
        dep = ET.Element("datasource-dependencies")
        dep.set("datasource", datasource_name)
        view.insert(0, dep)

    if dep.find(f"column-instance[@name='{ci_name}']") is None:
        ci = ET.SubElement(dep, "column-instance")
        ci.set("column", f"[{bare}]")
        ci.set("derivation", "None")
        ci.set("name", ci_name)
        ci.set("pivot", "key")
        ci.set("type", "nominal")

    for existing_filter in list(view.findall("filter")):
        if existing_filter.get("column") == qualified_full:
            view.remove(existing_filter)

    members_xml = "".join(
        f'<groupfilter function="member" level="{ci_name}" member="&quot;{str(v)}&quot;" '
        f'ns0:ui-domain="database" ns0:ui-enumeration="inclusive" ns0:ui-marker="enumerate" />'
        for v in values
    )
    if len(values) == 1:
        inner = members_xml
    else:
        inner = f'<groupfilter function="union" ns0:ui-domain="database" ns0:ui-enumeration="inclusive" ns0:ui-marker="enumerate">{members_xml}</groupfilter>'

    filter_xml = (
        f'<filter xmlns:ns0="http://www.tableausoftware.com/xml/user" class="categorical" column="{qualified_full}">'
        f'{inner}'
        f'</filter>'
    )
    try:
        filter_el = ET.fromstring(filter_xml)
    except ET.ParseError as e:
        return _err(f"Built filter XML is not well-formed: {e}. Nothing was written.")

    # insert after any datasource-dependencies / sort, before slices/panes,
    # matching real-reference worksheet ordering
    insert_idx = len(list(view))
    for i, child in enumerate(view):
        if child.tag in ("slices", "panes", "aggregation"):
            insert_idx = i
            break
    view.insert(insert_idx, filter_el)

    slices_el = view.find("slices")
    if slices_el is None:
        slices_el = ET.Element("slices")
        view.insert(insert_idx + 1, slices_el)
    if slices_el.find(f"column[.='{qualified_full}']") is None:
        col_el = ET.SubElement(slices_el, "column")
        col_el.text = qualified_full

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    return _ok(
        message=f"Filtered worksheet '{worksheet_name}' to {field} in {values!r} in {workbook_path}.",
        worksheet_name=worksheet_name,
        field=bare,
        values=values,
        backup_path=bkp["backup_path"],
        next_steps=[
            "Run validate_workbook to catch structural issues before opening Desktop.",
            "Reopen the workbook in Tableau Desktop to confirm the filter actually narrows the data as expected - XML validity alone doesn't prove the filter matches real row values.",
        ],
    )


_VIZ_TYPE_LETTER = {"nominal": "n", "ordinal": "o", "quantitative": "q"}


def _default_column_instance(bare: str, role: str, datatype: str):
    """(ci_name_bracketed, derivation, viz_type) for a field used on a shelf
    with no special derivation - 'None' for a dimension, 'Sum' for a measure
    - using the derivation+type-letter column-instance naming convention
    verified against real Desktop-saved reference workbooks elsewhere in
    this plugin (e.g. a plain string dimension -> '[none:Category:nk]', a
    summed real measure -> '[sum:Revenue:qk]'). Returns (None, None, None)
    if datatype isn't one _DATATYPE_TO_VIZ_TYPE recognizes."""
    viz_type = _DATATYPE_TO_VIZ_TYPE.get(datatype)
    if viz_type is None:
        return None, None, None
    letter = _VIZ_TYPE_LETTER[viz_type]
    derivation = "Sum" if role == "measure" else "None"
    token = derivation.lower() if derivation != "None" else "none"
    return f"[{token}:{bare}:{letter}k]", derivation, viz_type


@mcp.tool()
def build_crosstab_worksheet(
    workbook_path: str,
    datasource_name: str,
    new_worksheet_name: str,
    rows: list,
    cols: list,
    text_fields: list,
) -> dict:
    """
    Build a plain crosstab/table worksheet directly - rows and columns of
    dimension values with one or more measures shown as text in each cell
    (mark class 'Text') - no chart-recipe template involved. This is the
    tool for a Looker `looker_grid` (or any plain table) tile: those have no
    chart-template equivalent, because chart recipes are built from real
    charts, not tables - trying to force a table into a chart template, or
    silently substituting some chart type instead, produces the wrong thing.
    Use this instead whenever the source spec calls for a table.

    `rows`, `cols`: ordered lists of bare field names already in
    `datasource_name` (dimensions, typically - a measure works too, e.g. as
    a lone column header). Nested left-to-right / top-to-bottom the way
    Tableau does when more than one is given, e.g. rows=["client_name"],
    cols=["product_type"]. Either list can be empty, but not both.
    `text_fields`: ordered list of bare field names (usually measures) shown
    as text in each table cell - at least one required, or the table has
    nothing to display.

    Every field must already exist in `datasource_name` as a raw column or a
    calculated field (this tool never invents one - create it first with
    add_calculated_field if it's a Looker dynamic_field). If
    `new_worksheet_name` collides with an existing worksheet it's
    auto-renamed, matching instantiate_chart_recipe/instantiate_dashboard_layout
    - use the returned `worksheet_name`, not your requested one, afterward.

    Backs up the workbook before writing. After this: call add_worksheet_filter
    if the tile needs restricting to a specific value, run validate_workbook,
    and reopen in Tableau Desktop to confirm the table looks right - this
    tool builds a plain, unstyled table (no custom fonts/colors/tooltips);
    matching a source table's exact visual polish is still a manual Desktop
    step.
    """
    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    ds = _find_datasource(root, datasource_name)
    if ds is None:
        names = [d.get("name") for d in root.findall("./datasources/datasource")]
        return _err(f"Data source '{datasource_name}' not found in {workbook_path}. Available: {names}")

    rows = rows or []
    cols = cols or []
    text_fields = text_fields or []
    if not text_fields:
        return _err("text_fields must have at least one field - a table with nothing shown as text isn't useful.")
    if not rows and not cols:
        return _err("At least one of rows or cols must have a field - otherwise there's no table structure.")

    existing_ws_names = {w.get("name") for w in root.findall("./worksheets/worksheet")}
    requested_worksheet_name = new_worksheet_name
    new_worksheet_name = _dedupe_name(new_worksheet_name, existing_ws_names)
    ws_renamed = new_worksheet_name != requested_worksheet_name

    target_columns = _target_datasource_columns(ds)

    resolved = {}  # bare -> (ci_name, derivation, viz_type)
    errors = []
    for raw in [*rows, *cols, *text_fields]:
        bare = (raw or "").strip("[]")
        if not bare or bare in resolved:
            continue
        info = target_columns.get(bare)
        if info is None:
            errors.append(f"field '{bare}' not found in datasource '{datasource_name}' (add it first, or check spelling/caption vs internal name)")
            continue
        ci_name, derivation, viz_type = _default_column_instance(bare, info["role"], info["datatype"])
        if ci_name is None:
            errors.append(f"field '{bare}' has unsupported datatype '{info['datatype']}'")
            continue
        resolved[bare] = (ci_name, derivation, viz_type)
    if errors:
        return _err("Problems with rows/cols/text_fields: " + "; ".join(errors))

    ds_name_attr = ds.get("name")

    def qualified(raw):
        bare = (raw or "").strip("[]")
        ci_name, _derivation, _viz_type = resolved[bare]
        return f"[{ds_name_attr}].{ci_name}"

    ws_el = ET.Element("worksheet", {"name": new_worksheet_name})
    table_el = ET.SubElement(ws_el, "table")
    view_el = ET.SubElement(table_el, "view")
    dss_el = ET.SubElement(view_el, "datasources")
    ET.SubElement(dss_el, "datasource", {"caption": ds.get("caption") or ds_name_attr, "name": ds_name_attr})
    dep_el = ET.SubElement(view_el, "datasource-dependencies", {"datasource": ds_name_attr})
    for bare, (ci_name, derivation, viz_type) in resolved.items():
        ET.SubElement(dep_el, "column-instance", {
            "column": f"[{bare}]", "derivation": derivation, "name": ci_name, "pivot": "key", "type": viz_type,
        })
    ET.SubElement(view_el, "aggregation", {"value": "true"})
    ET.SubElement(table_el, "style")
    panes_el = ET.SubElement(table_el, "panes")
    pane_el = ET.SubElement(panes_el, "pane", {"selection-relaxation-option": "selection-relaxation-allow"})
    pane_view_el = ET.SubElement(pane_el, "view")
    ET.SubElement(pane_view_el, "breakdown", {"value": "auto"})
    ET.SubElement(pane_el, "mark", {"class": "Text"})
    enc_el = ET.SubElement(pane_el, "encodings")
    for raw in text_fields:
        ET.SubElement(enc_el, "text", {"column": qualified(raw)})

    rows_expr = " / ".join(qualified(r) for r in rows)
    if len(rows) > 1:
        rows_expr = f"({rows_expr})"
    cols_expr = " / ".join(qualified(c) for c in cols)
    if len(cols) > 1:
        cols_expr = f"({cols_expr})"
    rows_el = ET.SubElement(table_el, "rows")
    rows_el.text = rows_expr
    cols_el = ET.SubElement(table_el, "cols")
    cols_el.text = cols_expr

    ET.SubElement(ws_el, "simple-id", {"uuid": "{" + str(uuid.uuid4()).upper() + "}"})

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    worksheets_el = root.find("./worksheets")
    if worksheets_el is None:
        worksheets_el = ET.SubElement(root, "worksheets")
    worksheets_el.append(ws_el)

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    ws_message = f"Built crosstab worksheet '{new_worksheet_name}' in {workbook_path}."
    if ws_renamed:
        ws_message += (
            f" Note: a worksheet named '{requested_worksheet_name}' already existed in this "
            f"workbook, so this one was saved as '{new_worksheet_name}' instead - use that name "
            f"when placing it into a dashboard layout."
        )

    return _ok(
        message=ws_message,
        worksheet_name=new_worksheet_name,
        requested_worksheet_name=requested_worksheet_name,
        renamed=ws_renamed,
        backup_path=bkp["backup_path"],
        next_steps=[
            "Run validate_workbook to catch structural issues before opening Desktop.",
            "Call add_worksheet_filter if this tile needs restricting to a specific value.",
            "The new worksheet is not on any dashboard yet - add it via instantiate_dashboard_layout if needed.",
            "Reopen in Tableau Desktop to confirm it loads cleanly and the table looks right - this is the real test, not the XML validation.",
        ],
    )


def _next_zone_id(root: ET.Element) -> int:
    """Smallest safe integer to start allocating new dashboard zone ids from -
    scans every numeric `id` attribute in the whole document (zones, but also
    repository-location ids etc.) so a newly built dashboard's zones can never
    collide with anything already in the workbook."""
    max_id = 0
    for el in root.iter():
        v = el.get("id")
        if v and v.isdigit():
            max_id = max(max_id, int(v))
    return max_id + 1


def _worksheet_column_instances(ws_el: ET.Element, ds_name: str) -> list:
    """[{qualified_name, bare_column, derivation, pivot}] for a worksheet's
    column-instances against one datasource - i.e. the fields actually used
    on that worksheet's shelves/encodings, with the exact qualified names
    (e.g. '[sum:Sales:qk]') Tableau needs elsewhere (filter/action XML)."""
    out = []
    view = ws_el.find("./table/view")
    if view is None:
        return out
    for dep in view.findall("datasource-dependencies"):
        if dep.get("datasource") != ds_name:
            continue
        for ci in dep.findall("column-instance"):
            out.append({
                "qualified_name": ci.get("name"),
                "bare_column": (ci.get("column") or "").strip("[]"),
                "derivation": ci.get("derivation"),
                "pivot": ci.get("pivot"),
            })
    return out


def _resolve_qualified_field(ws_el: ET.Element, ds_name: str, bare_field: str, prefer_derivation: str = None):
    """Returns (qualified_ref, error) - qualified_ref like '[ds].[sum:Sales:qk]'
    for a field already used on this worksheet against this datasource, or an
    error string if it isn't there to find (this tool never fabricates a
    column-instance for a field that isn't already on the worksheet)."""
    instances = _worksheet_column_instances(ws_el, ds_name)
    matches = [i for i in instances if i["bare_column"] == bare_field]
    if not matches:
        return None, (
            f"field '{bare_field}' has no column-instance on this worksheet for datasource '{ds_name}' "
            f"- it must already be used on a shelf/encoding there (this tool won't fabricate one)"
        )
    if prefer_derivation:
        preferred = [i for i in matches if (i["derivation"] or "").lower() == prefer_derivation.lower()]
        if preferred:
            return f"[{ds_name}].{preferred[0]['qualified_name']}", None
    return f"[{ds_name}].{matches[0]['qualified_name']}", None


def _worksheet_color_field(ws_el: ET.Element):
    """The fully-qualified field reference (e.g. '[ds].[sum:Revenue:qk]')
    encoded as color on a worksheet, or None if it has no color encoding."""
    for enc in ws_el.iter("encodings"):
        color = enc.find("color")
        if color is not None and color.get("column"):
            return color.get("column")
    return None


@mcp.tool()
def instantiate_dashboard_layout(
    workbook_path: str,
    dashboard_name: str,
    layout: list,
    title: str = None,
    row_heights: list = None,
    controls: list = None,
) -> dict:
    """
    Build a real dashboard in `workbook_path`, placing existing worksheets
    into a grid layout. Reverse-engineered from real multi-worksheet Tableau
    dashboards (nested layout-basic/layout-flow zones with explicit
    percentage-space coordinates, 0-100000 per axis) - not guessed against an
    undocumented schema.

    `layout`: list of rows, each row a list of worksheet names already
    present in the workbook, e.g.
      [["Sales by Region", "Sales Trend"], ["Profit Summary"]]
    builds a 2-up top row and a full-width bottom row. Each cell may also be
    {"worksheet": "...", "weight": 2} to give it more width within its row
    than its row-mates (default weight 1 = even split). `row_heights` gives
    each row's weight top-to-bottom (default even split, same length as
    `layout`).

    Every worksheet named must already exist in the workbook (build it first,
    e.g. with instantiate_chart_recipe) and each worksheet may only appear
    once on this dashboard. Backs up the workbook before writing.

    `controls`: optional list of quick filters / legends / parameter controls
    to place in a strip below the title, each dict shaped as one of:
      {"kind": "legend", "worksheet": "..."}
        - the named worksheet must already have a color encoding; the legend
          shows whatever field is encoded there.
      {"kind": "filter", "worksheet": "...", "datasource_name": "...", "field": "...", "mode": "dropdown"}
        - `field` must already be used on that worksheet's shelf/encodings
          (this tool won't fabricate a new column-instance for an unused
          field). Adds a categorical, all-values quick filter if the
          worksheet doesn't already filter on that field.
      {"kind": "parameter", "parameter_name": "...", "mode": "compact"}
        - `parameter_name` must already exist (see add_parameter).
    Each zone type here was extracted from a real Tableau dashboard that used
    it, the same way the grid layout itself was - not guessed.

    Known gap: does NOT wire up cross-sheet actions (highlight/URL/nav/filter/
    parameter actions) - use add_dashboard_action for those, separately,
    after the dashboard exists. Also does not run validate_workbook or the
    render loop for you - always run those after.

    If `dashboard_name` collides with a dashboard already in the workbook,
    it is NOT rejected - it's auto-suffixed (" 2", " 3", ...) to a free
    name instead, so you can safely pass the dashboard's natural name
    (e.g. the source Looker dashboard's own title) without first checking
    for collisions - no need to invent a different name or ask the user
    for one just to dodge a clash. `title` (shown on the dashboard, if you
    set one) is left as what you asked for even when the internal name
    was renamed. The response's `dashboard_name` field is the name
    actually used (`renamed: true` when it differs from what you asked
    for) - use that value, not your original request, in any
    add_dashboard_action calls that reference this dashboard.
    """
    if not layout or not all(layout):
        return _err("`layout` must be a non-empty list of non-empty rows (each row a non-empty list of worksheet names).")

    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    existing_dash_names = {d.get("name") for d in root.findall("./dashboards/dashboard")}
    requested_dashboard_name = dashboard_name
    dashboard_name = _dedupe_name(dashboard_name, existing_dash_names)
    renamed = dashboard_name != requested_dashboard_name

    existing_ws_names = {w.get("name") for w in root.findall("./worksheets/worksheet")}

    norm_rows = []
    seen_ws = set()
    errors = []
    for ri, row in enumerate(layout):
        norm_cells = []
        for cell in row:
            if isinstance(cell, dict):
                name, weight = cell.get("worksheet"), cell.get("weight", 1)
            else:
                name, weight = cell, 1
            if not name or name not in existing_ws_names:
                errors.append(f"row {ri}: worksheet '{name}' not found in this workbook. Available: {sorted(existing_ws_names)}")
                continue
            if name in seen_ws:
                errors.append(f"row {ri}: worksheet '{name}' placed more than once - a Tableau dashboard can't repeat the same worksheet.")
                continue
            try:
                weight = float(weight)
                if weight <= 0:
                    raise ValueError
            except (TypeError, ValueError):
                errors.append(f"row {ri}: weight for '{name}' must be a positive number, got {weight!r}")
                continue
            seen_ws.add(name)
            norm_cells.append((name, weight))
        norm_rows.append(norm_cells)
    if errors:
        return _err("layout has problems: " + "; ".join(errors))

    if row_heights is not None:
        if len(row_heights) != len(layout):
            return _err(f"row_heights has {len(row_heights)} entries but layout has {len(layout)} rows.")
        try:
            row_heights = [float(x) for x in row_heights]
            if any(x <= 0 for x in row_heights):
                raise ValueError
        except (TypeError, ValueError):
            return _err("row_heights must all be positive numbers.")
    else:
        row_heights = [1.0] * len(layout)

    norm_controls = []
    if controls:
        control_errors = []
        params_ds = _find_datasource(root, "Parameters")
        param_names = {c.get("name", "").strip("[]") for c in params_ds.findall("column")} if params_ds is not None else set()
        for ci, control in enumerate(controls):
            ctrl_kind = (control or {}).get("kind")
            if ctrl_kind == "legend":
                ws_name = control.get("worksheet")
                if ws_name not in existing_ws_names:
                    control_errors.append(f"control {ci} (legend): worksheet '{ws_name}' not found. Available: {sorted(existing_ws_names)}")
                    continue
                ws_el = root.find(f"./worksheets/worksheet[@name='{ws_name}']")
                color_field = _worksheet_color_field(ws_el) if ws_el is not None else None
                if not color_field:
                    control_errors.append(f"control {ci} (legend): worksheet '{ws_name}' has no color encoding to build a legend from")
                    continue
                norm_controls.append({"kind": "legend", "worksheet": ws_name, "field": color_field})
            elif ctrl_kind == "filter":
                ws_name, ds_name, field, mode = control.get("worksheet"), control.get("datasource_name"), control.get("field"), control.get("mode", "dropdown")
                if ws_name not in existing_ws_names:
                    control_errors.append(f"control {ci} (filter): worksheet '{ws_name}' not found. Available: {sorted(existing_ws_names)}")
                    continue
                ds = _find_datasource(root, ds_name)
                if ds is None:
                    control_errors.append(f"control {ci} (filter): datasource '{ds_name}' not found")
                    continue
                bare = (field or "").strip("[]")
                target_cols = _target_datasource_columns(ds)
                if bare not in target_cols:
                    control_errors.append(f"control {ci} (filter): field '{bare}' not found in datasource '{ds_name}'")
                    continue
                if target_cols[bare]["role"] != "dimension":
                    control_errors.append(f"control {ci} (filter): field '{bare}' is a measure - only dimension (categorical) quick filters are supported today")
                    continue
                ws_el = root.find(f"./worksheets/worksheet[@name='{ws_name}']")
                qualified, err = _resolve_qualified_field(ws_el, ds.get("name"), bare, prefer_derivation="None")
                if err:
                    control_errors.append(f"control {ci} (filter): {err}")
                    continue
                norm_controls.append({"kind": "filter", "worksheet": ws_name, "field": qualified, "mode": mode, "ws_el": ws_el})
            elif ctrl_kind == "parameter":
                pname = (control.get("parameter_name") or "").strip("[]")
                mode = control.get("mode", "compact")
                if pname not in param_names:
                    control_errors.append(f"control {ci} (parameter): parameter '{pname}' not found - create it first with add_parameter. Available: {sorted(param_names)}")
                    continue
                norm_controls.append({"kind": "parameter", "parameter_name": pname, "mode": mode})
            else:
                control_errors.append(f"control {ci}: unknown kind {ctrl_kind!r} - must be 'legend', 'filter', or 'parameter'")
        if control_errors:
            return _err("controls has problems: " + "; ".join(control_errors))

    SPACE = 100000
    TITLE_H = 5000
    CONTROLS_H = 8000 if norm_controls else 0
    next_id = [_next_zone_id(root)]

    def alloc_id():
        i = next_id[0]
        next_id[0] += 1
        return i

    def make_zone(x, y, w, h, **attrs):
        el = ET.Element("zone")
        el.set("h", str(round(h)))
        el.set("id", str(alloc_id()))
        el.set("w", str(round(w)))
        el.set("x", str(round(x)))
        el.set("y", str(round(y)))
        for k, v in attrs.items():
            el.set(k, v)
        return el

    def build_row(cells, x, y, w, h):
        if len(cells) == 1:
            name, _wt = cells[0]
            return make_zone(x, y, w, h, name=name)
        total_wt = sum(wt for _n, wt in cells)
        row_zone = make_zone(x, y, w, h, param="horz", **{"type-v2": "layout-flow", "layout-strategy-id": "distribute-evenly"})
        cx = x
        for name, wt in cells:
            cw = w * (wt / total_wt)
            row_zone.append(make_zone(cx, y, cw, h, name=name))
            cx += cw
        return row_zone

    content_x, content_y, content_w, content_h = 0, TITLE_H + CONTROLS_H, SPACE, SPACE - TITLE_H - CONTROLS_H

    if len(norm_rows) == 1:
        content_zone = build_row(norm_rows[0], content_x, content_y, content_w, content_h)
    else:
        total_ht = sum(row_heights)
        content_zone = make_zone(content_x, content_y, content_w, content_h, param="vert", **{"type-v2": "layout-flow"})
        cy = content_y
        for cells, ht in zip(norm_rows, row_heights):
            rh = content_h * (ht / total_ht)
            content_zone.append(build_row(cells, content_x, cy, content_w, rh))
            cy += rh

    title_zone = make_zone(0, 0, SPACE, TITLE_H, **{"type-v2": "title"})

    root_zone = make_zone(0, 0, SPACE, SPACE, **{"type-v2": "layout-basic"})
    root_zone.append(content_zone)
    root_zone.append(title_zone)

    if norm_controls:
        cw_each = SPACE / len(norm_controls)
        cx = 0
        for control in norm_controls:
            if control["kind"] == "legend":
                zone = make_zone(cx, TITLE_H, cw_each, CONTROLS_H, name=control["worksheet"], param=control["field"], **{"type-v2": "color", "leg-item-layout": "horz"})
            elif control["kind"] == "filter":
                zone = make_zone(cx, TITLE_H, cw_each, CONTROLS_H, name=control["worksheet"], param=control["field"], mode=control["mode"], **{"type-v2": "filter"})
                ws_el = control["ws_el"]
                view = ws_el.find("./table/view")
                qualified = control["field"]
                already_filtered = any(f.get("column") == qualified for f in view.findall("filter"))
                if not already_filtered:
                    level = qualified.split("].", 1)[1] if "]." in qualified else qualified
                    filter_xml = (
                        '<filter xmlns:ns0="http://www.tableausoftware.com/xml/user" class="categorical" column="' + qualified + '">'
                        '<groupfilter function="level-members" level="' + level + '" ns0:ui-enumeration="all" ns0:ui-marker="enumerate" />'
                        '</filter>'
                    )
                    view.append(ET.fromstring(filter_xml))
            else:  # parameter
                zone = make_zone(cx, TITLE_H, cw_each, CONTROLS_H, param=f"[Parameters].[{control['parameter_name']}]", mode=control["mode"], **{"type-v2": "paramctrl"})
            root_zone.append(zone)
            cx += cw_each

    zones_el = ET.Element("zones")
    zones_el.append(root_zone)

    dash_title = title or requested_dashboard_name
    layout_options = ET.Element("layout-options")
    title_container = ET.SubElement(layout_options, "title")
    formatted_text = ET.SubElement(title_container, "formatted-text")
    run_el = ET.SubElement(formatted_text, "run", {
        "bold": "true", "fontalignment": "1", "fontcolor": "#49729d", "fontsize": "20",
    })
    run_el.text = dash_title

    fresh_uuid = "{" + str(uuid.uuid4()).upper() + "}"
    dashboard_el = ET.Element("dashboard", {"name": dashboard_name})
    dashboard_el.append(layout_options)
    ET.SubElement(dashboard_el, "style")
    ET.SubElement(dashboard_el, "size", {"sizing-mode": "automatic"})
    dashboard_el.append(zones_el)
    ET.SubElement(dashboard_el, "simple-id", {"uuid": fresh_uuid})

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    dashboards_el = root.find("./dashboards")
    if dashboards_el is None:
        dashboards_el = ET.Element("dashboards")
        worksheets_el = root.find("./worksheets")
        if worksheets_el is not None:
            idx = list(root).index(worksheets_el) + 1
            root.insert(idx, dashboards_el)
        else:
            root.append(dashboards_el)
    dashboards_el.append(dashboard_el)

    windows_el = root.find("./windows")
    if windows_el is None:
        windows_el = ET.SubElement(root, "windows")
    window_el = ET.SubElement(windows_el, "window", {"class": "dashboard", "name": dashboard_name})
    viewpoints_el = ET.SubElement(window_el, "viewpoints")
    for row in norm_rows:
        for name, _wt in row:
            vp = ET.SubElement(viewpoints_el, "viewpoint", {"name": name})
            ET.SubElement(vp, "zoom", {"type": "entire-view"})

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    message = f"Built dashboard '{dashboard_name}' in {workbook_path} with {sum(len(r) for r in norm_rows)} worksheet(s) across {len(norm_rows)} row(s)."
    if renamed:
        message += (
            f" Note: a dashboard named '{requested_dashboard_name}' already existed in this "
            f"workbook, so this one was saved as '{dashboard_name}' instead - use that name "
            f"for any add_dashboard_action calls or further references to this dashboard."
        )
    return _ok(
        message=message,
        dashboard_name=dashboard_name,
        requested_dashboard_name=requested_dashboard_name,
        renamed=renamed,
        backup_path=bkp["backup_path"],
        next_steps=[
            "Run validate_workbook to catch structural issues before opening Desktop.",
            "Reopen the workbook in Tableau Desktop to confirm it loads and the layout looks right - this is the real test, not the XML validation.",
            "Cross-sheet actions (highlight/URL/nav/filter/parameter) aren't wired up here - use add_dashboard_action for those.",
            "Run the request_render / check_render / pixel_diff loop before treating this dashboard as done.",
        ],
    )


# --------------------------------------------------------------------------
# Parameters
# --------------------------------------------------------------------------

_TABLEAU_PARAM_COMBOS = {
    ("list", "string"),
    ("range", "integer"),
    ("range", "real"),
    ("any", "date"),
}


def _tableau_literal(value, datatype: str) -> str:
    if datatype == "string":
        return '"' + str(value).replace('"', '\\"') + '"'
    if datatype == "integer":
        return str(int(value))
    if datatype == "real":
        return str(float(value))
    if datatype == "date":
        return f"#{value}#"
    raise ValueError(f"Unsupported datatype for a Tableau parameter literal: {datatype}")


@mcp.tool()
def add_parameter(
    workbook_path: str,
    name: str,
    domain_type: str,
    datatype: str,
    current_value,
    caption: str = None,
    list_values: list = None,
    range_min=None,
    range_max=None,
    range_granularity=None,
    default_format: str = None,
) -> dict:
    """
    Add a real Tableau parameter to `workbook_path` (a column in the special
    'Parameters' pseudo-datasource, created if it doesn't exist yet).

    Verified combinations of `domain_type` + `datatype` (each extracted from a
    real Tableau parameter, not written from general syntax knowledge):
      - domain_type="list", datatype="string": needs `list_values` (a list of
        strings) - a dropdown of fixed choices.
      - domain_type="range", datatype="integer" or "real": needs `range_min`,
        `range_max`, and optionally `range_granularity` (the slider step).
      - domain_type="any", datatype="date": a free date value, e.g.
        current_value="2017-02-16" (ISO format, no '#'). `default_format`
        (e.g. "*dd mmmm yyyy") is optional display formatting.
    Other combinations are very likely valid in Tableau too, but haven't been
    verified against a real file, so this tool refuses rather than guess at
    the XML.

    Does not itself place a control for this parameter on any dashboard -
    use instantiate_dashboard_layout's `controls` (kind="parameter") or
    add_dashboard_action (action_type="parameter") for that.
    """
    combo = (domain_type, datatype)
    if combo not in _TABLEAU_PARAM_COMBOS:
        return _err(
            f"Unsupported combination domain_type='{domain_type}' + datatype='{datatype}'. "
            f"Verified combinations: list+string, range+integer, range+real, any+date."
        )
    if domain_type == "list" and not list_values:
        return _err("domain_type='list' requires a non-empty list_values.")
    if domain_type == "range" and (range_min is None or range_max is None):
        return _err("domain_type='range' requires range_min and range_max (range_granularity optional).")

    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    datasources_el = root.find("./datasources")
    if datasources_el is None:
        datasources_el = ET.SubElement(root, "datasources")
    params_ds = None
    for ds in datasources_el.findall("datasource"):
        if ds.get("name") == "Parameters":
            params_ds = ds
            break
    if params_ds is None:
        params_ds = ET.SubElement(datasources_el, "datasource", {"name": "Parameters"})

    internal_name = name if name.startswith("[") else f"[{name}]"
    for col in params_ds.findall("column"):
        if col.get("name") == internal_name:
            return _err(f"A parameter named {internal_name} already exists.")

    try:
        literal = _tableau_literal(current_value, datatype)
    except ValueError as e:
        return _err(str(e))

    col = ET.SubElement(params_ds, "column")
    col.set("caption", caption or name)
    col.set("datatype", datatype)
    if default_format:
        col.set("datatype-customized", "true")
        col.set("default-format", default_format)
    col.set("name", internal_name)
    col.set("param-domain-type", domain_type)
    col.set("role", "measure")
    col.set("type", "nominal" if datatype == "string" else "quantitative")
    col.set("value", literal)
    ET.SubElement(col, "calculation", {"class": "tableau", "formula": literal})

    if domain_type == "list":
        members_el = ET.SubElement(col, "members")
        for v in list_values:
            ET.SubElement(members_el, "member", {"value": _tableau_literal(v, datatype)})
    elif domain_type == "range":
        ET.SubElement(col, "range", {
            "granularity": str(range_granularity if range_granularity is not None else (1 if datatype == "integer" else 1.0)),
            "max": str(range_max),
            "min": str(range_min),
        })

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    return _ok(
        message=f"Added parameter {internal_name} (domain_type={domain_type}, datatype={datatype}) to {workbook_path}.",
        backup_path=bkp["backup_path"],
        next_step="Reopen in Tableau Desktop to confirm it loads. Reference it in a calc as [Parameters]." + internal_name + ", or place a control for it with instantiate_dashboard_layout/add_dashboard_action.",
    )


# --------------------------------------------------------------------------
# Level-of-detail (LOD) calculation recipes
# --------------------------------------------------------------------------

LOD_PATTERNS = {
    "fixed_aggregate": {
        "description": "Aggregate a measure at a fixed level of detail, ignoring whatever dimensions are on the current view - e.g. total sales per region no matter how the viz is sliced.",
        "formula": "{FIXED [{{DIM}}] : {{AGG}}([{{MEASURE}}])}",
        "slots": {"DIM": "field", "AGG": "agg", "MEASURE": "field"},
        "output_role": "measure",
        "output_datatype": "real",
        "source_example": "{FIXED [Region] : SUM([Sales])} - from a real workbook (Tableau LOD and Actions.twbx)",
    },
    "include_aggregate": {
        "description": "Aggregate at a MORE detailed level than the view by including a dimension not otherwise on it - e.g. average per-order sales even when the view is aggregated to region.",
        "formula": "{INCLUDE [{{DIM}}] : {{AGG}}([{{MEASURE}}])}",
        "slots": {"DIM": "field", "AGG": "agg", "MEASURE": "field"},
        "output_role": "measure",
        "output_datatype": "real",
        "source_example": "{INCLUDE [Region] : SUM([Sales])} - from a real workbook (Tableau LOD and Actions.twbx)",
    },
    "exclude_aggregate": {
        "description": "Aggregate at a LESS detailed level than the view by excluding a dimension that's on it - e.g. total company sales shown alongside a per-region breakdown.",
        "formula": "{EXCLUDE [{{DIM}}] : {{AGG}}([{{MEASURE}}])}",
        "slots": {"DIM": "field", "AGG": "agg", "MEASURE": "field"},
        "output_role": "measure",
        "output_datatype": "real",
        "source_example": "{EXCLUDE [Region]: SUM([Sales])} - from a real workbook (Tableau LOD and Actions.twbx)",
    },
    "average_of_group_totals": {
        "description": "Average of a per-group fixed total, at a level excluding one dimension from the view - e.g. the average of each region's total sales, shown at the order level (an 'average of the aggregate' pattern a plain table calc can't do).",
        "formula": "{EXCLUDE [{{DIM}}]:{{AGG}}({FIXED [{{DIM2}}] : SUM([{{MEASURE}}])})}",
        "slots": {"DIM": "field", "AGG": "agg", "DIM2": "field", "MEASURE": "field"},
        "output_role": "measure",
        "output_datatype": "real",
        "source_example": "{EXCLUDE [Order Date]:AVG({FIXED [Order Date] : SUM([Sales])})} - from a real workbook (Tableau LOD and Actions.twbx)",
    },
    "cohort_first_date": {
        "description": "First date an entity appears - the standard building block of cohort analysis (e.g. each customer's first order date, to later bucket customers by acquisition month).",
        "formula": "{FIXED [{{DIM}}] : MIN([{{DATE_FIELD}}])}",
        "slots": {"DIM": "field", "DATE_FIELD": "field"},
        "output_role": "dimension",
        "output_datatype": "date",
        "source_example": "{ FIXED [Customer Name]:MIN([Order Date])} - from a real workbook (15 Examples of Tableau LOD - Cohort Analysis.twbx)",
    },
}

ALLOWED_LOD_AGG_FUNCTIONS = {"SUM", "AVG", "MIN", "MAX", "COUNT", "COUNTD", "MEDIAN"}


@mcp.tool()
def list_lod_patterns() -> dict:
    """
    List available Level-of-Detail (FIXED/INCLUDE/EXCLUDE) calculation
    patterns - each extracted from a real Tableau workbook that used it, not
    a generic LOD syntax reference. Use instantiate_lod_calculation to build
    one against your own fields.
    """
    return _ok(patterns={
        k: {"description": v["description"], "formula_template": v["formula"], "slots": v["slots"], "source_example": v["source_example"]}
        for k, v in LOD_PATTERNS.items()
    })


@mcp.tool()
def instantiate_lod_calculation(
    workbook_path: str,
    datasource_name: str,
    pattern_name: str,
    field_mapping: dict,
    new_field_name: str,
    caption: str = None,
) -> dict:
    """
    Build a real LOD calculated field in `datasource_name` from a verified
    pattern (call list_lod_patterns to see them and their required slots),
    substituting your own fields in place of the pattern's placeholders.
    Backs up the workbook (via add_calculated_field, which this wraps).

    `field_mapping` keys are the pattern's slot names. A "field"-kind slot
    must be an existing field's bare internal name (e.g. "Region") in
    `datasource_name`. An "agg"-kind slot must be one of: SUM, AVG, MIN, MAX,
    COUNT, COUNTD, MEDIAN.
    """
    pattern = LOD_PATTERNS.get(pattern_name)
    if pattern is None:
        return _err(f"No LOD pattern named '{pattern_name}'. Available: {list(LOD_PATTERNS)}")

    try:
        tree, _kind, _member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()
    ds = _find_datasource(root, datasource_name)
    if ds is None:
        names = [d.get("name") for d in root.findall("./datasources/datasource")]
        return _err(f"Data source '{datasource_name}' not found. Available: {names}")
    target_columns = _target_datasource_columns(ds)

    missing = [s for s in pattern["slots"] if s not in field_mapping]
    if missing:
        return _err(f"field_mapping is missing entries for: {missing}. Slots: {pattern['slots']}")

    errors = []
    resolved = {}
    for slot, slot_kind in pattern["slots"].items():
        value = field_mapping[slot]
        if slot_kind == "agg":
            agg = str(value).upper()
            if agg not in ALLOWED_LOD_AGG_FUNCTIONS:
                errors.append(f"{slot}: '{value}' is not a supported aggregation - use one of {sorted(ALLOWED_LOD_AGG_FUNCTIONS)}")
                continue
            resolved[slot] = agg
        else:
            bare = str(value).strip("[]")
            if bare not in target_columns:
                errors.append(f"{slot}: field '{bare}' not found in datasource '{datasource_name}'")
                continue
            resolved[slot] = bare
    if errors:
        return _err("field_mapping has problems: " + "; ".join(errors))

    formula = pattern["formula"]
    for slot, val in resolved.items():
        formula = formula.replace("{{" + slot + "}}", val)

    return add_calculated_field(
        workbook_path, datasource_name, new_field_name, formula,
        caption=caption, datatype=pattern["output_datatype"], role=pattern["output_role"],
    )


# --------------------------------------------------------------------------
# Dashboard actions
# --------------------------------------------------------------------------

AGG_TYPE_TO_DERIVATION = {
    "sum": "Sum", "avg": "Avg", "min": "Min", "max": "Max",
    "attr": "None", "count": "Count", "countd": "CountD",
}


def _ensure_actions_element(root: ET.Element) -> ET.Element:
    actions_el = root.find("./actions")
    if actions_el is not None:
        return actions_el
    actions_el = ET.Element("actions")
    worksheets_el = root.find("./worksheets")
    if worksheets_el is not None:
        idx = list(root).index(worksheets_el)
        root.insert(idx, actions_el)
    else:
        root.append(actions_el)
    return actions_el


def _next_action_name(root: ET.Element) -> str:
    max_n = 0
    for el in root.iter():
        if el.tag in ("action", "nav-action", "edit-parameter-action"):
            m = re.match(r"\[Action(\d+)\]", el.get("name") or "")
            if m:
                max_n = max(max_n, int(m.group(1)))
    return f"[Action{max_n + 1}]"


@mcp.tool()
def add_dashboard_action(
    workbook_path: str,
    dashboard_name: str,
    action_type: str,
    caption: str,
    source_worksheet: str = None,
    target_worksheet: str = None,
    target_sheet: str = None,
    url: str = None,
    field_captions: str = None,
    datasource_name: str = None,
    field_pairs: list = None,
    parameter_name: str = None,
    source_field: str = None,
    agg_type: str = None,
    auto_clear: bool = True,
) -> dict:
    """
    Add a real dashboard action to an existing dashboard. Each action_type's
    XML shape was extracted from a real Tableau workbook that used it - not
    written from general Tableau knowledge.

    action_type="highlight": highlights matching marks across the dashboard
      on selection. Needs `field_captions` (exactly as Tableau's action
      dialog shows it, e.g. "Category" or "MONTH(Order Date)").
      `source_worksheet`/`target_worksheet` optional (omit = whole dashboard).

    action_type="url": opens a link. Needs `url`. `source_worksheet` optional
      (omit = whole dashboard triggers it).

    action_type="nav": jumps to another sheet/dashboard. Needs `target_sheet`
      (a dashboard/worksheet name, or "None"). `source_worksheet` optional.

    action_type="parameter": sets a parameter from a selection. Needs
      `parameter_name` (must already exist - see add_parameter),
      `source_worksheet`, `datasource_name`, `source_field` (must already be
      used on that worksheet's shelf/encodings - this tool won't fabricate a
      column-instance for an unused field), and `agg_type`
      (sum|avg|min|max|attr|count|countd - "attr" for a dimension).

    action_type="filter": filters `target_worksheet` from a selection on this
      dashboard. Needs `datasource_name` and `field_pairs` - a list of
      {"source_field": "...", "target_field": "..."} (target_field defaults
      to source_field), both must exist in `datasource_name`. Known caveat:
      the companion `<actions><datasource-dependencies>` cache block real
      Tableau files carry alongside this wasn't reproduced (no confirmed
      requirement it's needed for correctness) - reopening in Desktop is the
      real test, per the validate/render loop.

    Backs up the workbook before writing. Does not run validate_workbook or
    the render loop for you.
    """
    valid_types = {"highlight", "url", "nav", "parameter", "filter"}
    if action_type not in valid_types:
        return _err(f"action_type must be one of {sorted(valid_types)}, got '{action_type}'.")

    try:
        tree, kind, member = load_workbook_xml(workbook_path)
    except Exception as e:
        return _err(str(e))
    root = tree.getroot()

    dash_names = {d.get("name") for d in root.findall("./dashboards/dashboard")}
    if dashboard_name not in dash_names:
        return _err(f"Dashboard '{dashboard_name}' not found. Available: {sorted(dash_names)}")

    ws_by_name = {w.get("name"): w for w in root.findall("./worksheets/worksheet")}

    def _check_ws(n, label):
        if n is not None and n not in ws_by_name:
            return f"{label} '{n}' is not a worksheet in this workbook. Available: {sorted(ws_by_name)}"
        return None

    el = None

    if action_type == "highlight":
        if not field_captions:
            return _err("action_type='highlight' requires field_captions (e.g. 'Category' or 'MONTH(Order Date)').")
        err = _check_ws(source_worksheet, "source_worksheet")
        if err:
            return _err(err)
        el = ET.Element("action", {"caption": caption, "name": _next_action_name(root)})
        activation = ET.SubElement(el, "activation", {"type": "on-select"})
        if auto_clear:
            activation.set("auto-clear", "true")
        ET.SubElement(el, "source", {"dashboard": dashboard_name, "type": "sheet"})
        cmd = ET.SubElement(el, "command", {"command": "tsc:brush"})
        ET.SubElement(cmd, "param", {"name": "field-captions", "value": field_captions})
        ET.SubElement(cmd, "param", {"name": "target", "value": target_worksheet or dashboard_name})

    elif action_type == "url":
        if not url:
            return _err("action_type='url' requires `url`.")
        err = _check_ws(source_worksheet, "source_worksheet")
        if err:
            return _err(err)
        el = ET.Element("action", {"caption": caption, "name": _next_action_name(root)})
        ET.SubElement(el, "activation", {"type": "on-select"})
        src_attrs = {"dashboard": dashboard_name, "type": "sheet"}
        if source_worksheet:
            src_attrs["worksheet"] = source_worksheet
        ET.SubElement(el, "source", src_attrs)
        ET.SubElement(el, "link", {"caption": caption, "expression": url})

    elif action_type == "nav":
        if not target_sheet:
            return _err("action_type='nav' requires target_sheet (a dashboard/worksheet name, or 'None').")
        if target_sheet != "None" and target_sheet not in dash_names and target_sheet not in ws_by_name:
            return _err(f"target_sheet '{target_sheet}' is not a known dashboard or worksheet. Dashboards: {sorted(dash_names)}, worksheets: {sorted(ws_by_name)}")
        err = _check_ws(source_worksheet, "source_worksheet")
        if err:
            return _err(err)
        el = ET.Element("nav-action", {"caption": caption, "name": _next_action_name(root)})
        ET.SubElement(el, "activation", {"type": "on-select"})
        src_attrs = {"dashboard": dashboard_name, "type": "sheet"}
        if source_worksheet:
            src_attrs["worksheet"] = source_worksheet
        ET.SubElement(el, "source", src_attrs)
        params_el = ET.SubElement(el, "params")
        ET.SubElement(params_el, "param", {"name": "sheet", "value": target_sheet})

    elif action_type == "parameter":
        if not (parameter_name and source_worksheet and source_field and agg_type and datasource_name):
            return _err("action_type='parameter' requires parameter_name, source_worksheet, source_field, agg_type, and datasource_name.")
        err = _check_ws(source_worksheet, "source_worksheet")
        if err:
            return _err(err)
        agg_type_l = agg_type.lower()
        if agg_type_l not in AGG_TYPE_TO_DERIVATION:
            return _err(f"agg_type must be one of {sorted(AGG_TYPE_TO_DERIVATION)}, got '{agg_type}'.")
        params_ds = _find_datasource(root, "Parameters")
        pname_bare = parameter_name.strip("[]")
        param_exists = params_ds is not None and any(c.get("name", "").strip("[]") == pname_bare for c in params_ds.findall("column"))
        if not param_exists:
            return _err(f"Parameter '{parameter_name}' not found - create it first with add_parameter.")
        src_ds = _find_datasource(root, datasource_name)
        if src_ds is None:
            names = [d.get("name") for d in root.findall("./datasources/datasource")]
            return _err(f"Data source '{datasource_name}' not found. Available: {names}")
        ws_el = ws_by_name[source_worksheet]
        bare = source_field.strip("[]")
        qualified, err = _resolve_qualified_field(ws_el, src_ds.get("name"), bare, prefer_derivation=AGG_TYPE_TO_DERIVATION[agg_type_l])
        if err:
            return _err(f"source_field: {err}")
        el = ET.Element("edit-parameter-action", {"caption": caption, "name": _next_action_name(root)})
        ET.SubElement(el, "activation", {"type": "on-select"})
        ET.SubElement(el, "source", {"type": "sheet", "worksheet": source_worksheet})
        ET.SubElement(el, "agg-type", {"type": agg_type_l})
        params_el = ET.SubElement(el, "params")
        ET.SubElement(params_el, "param", {"name": "source-field", "value": qualified})
        ET.SubElement(params_el, "param", {"name": "target-parameter", "value": f"[Parameters].[{pname_bare}]"})

    elif action_type == "filter":
        if not (target_worksheet and datasource_name and field_pairs):
            return _err("action_type='filter' requires target_worksheet, datasource_name, and field_pairs.")
        err = _check_ws(target_worksheet, "target_worksheet")
        if err:
            return _err(err)
        ds = _find_datasource(root, datasource_name)
        if ds is None:
            names = [d.get("name") for d in root.findall("./datasources/datasource")]
            return _err(f"Data source '{datasource_name}' not found. Available: {names}")
        target_columns = _target_datasource_columns(ds)
        norm_pairs = []
        field_errors = []
        for pair in field_pairs:
            src = pair.get("source_field") if isinstance(pair, dict) else pair
            tgt = (pair.get("target_field") if isinstance(pair, dict) else None) or src
            src_bare, tgt_bare = (src or "").strip("[]"), (tgt or "").strip("[]")
            if src_bare not in target_columns:
                field_errors.append(f"source_field '{src_bare}' not found in '{datasource_name}'")
            if tgt_bare not in target_columns:
                field_errors.append(f"target_field '{tgt_bare}' not found in '{datasource_name}'")
            norm_pairs.append((src_bare, tgt_bare))
        if field_errors:
            return _err("field_pairs has problems: " + "; ".join(field_errors))
        ds_internal_name = ds.get("name")
        expr_parts = []
        for src_bare, tgt_bare in norm_pairs:
            key = f"[{ds_internal_name}].[{src_bare}]"
            key_enc = urllib.parse.quote(key, safe="")
            val_ref = f"[{ds_internal_name}].[{tgt_bare}]"
            expr_parts.append(f"{key_enc}~s0=<{val_ref}~na>")
        expression = f"tsl:{target_worksheet}?" + "&".join(expr_parts)
        el = ET.Element("action", {"caption": caption, "name": _next_action_name(root)})
        ET.SubElement(el, "activation", {"type": "on-select"})
        ET.SubElement(el, "source", {"dashboard": dashboard_name, "type": "sheet"})
        ET.SubElement(el, "link", {
            "caption": caption, "delimiter": ",", "escape": "\\", "expression": expression,
            "include-null": "true", "multi-select": "true", "url-escape": "true",
        })
        cmd = ET.SubElement(el, "command", {"command": "tsc:tsl-filter"})
        ET.SubElement(cmd, "param", {"name": "target", "value": target_worksheet})

    bkp = backup_file(workbook_path)
    if not bkp["ok"]:
        return bkp

    actions_el = _ensure_actions_element(root)
    actions_el.append(el)

    try:
        save_workbook_xml(workbook_path, tree, kind, member)
    except Exception as e:
        return _err(f"Failed to save workbook (backup preserved at {bkp['backup_path']}): {e}")

    return _ok(
        message=f"Added {action_type} action '{caption}' to dashboard '{dashboard_name}'.",
        backup_path=bkp["backup_path"],
        next_steps=[
            "Run validate_workbook to catch structural issues before opening Desktop.",
            "Reopen in Tableau Desktop and test the action live - this is the real test for action wiring.",
        ],
    )


# --------------------------------------------------------------------------
# Self-test (no MCP transport - exercises the XML/validation logic directly)
# --------------------------------------------------------------------------


def _selftest():
    import tempfile
    _TMP = Path(tempfile.mkdtemp(prefix="tableau_selftest_"))
    print("Running offline self-test (no Tableau files touched)...")
    sample_twb = """<?xml version='1.0' encoding='utf-8' ?>
<workbook>
  <datasources>
    <datasource name='sqlproxy.test' caption='Test DS'>
      <connection class='hyper' />
      <column name='[Revenue]' caption='Revenue' datatype='real' role='measure' type='quantitative' />
      <column name='[Profit Ratio]' caption='Profit Ratio' datatype='real' role='measure' type='quantitative'>
        <calculation class='tableau' formula='SUM([Profit])/SUM([Revenue])' />
      </column>
    </datasource>
  </datasources>
  <worksheets>
    <worksheet name='Sheet 1'>
      <table><view><mark class='Bar' /></view></table>
    </worksheet>
  </worksheets>
  <dashboards>
    <dashboard name='Overview'>
      <zones><zone name='Sheet 1' /></zones>
    </dashboard>
  </dashboards>
</workbook>
"""
    tmp = (_TMP / "_tableau_selftest.twb")
    tmp.write_text(sample_twb, encoding="utf-8")

    inspect = inspect_workbook(str(tmp))
    assert inspect["ok"], inspect
    assert inspect["datasources"][0]["calculated_field_count"] == 1
    print("  inspect_workbook: OK")

    validate = validate_workbook(str(tmp))
    assert validate["ok"] and validate["passed"], validate
    print("  validate_workbook: OK")

    added = add_calculated_field(
        str(tmp), "Test DS", "Margin Flag", "IIF([Profit Ratio] > 0.2, 'High', 'Low')"
    )
    assert added["ok"], added
    print("  add_calculated_field: OK")

    calcs = list_calculated_fields(str(tmp))
    assert calcs["ok"] and len(calcs["calculated_fields"]) == 2, calcs
    print("  list_calculated_fields: OK")

    # validate_workbook's formula-balance check must not be fooled by an
    # ordinary '(' or ')' character that's part of a string literal's display
    # text (a real, recurring case: a label ported verbatim from a source
    # system, e.g. "Pending Parking Event (>= 3 hours" with no closing paren
    # in the text itself) - that's valid Tableau syntax, not a broken formula.
    label_paren = add_calculated_field(
        str(tmp), "Test DS", "State Label",
        'CASE [Revenue] WHEN 1 THEN "Missing (>= 3 hours" ELSE "Present (< 3 hours)" END',
    )
    assert label_paren["ok"], label_paren
    v_label = validate_workbook(str(tmp))
    assert v_label["ok"] and v_label["passed"], v_label
    print("  validate_workbook doesn't false-positive on parens inside string literals: OK")

    # a genuinely unbalanced formula (missing paren in the FORMULA structure,
    # not inside a string) must still be caught
    real_bad = add_calculated_field(str(tmp), "Test DS", "Broken Calc", "SUM([Revenue]")
    assert real_bad["ok"], real_bad  # add_calculated_field itself doesn't validate syntax
    v_bad = validate_workbook(str(tmp))
    assert v_bad["ok"] and not v_bad["passed"], v_bad
    assert any("unbalanced_formulas" in issue for issue in v_bad["issues"] if isinstance(issue, dict)), v_bad
    # fix it back up (no remove_calculated_field tool exists) so later
    # selftest steps see a clean, passing workbook again
    fixed = edit_calculated_field(str(tmp), "Test DS", "Broken Calc", "SUM([Revenue])")
    assert fixed["ok"], fixed
    print("  validate_workbook still catches a genuinely unbalanced formula: OK")

    # fix-loop state tracking
    renders_dir = str(_TMP / "_selftest_renders")
    r0 = qa_get_attempts(renders_dir, "Sheet 1")
    assert r0["ok"] and r0["attempt_count"] == 0, r0
    qa_log_attempt(renders_dir, "Sheet 1", passed=False, notes="axis label showed raw field name")
    r1 = qa_log_attempt(renders_dir, "Sheet 1", passed=False, notes="still wrong after first fix")
    assert r1["ok"] and r1["attempt_number"] == 2, r1
    r2 = qa_get_attempts(renders_dir, "Sheet 1")
    assert r2["attempt_count"] == 2 and r2["last_passed"] is False, r2
    reset_qa_attempts(renders_dir, "Sheet 1")
    r3 = qa_get_attempts(renders_dir, "Sheet 1")
    assert r3["attempt_count"] == 0, r3
    print("  qa fix-loop tracking: OK")
    shutil.rmtree(Path(renders_dir).parent / QA_LOG_DIRNAME, ignore_errors=True)

    # chart template extraction (against the twbx built earlier in this test run's
    # sibling in-memory sample - build a minimal one here for isolation)
    tmp2 = (_TMP / "_selftest_chart.twb")
    tmp2.write_text(sample_twb, encoding="utf-8")
    templates_dir = str(_TMP / "_selftest_templates")
    extracted = extract_chart_templates(str(tmp2), templates_dir)
    assert extracted["ok"] and extracted["templates_extracted"] == 1, extracted
    listed = list_chart_templates(templates_dir)
    assert listed["ok"] and listed["count"] == 1, listed
    full = get_chart_template(templates_dir, "Sheet 1")
    assert full["ok"] and "worksheet_xml" in full["template"], full
    print("  chart template extraction: OK")

    recipe = generate_chart_recipe(templates_dir, "Sheet 1")
    assert recipe["ok"], recipe
    assert recipe["tokenization_warning"] is None, recipe
    # The synthetic sample's <worksheet> has no datasource-dependencies (its
    # fields are only declared at the datasource level, never referenced
    # on a shelf) - so zero field_slots is the correct result here, not a
    # bug. Real worksheets (tested separately against the 61-chart library)
    # do reference fields and produce populated slots - see below.
    assert recipe["field_slots"] == [], recipe
    all_recipes = generate_all_chart_recipes(templates_dir)
    assert all_recipes["ok"] and all_recipes["recipes_generated"] == 1, all_recipes
    print("  chart recipe generation: OK")

    shutil.rmtree(templates_dir, ignore_errors=True)
    tmp2.unlink()

    # --- chart recipe INSTANTIATION: a worksheet with real field references,
    # extracted/recipe'd from a "seed" workbook, then instantiated into a
    # different "target" workbook with entirely different field names - this
    # is the actual proof that substitution works, not just that it parses.
    seed_twb = """<?xml version='1.0' encoding='utf-8' ?>
<workbook>
  <datasources>
    <datasource name='federated.seed' caption='Seed DS'>
      <connection class='hyper' />
      <column name='[Revenue]' datatype='real' role='measure' type='quantitative' />
      <column caption='Category' name='[Category]' datatype='string' role='dimension' type='nominal' />
    </datasource>
  </datasources>
  <worksheets>
    <worksheet name='Seed Bar'>
      <layout-options>
        <title>
          <formatted-text>
            <run fontsize='14'>&lt;Sheet Name&gt; Chart</run>
          </formatted-text>
        </title>
      </layout-options>
      <table>
        <view>
          <datasources><datasource caption='Seed DS' name='federated.seed' /></datasources>
          <datasource-dependencies datasource='federated.seed'>
            <column datatype='real' name='[Revenue]' role='measure' type='quantitative' />
            <column caption='Category' datatype='string' name='[Category]' role='dimension' type='nominal' />
            <column-instance column='[Category]' derivation='None' name='[none:Category:nk]' pivot='key' type='nominal' />
            <column-instance column='[Revenue]' derivation='Sum' name='[sum:Revenue:qk]' pivot='key' type='quantitative' />
          </datasource-dependencies>
        </view>
        <style />
        <panes>
          <pane selection-relaxation-option='selection-relaxation-allow'>
            <view><breakdown value='auto' /></view>
            <mark class='Bar' />
            <encodings><color column='[federated.seed].[sum:Revenue:qk]' /></encodings>
          </pane>
        </panes>
        <rows>[federated.seed].[sum:Revenue:qk]</rows>
        <cols>[federated.seed].[none:Category:nk]</cols>
      </table>
      <simple-id uuid='{AAAAAAAA-AAAA-AAAA-AAAA-AAAAAAAAAAAA}' />
    </worksheet>
  </worksheets>
</workbook>
"""
    seed_path = (_TMP / "_selftest_seed.twb")
    seed_path.write_text(seed_twb, encoding="utf-8")

    target_twb = """<?xml version='1.0' encoding='utf-8' ?>
<workbook>
  <datasources>
    <datasource name='federated.target' caption='Target DS'>
      <connection class='hyper' />
      <column name='[Profit]' datatype='real' role='measure' type='quantitative' />
      <column caption='Region' name='[Region]' datatype='string' role='dimension' type='nominal' />
    </datasource>
  </datasources>
  <worksheets />
</workbook>
"""
    target_path = (_TMP / "_selftest_target.twb")
    target_path.write_text(target_twb, encoding="utf-8")

    inst_templates_dir = str(_TMP / "_selftest_inst_templates")
    ext = extract_chart_templates(str(seed_path), inst_templates_dir)
    assert ext["ok"] and ext["templates_extracted"] == 1, ext
    rec = generate_chart_recipe(inst_templates_dir, "Seed Bar")
    assert rec["ok"] and rec["tokenization_warning"] is None, rec
    slot_names = {s["placeholder"]: s["role"] for s in rec["field_slots"]}
    assert slot_names == {"MEA1": "measure", "DIM1": "dimension"}, slot_names

    # negative case: field doesn't exist in target datasource
    bad = instantiate_chart_recipe(
        str(target_path), inst_templates_dir, "Seed Bar", "Target DS",
        {"MEA1": "NoSuchField", "DIM1": "Region"}, "Bad Sheet 1",
    )
    assert not bad["ok"] and "not found" in bad["error"], bad

    # negative case: role mismatch (mapping a measure slot to a dimension field)
    bad2 = instantiate_chart_recipe(
        str(target_path), inst_templates_dir, "Seed Bar", "Target DS",
        {"MEA1": "Region", "DIM1": "Profit"}, "Bad Sheet 2",
    )
    assert not bad2["ok"] and "expects a" in bad2["error"], bad2
    print("  instantiate_chart_recipe rejects bad field_mapping: OK")

    # positive case: real substitution with different field names AND a custom caption
    good = instantiate_chart_recipe(
        str(target_path), inst_templates_dir, "Seed Bar", "Target DS",
        {"MEA1": "Profit", "DIM1": {"field": "Region", "caption": "Region Name"}},
        "My New Bar",
    )
    assert good["ok"], good
    assert good["field_mapping_used"] == {"MEA1": "Profit", "DIM1": "Region"}, good

    reread = inspect_workbook(str(target_path))
    assert reread["ok"], reread
    ws_names = {w["name"] for w in reread["worksheets"]}
    assert "My New Bar" in ws_names, ws_names
    new_ws_mark = next(w["mark_class"] for w in reread["worksheets"] if w["name"] == "My New Bar")
    assert new_ws_mark == "Bar", new_ws_mark

    raw_xml_after = target_path.read_text(encoding="utf-8")
    assert "Profit" in raw_xml_after and "Region" in raw_xml_after, "substituted field names should appear in the saved workbook"
    assert "{{" not in raw_xml_after, "no leftover placeholders should remain in the saved workbook"
    assert 'caption="Region Name"' in raw_xml_after, "custom caption override should have been applied"

    v = validate_workbook(str(target_path))
    assert v["ok"] and v["passed"], v
    print("  instantiate_chart_recipe end-to-end substitution: OK")

    # the source template's vestigial "<Sheet Name> Chart" title text must
    # NOT survive into the instantiated worksheet - it should be replaced
    # with the real new worksheet's name
    assert "<Sheet Name> Chart" not in raw_xml_after and "&lt;Sheet Name&gt; Chart" not in raw_xml_after, raw_xml_after
    assert "<run>My New Bar</run>" in raw_xml_after, raw_xml_after
    print("  instantiate_chart_recipe replaces vestigial template title text with the real worksheet name: OK")

    # --- add_worksheet_filter: bake a tile-specific categorical filter into
    # an already-instantiated worksheet (the "N tiles, one recipe, different
    # filter value each" pattern).
    bad_field = add_worksheet_filter(str(target_path), "My New Bar", "Target DS", "NoSuchField", ["West"])
    assert not bad_field["ok"] and "not found" in bad_field["error"], bad_field

    bad_role = add_worksheet_filter(str(target_path), "My New Bar", "Target DS", "Profit", ["1000"])
    assert not bad_role["ok"] and "not a dimension" in bad_role["error"], bad_role
    print("  add_worksheet_filter rejects bad field: OK")

    filt = add_worksheet_filter(str(target_path), "My New Bar", "Target DS", "Region", ["West"])
    assert filt["ok"], filt
    filt_xml = target_path.read_text(encoding="utf-8")
    assert 'column="[Target DS].[none:Region:nk]"' in filt_xml, filt_xml
    assert 'member="&quot;West&quot;"' in filt_xml or 'member="&amp;quot;West&amp;quot;"' in filt_xml or 'member=\'"West"\'' in filt_xml or '"West"' in filt_xml, filt_xml
    assert '<slices>' in filt_xml and '[Target DS].[none:Region:nk]' in filt_xml.split('<slices>', 1)[1], filt_xml

    v3 = validate_workbook(str(target_path))
    assert v3["ok"] and v3["passed"], v3

    # re-applying for the same field replaces rather than stacks a second filter
    filt2 = add_worksheet_filter(str(target_path), "My New Bar", "Target DS", "Region", ["East", "Central"])
    assert filt2["ok"], filt2
    filt_xml2 = target_path.read_text(encoding="utf-8")
    assert filt_xml2.count('class="categorical" column="[Target DS].[none:Region:nk]"') == 1, filt_xml2
    assert 'function="union"' in filt_xml2, "multi-value filter should OR its members"
    print("  add_worksheet_filter bakes and replaces a tile-specific filter: OK")

    # --- build_crosstab_worksheet: a plain table tile (no chart-recipe path)
    bad_ct_field = build_crosstab_worksheet(str(target_path), "Target DS", "Bad Table", ["NoSuchField"], [], ["Profit"])
    assert not bad_ct_field["ok"] and "not found" in bad_ct_field["error"], bad_ct_field

    bad_ct_empty = build_crosstab_worksheet(str(target_path), "Target DS", "Bad Table 2", [], [], [])
    assert not bad_ct_empty["ok"] and "text_fields" in bad_ct_empty["error"], bad_ct_empty
    print("  build_crosstab_worksheet rejects bad input: OK")

    ct = build_crosstab_worksheet(str(target_path), "Target DS", "Region Table", ["Region"], [], ["Profit"])
    assert ct["ok"], ct
    ct_xml = target_path.read_text(encoding="utf-8")
    assert 'name="Region Table"' in ct_xml, ct_xml
    assert '<column-instance column="[Region]" derivation="None" name="[none:Region:nk]"' in ct_xml, ct_xml
    assert '<column-instance column="[Profit]" derivation="Sum" name="[sum:Profit:qk]"' in ct_xml, ct_xml
    assert '<rows>[federated.target].[none:Region:nk]</rows>' in ct_xml, ct_xml
    assert '<text column="[federated.target].[sum:Profit:qk]" />' in ct_xml, ct_xml
    assert '<mark class="Text" />' in ct_xml, ct_xml

    v_ct = validate_workbook(str(target_path))
    assert v_ct["ok"] and v_ct["passed"], v_ct

    # duplicate name auto-dedupes, matching instantiate_chart_recipe's convention
    ct_dup = build_crosstab_worksheet(str(target_path), "Target DS", "Region Table", ["Region"], [], ["Profit"])
    assert ct_dup["ok"] and ct_dup["renamed"] and ct_dup["worksheet_name"] == "Region Table 2", ct_dup
    print("  build_crosstab_worksheet end-to-end table build: OK")

    # --- dashboard layout instantiation: place worksheets (the one just
    # built via recipe instantiation, plus two more bare ones) into a grid.
    t2 = load_workbook_xml(str(target_path))[0]
    t2_root = t2.getroot()
    ws_el = t2_root.find("./worksheets")
    for extra_name in ("Extra 1", "Extra 2"):
        w = ET.SubElement(ws_el, "worksheet", {"name": extra_name})
        tbl = ET.SubElement(w, "table")
        view = ET.SubElement(tbl, "view")
        ET.SubElement(view, "mark", {"class": "Bar"})
    save_workbook_xml(str(target_path), t2, "twb", None)

    # negative: unknown worksheet
    bad3 = instantiate_dashboard_layout(str(target_path), "Bad Dash", [["My New Bar", "No Such Sheet"]])
    assert not bad3["ok"] and "not found" in bad3["error"], bad3

    # negative: same worksheet twice on one dashboard
    bad4 = instantiate_dashboard_layout(str(target_path), "Bad Dash 2", [["My New Bar", "My New Bar"]])
    assert not bad4["ok"] and "more than once" in bad4["error"], bad4
    print("  instantiate_dashboard_layout rejects bad layout: OK")

    # positive: 2-up top row (weighted 2:1) + full-width bottom row
    dash = instantiate_dashboard_layout(
        str(target_path),
        "Overview",
        [[{"worksheet": "My New Bar", "weight": 2}, "Extra 1"], ["Extra 2"]],
        title="Overview Dashboard",
        row_heights=[2, 1],
    )
    assert dash["ok"], dash

    dash_xml_after = target_path.read_text(encoding="utf-8")
    assert "<dashboard name=\"Overview\">" in dash_xml_after or "name=\"Overview\"" in dash_xml_after, dash_xml_after
    assert 'name="My New Bar"' in dash_xml_after and 'name="Extra 1"' in dash_xml_after and 'name="Extra 2"' in dash_xml_after

    reread2 = inspect_workbook(str(target_path))
    assert reread2["ok"], reread2

    v2 = validate_workbook(str(target_path))
    assert v2["ok"] and v2["passed"], v2

    # duplicate dashboard name is auto-deduped, not rejected
    dup = instantiate_dashboard_layout(str(target_path), "Overview", [["Extra 1"]])
    assert dup["ok"] and dup["renamed"] and dup["dashboard_name"] == "Overview 2" and dup["requested_dashboard_name"] == "Overview", dup
    dash_xml_after_dup = target_path.read_text(encoding="utf-8")
    assert 'name="Overview 2"' in dash_xml_after_dup, dash_xml_after_dup
    print("  instantiate_dashboard_layout end-to-end grid build: OK")
    print("  instantiate_dashboard_layout auto-dedupes name collision: OK")

    # --- parameters ---
    bad_combo = add_parameter(str(target_path), "Bad Param", "list", "integer", 1, list_values=[1, 2])
    assert not bad_combo["ok"] and "Unsupported combination" in bad_combo["error"], bad_combo

    p1 = add_parameter(str(target_path), "Region Choice", "list", "string", "West", list_values=["East", "West", "Central", "South"])
    assert p1["ok"], p1
    dup_p = add_parameter(str(target_path), "Region Choice", "list", "string", "West", list_values=["East"])
    assert not dup_p["ok"] and "already exists" in dup_p["error"], dup_p

    p2 = add_parameter(str(target_path), "Profit Target", "range", "real", 1000.0, range_min=0.0, range_max=5000.0, range_granularity=100.0)
    assert p2["ok"], p2

    p3 = add_parameter(str(target_path), "As Of Date", "any", "date", "2024-01-15", default_format="*dd mmmm yyyy")
    assert p3["ok"], p3

    params_xml = target_path.read_text(encoding="utf-8")
    assert 'name="Parameters"' in params_xml
    assert 'value="&quot;West&quot;"' in params_xml
    assert '<range granularity="100.0" max="5000.0" min="0.0" />' in params_xml
    assert 'value="#2024-01-15#"' in params_xml
    print("  add_parameter (list/range/any): OK")

    # --- LOD calculation recipes ---
    patterns = list_lod_patterns()
    assert patterns["ok"] and set(patterns["patterns"]) == set(LOD_PATTERNS), patterns

    bad_agg = instantiate_lod_calculation(str(target_path), "Target DS", "fixed_aggregate", {"DIM": "Region", "AGG": "NOTANAGG", "MEASURE": "Profit"}, "Bad LOD")
    assert not bad_agg["ok"] and "not a supported aggregation" in bad_agg["error"], bad_agg

    bad_field = instantiate_lod_calculation(str(target_path), "Target DS", "fixed_aggregate", {"DIM": "NoSuchDim", "AGG": "SUM", "MEASURE": "Profit"}, "Bad LOD 2")
    assert not bad_field["ok"] and "not found" in bad_field["error"], bad_field

    lod1 = instantiate_lod_calculation(str(target_path), "Target DS", "fixed_aggregate", {"DIM": "Region", "AGG": "SUM", "MEASURE": "Profit"}, "Total Profit by Region")
    assert lod1["ok"], lod1
    lod_xml = target_path.read_text(encoding="utf-8")
    assert "{FIXED [Region] : SUM([Profit])}" in lod_xml, lod_xml
    print("  instantiate_lod_calculation: OK")

    # --- dashboard controls: legend, filter, parameter ---
    ctrl_dash = instantiate_dashboard_layout(
        str(target_path), "Overview With Controls", [["My New Bar"]],
        controls=[
            {"kind": "legend", "worksheet": "My New Bar"},
            {"kind": "filter", "worksheet": "My New Bar", "datasource_name": "federated.target", "field": "Region"},
            {"kind": "parameter", "parameter_name": "Region Choice"},
        ],
    )
    assert ctrl_dash["ok"], ctrl_dash

    bad_legend = instantiate_dashboard_layout(str(target_path), "Bad Controls 1", [["Extra 1"]], controls=[{"kind": "legend", "worksheet": "Extra 1"}])
    assert not bad_legend["ok"] and "no color encoding" in bad_legend["error"], bad_legend

    bad_filter_ctrl = instantiate_dashboard_layout(str(target_path), "Bad Controls 2", [["Extra 1"]], controls=[{"kind": "filter", "worksheet": "Extra 1", "datasource_name": "federated.target", "field": "Region"}])
    assert not bad_filter_ctrl["ok"] and "no column-instance" in bad_filter_ctrl["error"], bad_filter_ctrl

    bad_param_ctrl = instantiate_dashboard_layout(str(target_path), "Bad Controls 3", [["Extra 1"]], controls=[{"kind": "parameter", "parameter_name": "No Such Param"}])
    assert not bad_param_ctrl["ok"] and "not found" in bad_param_ctrl["error"], bad_param_ctrl

    controls_xml = target_path.read_text(encoding="utf-8")
    assert 'type-v2="color"' in controls_xml
    assert 'type-v2="filter"' in controls_xml
    assert 'type-v2="paramctrl"' in controls_xml
    assert 'param="[Parameters].[Region Choice]"' in controls_xml
    assert 'class="categorical"' in controls_xml and 'ui-enumeration="all"' in controls_xml
    print("  instantiate_dashboard_layout controls (legend/filter/parameter): OK")

    v3 = validate_workbook(str(target_path))
    assert v3["ok"] and v3["passed"], v3

    # --- dashboard actions: highlight, url, nav, parameter, filter ---
    a_highlight = add_dashboard_action(str(target_path), "Overview", "highlight", "Highlight Region", field_captions="Region")
    assert a_highlight["ok"], a_highlight

    a_url = add_dashboard_action(str(target_path), "Overview", "url", "Open Docs", url="https://www.tableau.com")
    assert a_url["ok"], a_url

    a_nav = add_dashboard_action(str(target_path), "Overview", "nav", "Go To Controls", target_sheet="Overview With Controls")
    assert a_nav["ok"], a_nav
    bad_nav = add_dashboard_action(str(target_path), "Overview", "nav", "Bad Nav", target_sheet="No Such Sheet")
    assert not bad_nav["ok"] and "not a known dashboard or worksheet" in bad_nav["error"], bad_nav

    a_param_action = add_dashboard_action(
        str(target_path), "Overview With Controls", "parameter", "Set Region",
        source_worksheet="My New Bar", datasource_name="federated.target", source_field="Region",
        agg_type="attr", parameter_name="Region Choice",
    )
    assert a_param_action["ok"], a_param_action
    bad_param_action = add_dashboard_action(
        str(target_path), "Overview With Controls", "parameter", "Bad Set",
        source_worksheet="My New Bar", datasource_name="federated.target", source_field="NoSuchField",
        agg_type="attr", parameter_name="Region Choice",
    )
    assert not bad_param_action["ok"], bad_param_action

    a_filter_action = add_dashboard_action(
        str(target_path), "Overview", "filter", "Filter Extra 1",
        target_worksheet="Extra 1", datasource_name="federated.target",
        field_pairs=[{"source_field": "Region"}],
    )
    assert a_filter_action["ok"], a_filter_action

    bad_action_type = add_dashboard_action(str(target_path), "Overview", "not-a-type", "X")
    assert not bad_action_type["ok"] and "action_type must be one of" in bad_action_type["error"], bad_action_type

    actions_xml = target_path.read_text(encoding="utf-8")
    assert "tsc:brush" in actions_xml
    assert "www.tableau.com" in actions_xml
    assert "<nav-action" in actions_xml
    assert "<edit-parameter-action" in actions_xml
    assert "tsc:tsl-filter" in actions_xml and "tsl:Extra 1?" in actions_xml
    print("  add_dashboard_action (highlight/url/nav/parameter/filter): OK")

    v4 = validate_workbook(str(target_path))
    assert v4["ok"] and v4["passed"], v4

    shutil.rmtree(inst_templates_dir, ignore_errors=True)
    shutil.rmtree(str(_TMP / "_backups"), ignore_errors=True)
    seed_path.unlink()
    target_path.unlink()

    lib = get_chart_library_path()
    if lib["ok"]:
        assert lib["recipe_count"] > 0, lib
        print(f"  get_chart_library_path: OK ({lib['recipe_count']} recipes)")
    else:
        print("  get_chart_library_path: skipped (no bundled library next to server.py)")

    print("All self-tests passed.")
    shutil.rmtree(_TMP, ignore_errors=True)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--selftest", action="store_true")
    args = parser.parse_args()
    if args.selftest:
        _selftest()
        sys.exit(0)
    mcp.run()
