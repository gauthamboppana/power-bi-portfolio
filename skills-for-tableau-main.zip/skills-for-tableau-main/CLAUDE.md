# Tableau Development Instructions (Claude Code)

> **Updates**: `tableau-collection` is a third-party marketplace. To enable auto-update, run `/plugin`, open **Marketplaces**, select `tableau-collection`, and choose **Enable auto-update**. To update on demand, run `claude plugin update tableau-skills@tableau-collection`.

@./AGENTS.md

## Claude Code specifics

- MCP tools appear as `mcp__tableau-desktop__<tool>`. The plugin registers the server. In a plain clone, `.mcp.json` at the repo root registers it.
- Subagents: `TableauReportDeveloper`, `TableauDataEngineer`, `TableauQA`, `TableauMigrationEngineer`. Run QA in `TableauQA` so the builder doesn't grade its own work.
- To see a render, open the PNG with the Read tool. Visual review means looking at the image.
