# Skills for Tableau

Agent skills, agents and an MCP server that let AI coding assistants (Claude Code, GitHub Copilot CLI, Cursor, Windsurf, Codex, Gemini CLI) **plan, build, verify and publish Tableau workbooks**: real `.twb`/`.twbx` files, written directly. No screenshots-to-code or "rename JSON to .twb" shortcuts.

Modeled on [microsoft/skills-for-fabric](https://github.com/microsoft/skills-for-fabric), which does the same for Fabric and Power BI.

```
 request / BRD / LookML
          │
  TableauReportDeveloper ──► planning ─► datasource ─► design ─► authoring ─► TableauQA ─► publish
          │                     (tableau-report-cli modes + tableau-datasource-authoring)        (tableau-server-cli)
          ▼
  tableau-desktop MCP server: 32 tools that read and write .twb/.twbx/.hyper, back up before every write, validate after
```

## Install

### Claude Code

```bash
/plugin marketplace add GauthamBoppana2811/skills-for-tableau
/plugin install tableau-skills@tableau-collection
```

Then install the MCP server's Python dependencies once (Python 3.10+):

```bash
pip install "mcp>=1.2,<2" Pillow pandas            # core
pip install tableauhyperapi tableauserverclient    # optional: .hyper extracts, Server/Cloud
```

To get automatic updates: `/plugin` → **Marketplaces** → `tableau-collection` → **Enable auto-update**.

### GitHub Copilot CLI

```bash
/plugin marketplace add GauthamBoppana2811/skills-for-tableau
/plugin install tableau-skills@tableau-collection
```

### One skill only (APM)

```bash
apm install GauthamBoppana2811/skills-for-tableau --skill tableau-report-cli --target claude
```

### Any other tool

Clone the repo. [AGENTS.md](AGENTS.md), [CLAUDE.md](CLAUDE.md), [GEMINI.md](GEMINI.md), `.cursorrules` and `.windsurfrules` are picked up automatically, and [mcp-setup/README.md](mcp-setup/README.md) covers MCP registration per host.

## What's included

### Skills

| Skill | Use it for |
|---|---|
| [`tableau-report-cli`](skills/tableau-report-cli/SKILL.md) | The report lifecycle in four modes: **planning** (requirements/BRD → approved spec), **design** (chart and layout from the recipe library), **authoring** (worksheets, grid dashboards, quick filters, legends, parameter controls, actions), **qa** (validate → render → review → fix, 3-attempt cap) |
| [`tableau-datasource-authoring`](skills/tableau-datasource-authoring/SKILL.md) | Connect a blank workbook (Postgres, Excel, `.hyper`; Snowflake unverified), calculated fields, verified LOD patterns, parameters, `.hyper` extracts |
| [`tableau-chart-library`](skills/tableau-chart-library/SKILL.md) | Browse and extend the 81-chart template/recipe library |
| [`tableau-server-cli`](skills/tableau-server-cli/SKILL.md) | Publish, render PNG/PDF, refresh and download on Tableau Server/Cloud (PAT auth). Makes the QA render step automatic |
| [`looker-to-tableau-migration`](skills/looker-to-tableau-migration/SKILL.md) | LookML (+ dashboard PDF) → a literal, gap-honest BRD → Tableau build |

### Agents

| Agent | Role |
|---|---|
| [`TableauReportDeveloper`](agents/TableauReportDeveloper.agent.md) | Runs builds end to end and delegates |
| [`TableauDataEngineer`](agents/TableauDataEngineer.agent.md) | Data layer |
| [`TableauQA`](agents/TableauQA.agent.md) | Independent verification gate with a retry cap |
| [`TableauMigrationEngineer`](agents/TableauMigrationEngineer.agent.md) | Looker → Tableau |

### MCP server and chart library

- [`mcp-server/`](mcp-server/README.md): the `tableau-desktop` stdio server, 32 tools ([catalog](common/MCP-TOOLS.md)). Every XML shape it writes was reverse-engineered from real Tableau-saved files; unverified shapes are refused.
- [`chart-library/`](chart-library/README.md): 81 charts, each as a raw template plus a role-tagged recipe ([catalog](skills/tableau-report-cli/references/chart-catalog.md)).

### Apps

- [`apps/brd-ui`](apps/brd-ui/README.md): a Streamlit chat UI over the same tools. Upload a BRD (or LookML) and a starter workbook, talk to the agent, download the result. For people who don't use an agent host.

## Try it

After installing, open your agent in a folder with a workbook and try:

- [Superstore dashboard from scratch](prompt_examples/SuperstoreDashboardFromScratch.txt)
- [BRD → workbook](prompt_examples/BRDToWorkbook.txt)
- [Looker migration](prompt_examples/LookerMigration.txt)
- [Publish and render on Tableau Cloud](prompt_examples/PublishAndRender.txt)
- [Calcs, LOD and parameters](prompt_examples/AddCalcAndLOD.txt)
- [Grow the chart library](prompt_examples/GrowChartLibrary.txt)

## Authentication (Server/Cloud only)

Desktop-only work needs no auth. For `tableau-server-cli`, create a Personal Access Token in Tableau (My Account Settings → Personal Access Tokens), then set:

```bash
export TABLEAU_SERVER_URL=https://<pod>.online.tableau.com
export TABLEAU_SITE=<site content url>      # "" for the Default site on Server
export TABLEAU_PAT_NAME=<token name>
export TABLEAU_PAT_SECRET=<token secret>     # keep out of chat, files and shell history
```

## What it can and can't do today

| ✅ Automated | ⚠️ Still a Tableau Desktop step |
|---|---|
| Connect a blank workbook (Postgres, Excel, Hyper) | Multi-table relationship models; Snowflake connection unverified |
| Calcs, 5 verified LOD patterns, parameters (list/range/date) | Other parameter types |
| Worksheets from 81 chart recipes, crosstabs, baked-in categorical filters | Charts with no recipe; formatting polish |
| Grid dashboards with legends, categorical quick filters, parameter controls | Floating/tabbed layouts; measure, date or range quick filters |
| Highlight / URL / nav / parameter / filter actions | — |
| QA loop: validate, data checks, pixel diff, visual review, retry cap | Render on Desktop-only setups (user exports one image); automatic with Server/Cloud |
| Publish / render / refresh on Server/Cloud | Permissions, schedules, RLS |

## Repository layout

```
skills/            source skills (SKILL.md dispatcher + references/)
agents/            orchestrating agents
common/            shared rules: TABLEAU-CORE, DESIGN-CONTRACT, MCP-TOOLS
mcp-server/        tableau-desktop MCP server
chart-library/     81 chart templates + recipes
apps/brd-ui/       Streamlit app
mcp-setup/         MCP registration for every host
build/build.py     generates everything below and validates links/frontmatter/recipe names
plugins/tableau-skills/            (generated) self-contained plugin bundle
.claude-plugin/marketplace.json    (generated) Claude Code marketplace
.github/plugin/marketplace.json    (generated) Copilot CLI marketplace
apm.yml, skills/*/apm.yml          (generated) APM manifests
.cursorrules, .windsurfrules       (generated) from AGENTS.md
```

## Contributing

See [CONTRIBUTING.md](CONTRIBUTING.md). In short: edit sources, run `python build/build.py`, and make sure `python build/build.py --check` and `python mcp-server/server.py --selftest` pass. Release notes are in [CHANGELOG.md](CHANGELOG.md).

## License

[MIT](LICENSE). Not affiliated with or endorsed by Tableau or Salesforce. Tableau is a trademark of Salesforce, Inc.
