# Security

Please report vulnerabilities privately through GitHub's **Security → Report a vulnerability** on this repository rather than in a public issue.

Design rules this project follows, which reports against are especially welcome:

- No credentials in workbooks, repo files, chat or command lines. Tableau Server/Cloud auth reads `TABLEAU_PAT_NAME` / `TABLEAU_PAT_SECRET` from the environment.
- `create_datasource` leaves database passwords unset by default, so Tableau Desktop prompts on open.
- Every mutating MCP tool backs up the workbook before writing.
- `apps/brd-ui/.ui_settings.json` may store an Anthropic API key locally and is git-ignored.
