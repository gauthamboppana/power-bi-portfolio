# Contributing

## Layout: sources vs. generated

Edit **sources** only: `skills/`, `agents/`, `common/`, `mcp-server/`, `chart-library/`, `AGENTS.md`, `package.json`.

Everything else is **generated** by `python build/build.py`: `plugins/tableau-skills/`, both `marketplace.json` files, `apm.yml` files, `.cursorrules`, `.windsurfrules` and the chart catalog. CI runs `python build/build.py --check` and fails on stale output, broken relative links, bad skill frontmatter, or a recipe name in the docs that isn't in the library.

## Before opening a PR

```bash
pip install "mcp>=1.2,<2" Pillow pandas tableauserverclient
python mcp-server/server.py --selftest
python build/build.py          # regenerate
python build/build.py --check  # what CI runs
```

## Conventions

- **Skills**: `SKILL.md` frontmatter needs `name` (= folder name), `description` (≤ 1024 chars, ending with `Triggers: ...`) and `metadata.version`. Keep SKILL.md a short dispatcher and put procedures in `references/`. Link shared material through `../../common/`.
- **New XML shapes**: extract them from a real Tableau-saved file and add a self-test case. Don't hand-write XML from memory. If a shape is unverified, the tool should refuse it.
- **Agents**: `agents/<Name>.agent.md` with `name` and `description` frontmatter, plus Personality / Delegation rules / Must / Must not sections.
- **Versioning**: bump `version` in `package.json` (the build propagates it) and add a CHANGELOG entry. Bump a skill's `metadata.version` when its behavior changes.
- **Commits**: never commit workbooks, `.hyper` files, `_backups/`, `_renders/` or API keys (`.gitignore` covers the usual paths).
