# `tableau-desktop` MCP tool catalog

The server lives in [`mcp-server/server.py`](../mcp-server/server.py). In Claude Code, tools appear as `mcp__tableau-desktop__<name>`; other hosts show `tableau-desktop/<name>` or similar. **W** = writes the workbook (backs up first, then run `validate_workbook`).

## Inspect and validate

| Tool | W | Use it to |
|---|---|---|
| `list_workbooks(folder)` | | Find `.twb`/`.twbx` files under a folder. |
| `inspect_workbook(path)` | | List datasources (fields, roles, datatypes, calcs), worksheets, dashboards. **Always the first call** on a workbook. |
| `list_calculated_fields(path, datasource_name?)` | | Read existing calc formulas. |
| `validate_workbook(path)` | | Check zip integrity, well-formed XML, required sections, and formula bracket/quote balance. Run after every write. |

## Data source layer

| Tool | W | Use it to |
|---|---|---|
| `create_datasource(workbook_path, datasource_name, platform, fields, ...)` | W | Connect a blank workbook: `postgres` / `excel` / `hyper` (verified), `snowflake` (unverified). One table or one `custom_sql`. |
| `add_calculated_field(path, datasource_name, field_name, formula, caption?, datatype?, role?)` | W | Add a calc. |
| `edit_calculated_field(path, datasource_name, field_name, new_formula)` | W | Change a calc's formula. |
| `add_parameter(workbook_path, name, domain_type, datatype, current_value, ...)` | W | Verified combinations only: list+string, range+integer/real, any+date. |
| `list_lod_patterns()` | | See the 5 verified FIXED/INCLUDE/EXCLUDE patterns. |
| `instantiate_lod_calculation(workbook_path, datasource_name, pattern_name, field_mapping, new_field_name, caption?)` | W | Build an LOD calc from a pattern. |

## Extracts (needs `tableauhyperapi`)

| Tool | W | Use it to |
|---|---|---|
| `create_hyper_extract(csv_path, hyper_path, table_name?)` | | Build a `.hyper` from a CSV. |
| `query_hyper(hyper_path, sql)` | | Run read-only SQL; spot-check values. |
| `validate_data(hyper_path, table_name, rules)` | | Check row counts, not-null columns and bounds. |

## Chart library

| Tool | W | Use it to |
|---|---|---|
| `get_chart_library_path()` | | Get the bundled library path. **Pass it as `templates_dir`** everywhere below. |
| `list_chart_templates(templates_dir)` | | Browse the 81 charts (name, mark, fields). |
| `get_chart_template(templates_dir, name)` | | Read one template's raw XML. |
| `generate_chart_recipe(templates_dir, name)` | | (Re)build a recipe and read its placeholder slots and roles. Writes `<name>.recipe.json` into the library. |
| `generate_all_chart_recipes(templates_dir)` | | Rebuild all recipes after adding templates. |
| `extract_chart_templates(source_workbook, templates_dir)` | | Grow the library from a workbook whose sheets are example charts. |

## Worksheets

| Tool | W | Use it to |
|---|---|---|
| `instantiate_chart_recipe(workbook_path, templates_dir, recipe_name, datasource_name, field_mapping, new_worksheet_name)` | W | Build a worksheet from a recipe. `field_mapping` = `{"DIM1": "Region", "MEA1": {"field": "Sales", "caption": "Total Sales"}}`. Checks that each field exists and its role matches. |
| `build_crosstab_worksheet(workbook_path, datasource_name, new_worksheet_name, rows, cols, text_fields)` | W | Build a plain table (no recipe). |
| `add_worksheet_filter(workbook_path, worksheet_name, datasource_name, field, values)` | W | Add a baked-in categorical filter (string/boolean). Use it for "same chart, one tile per value". |

## Dashboards

| Tool | W | Use it to |
|---|---|---|
| `instantiate_dashboard_layout(workbook_path, dashboard_name, layout, title?, row_heights?, controls?)` | W | Build a grid dashboard, with legends, categorical quick filters and parameter controls. |
| `add_dashboard_action(workbook_path, dashboard_name, action_type, caption, ...)` | W | Add a `highlight`, `url`, `nav`, `parameter` or `filter` action. |

## Render and QA loop

| Tool | W | Use it to |
|---|---|---|
| `request_render(workbook_path, target_name, renders_dir)` | | Register a manual export request; returns the exact filename for the user to save. |
| `list_pending_renders(renders_dir)` | | See which exports have arrived. |
| `check_render(image_path)` | | Catch corrupt or blank images. |
| `pixel_diff(baseline_path, new_path, diff_out_path?)` | | Get the % of pixels that changed (a flag to look closer, not a verdict). |
| `approve_baseline(new_path, baseline_path)` | | Lock in a reviewed render. Only after explicit approval. |
| `qa_log_attempt(renders_dir, target_name, passed, notes)` | | Log every QA pass or fail. |
| `qa_get_attempts(renders_dir, target_name)` | | Read history; **3 failures = stop and escalate**. |
| `reset_qa_attempts(renders_dir, target_name)` | | Reset the count only when starting genuinely new work on a target. |
