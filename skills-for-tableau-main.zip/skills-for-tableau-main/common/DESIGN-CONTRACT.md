# Design contracts — the YAML handed between stages

Three documents carry a build from request to finished workbook. Each stage reads the previous document and does not re-decide it.

```
report_spec  (planning)  ->  design + dashboard  (design)  ->  tool calls  (authoring)  ->  QA log  (qa)
```

## 1. `report_spec` — written by planning, approved by the user

Save it as `_brief/report-spec.md` next to the workbook: human-readable Markdown with this block embedded.

```yaml
report_spec:
  audience: "Regional sales managers"
  job_to_be_done: "Spot under-performing sub-categories each Monday"
  environment: "desktop_only | server | cloud"
  data_sources:
    - name: "Sample - Superstore"          # exact datasource name or caption from inspect_workbook
      connection_type: "live | extract"
      grain: "one row per order line"
      fields_in_scope: ["Region", "Sub-Category", "Order Date", "Sales", "Profit"]
  dashboards:
    - name: "Weekly Sales Review"
      worksheets:
        - name: "Sales Trend"
          intent: "trend"                    # trend | comparison | distribution | composition | ranking | correlation | single-value | geospatial | calendar | table
          filters: ["Region"]
      actions: ["filter: Sales by Region -> Sales Trend"]
  delivery:
    target: "desktop_only | server_publish"
    starter_workbook_path: "C:/work/superstore_starter.twbx"
    publish:                                 # only when target = server_publish
      server_url: "https://..."
      site: "..."
      project: "..."
  out_of_scope: ["Measure range filter on Profit - Desktop step"]
```

## 2. `design` — one per worksheet, written by design

```yaml
design:
  worksheet: "Sales Trend"
  intent: "trend"
  mark_type: "Line"
  matched_template: "Line"                   # exact recipe name from the chart library, or null
  field_mapping:                             # recipe placeholder -> real field (only when matched_template is set)
    DIM1: "Order Date"
    MEA1: { field: "Sales", caption: "Total Sales" }
  worksheet_filters:                         # baked-in filters -> add_worksheet_filter
    - { field: "Segment", values: ["Consumer"] }
  title: "Sales rose 12% after the Q3 promo" # an insight, not just a field name
  notes: "anything the recipe cannot express"
```

`matched_template: null` means one of two things: use `build_crosstab_worksheet` (intent `table`), or the chart must be built in Desktop. Say which.

## 3. `dashboard` — one per dashboard, written by design

```yaml
dashboard:
  name: "Weekly Sales Review"
  title: "Weekly Sales Review"
  layout:                                    # rows top-to-bottom
    - [{ worksheet: "Sales Trend", weight: 2 }, "Sales by Region"]
    - ["Sub-Category Ranking"]
  row_heights: [2, 1]
  controls:                                  # -> instantiate_dashboard_layout(controls=...)
    - { kind: "legend", worksheet: "Sales by Region" }
    - { kind: "filter", worksheet: "Sales by Region", datasource_name: "Sample - Superstore", field: "Region" }
    - { kind: "parameter", parameter_name: "Top N" }
  actions:                                   # -> add_dashboard_action, after the dashboard exists
    - { action_type: "filter", caption: "Region drill", source_worksheet: "Sales by Region",
        target_worksheet: "Sales Trend", datasource_name: "Sample - Superstore",
        field_pairs: [{ source_field: "Region" }] }
  layout_notes: "only what a grid cannot express (floating, tabs) - needs Desktop"
```

Preconditions the authoring step checks:

- A legend needs its worksheet to already have a color encoding.
- A filter control, parameter action or filter action needs its field to already be on that worksheet's shelves.
- A parameter control or action needs the parameter to already exist (`add_parameter`).

## 4. QA log — written by qa

Kept by the server through `qa_log_attempt`, one JSON file per target, in a `_qa/` folder beside `renders_dir`. Use `<workbook folder>/_renders` as `renders_dir` throughout so the logs stay with the workbook. Each failure note must name the specific check and what was wrong. "Axis shows raw field name `[Profit Ratio]`" is usable; "looks off" is not.
