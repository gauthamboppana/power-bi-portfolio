# Tableau Core — shared rules for every skill

Every skill in this repo links here. Read it once per session before changing a workbook.

## 1. What you are editing

| File | What it really is | Notes |
|---|---|---|
| `.twb` | One XML document (Tableau workbook schema) | Editable directly. |
| `.twbx` | A zip holding one `.twb` plus data/images | The MCP tools open the zip, edit the inner `.twb`, and re-zip. Never rename a text file to `.twbx`. |
| `.tds` / `.tdsx` | Data source only (XML / zipped XML) | Same structure as a `<datasource>` inside a `.twb`. |
| `.hyper` | Tableau extract (columnar database) | Read and write only through the Hyper API (`create_hyper_extract`, `query_hyper`). |

A `.twb` has this skeleton. The tools read and write each part:

```xml
<workbook>
  <preferences/>
  <datasources>           <!-- connections, columns, calculated fields, the 'Parameters' pseudo-datasource -->
  <worksheets>            <!-- one <worksheet> per sheet: <table><view> holds shelves, marks, encodings -->
  <dashboards>            <!-- zone tree, coordinates 0..100000 on each axis -->
  <actions>               <!-- filter / highlight / url / nav / parameter actions -->
  <windows>               <!-- which sheets are open; tabs -->
</workbook>
```

## 2. Non-negotiable safety rules

1. **Use an MCP tool when one exists.** Each mutating tool backs the workbook up to `_backups/` next to it before writing. Hand-edited XML skips that and skips validation.
2. **Run `validate_workbook` after every write.** If it fails, restore the backup the tool reported and try again; do not stack further edits on a broken file.
3. **"Saved" is not "correct".** Done means the file reopens in Tableau Desktop *and* the render loop passed (see `skills/tableau-report-cli/references/qa.md`).
4. **Never invent a field.** Every field name you map must come from `inspect_workbook` output. A field the data does not have is a scope conversation with the user, not a guess.
5. **Use the name the tool returns.** `instantiate_chart_recipe`, `build_crosstab_worksheet` and `instantiate_dashboard_layout` auto-suffix colliding names (`" 2"`); use the `worksheet_name` / `dashboard_name` they return in later calls.
6. **Keep secrets out of workbooks.** `create_datasource` accepts `password`, but writing it is unverified and stores it in plain text. Leave it unset so Desktop prompts on open.
7. **Stay inside verified shapes.** The tools refuse XML shapes nobody has verified against a real file (for example an unverified parameter type). Pass that refusal on to the user; do not hand-write the XML.

## 3. Starting point: the starter workbook

Every build edits **one real workbook file** in place. Get it in one of two ways:

- **The user provides one**: a `.twb`/`.twbx` already connected to the data, with nothing built yet, or an existing workbook to extend.
- **You create the connection**: start from a blank `.twb` and call `create_datasource` (platforms: `postgres`, `excel`, `hyper` verified; `snowflake` by analogy, unverified). A multi-table relationship model is not supported; pre-join into `custom_sql` or finish it in Desktop.

Record the path; every later step uses that one file.

## 4. Desktop vs Server/Cloud

| Capability | Desktop only (local files) | With Tableau Server / Cloud |
|---|---|---|
| Author workbook XML | ✅ MCP tools | ✅ same tools, then publish |
| Build/query extracts | ✅ Hyper API | ✅ plus server-side refresh |
| Render an image of a view | ⚠️ manual: user exports from Desktop | ✅ REST `views/{id}/image` (`tableau-server-cli`) |
| Publish, refresh, permissions | ❌ | ✅ `tableau-server-cli` |

Ask which environment the user has before planning; it decides whether the render step is manual.

## 5. Known gaps (say these plainly; never work around them silently)

- Quick filters on **measures / ranges / dates** are not supported (categorical dimensions only). That stays a Desktop step.
- Dashboards are **grids only**: no floating containers, tabs, or overlays.
- Chart types not in the 81-recipe library must be built in Desktop, or added to the library first (`tableau-chart-library`).
- Visual polish (fonts, custom palettes, tooltip text, conditional cell shading) is not authored by the tools.
- The `snowflake` connection shape and embedded passwords are unverified.

## 6. Shared artifacts

The YAML contracts that pass between planning → design → authoring → QA are defined once in [DESIGN-CONTRACT.md](DESIGN-CONTRACT.md). The full tool catalog is in [MCP-TOOLS.md](MCP-TOOLS.md).
