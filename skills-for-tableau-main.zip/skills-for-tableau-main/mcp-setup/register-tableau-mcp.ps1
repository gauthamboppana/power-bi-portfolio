# Register the tableau-desktop MCP server with Claude Code (user scope) from a local clone.
# Usage (PowerShell, from anywhere inside the clone):  .\mcp-setup\register-tableau-mcp.ps1
$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $PSScriptRoot
$Py = if ($env:PYTHON) { $env:PYTHON } else { "python" }
& $Py -m pip install -r "$Root\mcp-server\requirements.txt"
& $Py "$Root\mcp-server\server.py" --selftest
if (Get-Command claude -ErrorAction SilentlyContinue) {
    claude mcp add --scope user tableau-desktop -- $Py "$Root\mcp-server\server.py"
    Write-Host "Registered with Claude Code. Check with: claude mcp list"
} else {
    Write-Host "Claude Code CLI not found. Add this to your host's MCP config:"
    $rootFwd = $Root -replace '\\', '/'
    (Get-Content "$Root\mcp-setup\mcp-config-template.json" -Raw) -replace '<ABSOLUTE PATH TO>/skills-for-tableau', $rootFwd
}
