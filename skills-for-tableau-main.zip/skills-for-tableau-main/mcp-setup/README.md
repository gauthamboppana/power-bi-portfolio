# MCP setup — `tableau-desktop`

The skills tell the agent *how* to work; the `tableau-desktop` MCP server is what actually reads and writes `.twb`/`.twbx`/`.hyper` files. It is a local stdio server (Python 3.10+), so it runs on the machine where your workbooks live.

## Prerequisites

```bash
python --version                         # 3.10 or newer
pip install -r mcp-server/requirements.txt
python mcp-server/server.py --selftest   # "All self-tests passed."
```

`tableauhyperapi` is optional (extract tools only). If its wheel fails to install on your platform, comment it out of `requirements.txt`.

## Claude Code

- **Plugin install** (recommended): the `tableau-skills` plugin registers the server automatically. Nothing else to do once the Python dependencies above are installed.
- **Plain clone**: opening the repo folder picks up the root `.mcp.json`. To register it for every project, run `./mcp-setup/register-tableau-mcp.sh` (macOS/Linux) or `.\mcp-setup\register-tableau-mcp.ps1` (Windows).

Check: `claude mcp list` should show `tableau-desktop`.

## GitHub Copilot CLI

The plugin bundle declares the server in `.github/plugin/marketplace.json`. For a manual registration, add the block from [mcp-config-template.json](mcp-config-template.json) (with absolute paths) to `~/.copilot/mcp-config.json`.

## VS Code (Copilot agent mode), Cursor, Windsurf, Codex, Gemini CLI

Each host has its own MCP config file. Paste the server block from [mcp-config-template.json](mcp-config-template.json) with absolute paths:

| Host | Config file |
|---|---|
| VS Code | `.vscode/mcp.json` (key is `servers` instead of `mcpServers`) |
| Cursor | `~/.cursor/mcp.json` or `.cursor/mcp.json` |
| Windsurf | `~/.codeium/windsurf/mcp_config.json` |
| Codex CLI | `~/.codex/config.toml` → `[mcp_servers.tableau-desktop]` with `command` / `args` |
| Gemini CLI | `~/.gemini/settings.json` → `mcpServers` |

## Troubleshooting

| Symptom | Fix |
|---|---|
| `No module named 'mcp.server.fastmcp'` | You have `mcp` 2.x. `pip install "mcp>=1.2,<2"`. |
| `python` not found (macOS/Linux) | Use `python3`. For the plugin, create a `python` alias or edit the installed plugin's `.mcp.json`. |
| `tableauhyperapi` errors | Only the extract tools need it; everything else works without it. |
| Chart tools can't find templates | Call `get_chart_library_path`; set `TABLEAU_CHART_LIBRARY` if the library lives elsewhere. |
