#!/usr/bin/env bash
# Register the tableau-desktop MCP server with Claude Code (user scope) from a local clone.
# Usage: ./mcp-setup/register-tableau-mcp.sh            (run from anywhere inside the clone)
set -euo pipefail
ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PY="${PYTHON:-python3}"
"$PY" -m pip install -r "$ROOT/mcp-server/requirements.txt"
"$PY" "$ROOT/mcp-server/server.py" --selftest
if command -v claude >/dev/null 2>&1; then
  claude mcp add --scope user tableau-desktop -- "$PY" "$ROOT/mcp-server/server.py"
  echo "Registered with Claude Code. Check with: claude mcp list"
else
  echo "Claude Code CLI not found. Add this to your host's MCP config:"
  sed "s#<ABSOLUTE PATH TO>/skills-for-tableau#$ROOT#g; s#\"python\"#\"$PY\"#" "$ROOT/mcp-setup/mcp-config-template.json"
fi
