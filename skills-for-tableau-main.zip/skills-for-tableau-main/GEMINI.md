# Tableau Development Agent (Gemini CLI)

<!-- Thin on purpose: imports AGENTS.md so every tool's instructions stay identical. Edit AGENTS.md. -->

@./AGENTS.md
